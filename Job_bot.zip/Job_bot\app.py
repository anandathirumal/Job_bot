"""Streamlit UI. Thin presentation layer over ``pipeline.py`` -- this module
owns no business logic, no direct database/storage/LLM/scraper calls, and
no filesystem paths beyond what it hands to ``pipeline.py``'s keyword
arguments (which default to the configured production paths when omitted).

Two tabs:

- **New Application** -- paste a resume once per session (cached in
  ``st.session_state`` so it isn't re-parsed, and doesn't get fresh bullet
  IDs, on every tailoring run), then tailor it against either a job URL or
  pasted job text, and download the generated ``.docx``.
- **Pipeline** -- the application tracker: status per job, status history,
  resume version history with per-version download, and a two-step
  confirmation before permanently purging an application.

Every exception type ``pipeline.py`` can raise gets its own user-facing
message here rather than a generic "something went wrong" -- most of them
(``InsecureHostError``, ``AntiBotDetectedError``, ``DomStructureDriftError``,
...) represent a specific, actionable situation (try pasting the
description instead, the URL was unsafe, ...) that a bare exception string
would not communicate.

RESIDUAL RISK -- data privacy. Every tailoring run sends the full resume
text and job description to the configured external Anthropic account (see
``llm_service.py``'s own residual-risk note). A caption on the tailoring
form discloses this; there is no local-only fallback mode.
"""

from __future__ import annotations

from datetime import datetime

import streamlit as st

import pipeline
from config import settings
from exceptions import (
    AntiBotDetectedError,
    ApplicationError,
    AuthenticationError,
    DomStructureDriftError,
    EvidenceValidationError,
    InsecureHostError,
    RefusalError,
    ResourceLimitExceededError,
    TransientScrapingError,
    UnsupportedModelCapabilityError,
)
from models import ApplicationStatus

st.set_page_config(page_title="JobPortal — Resume Tailoring", page_icon="📄", layout="wide")


@st.cache_resource(show_spinner="Starting up…")
def _boot() -> bool:
    pipeline.initialize_application()
    return True


def _require_boot() -> bool:
    try:
        return _boot()
    except UnsupportedModelCapabilityError as exc:
        st.error(f"Startup check failed: {exc}")
        st.caption(
            "The configured Anthropic model does not report support for native Structured "
            "Outputs. Set JOBPORTAL_ANTHROPIC_MODEL to a supported model and restart."
        )
    except AuthenticationError as exc:
        st.error(f"Startup check failed: {exc}")
        st.caption("Set JOBPORTAL_ANTHROPIC_API_KEY (or ANTHROPIC_API_KEY) and restart.")
    except ApplicationError as exc:
        st.error(f"Application failed to start: {exc}")
    return False


def _format_timestamp(value: datetime) -> str:
    return value.strftime("%Y-%m-%d %H:%M")


def _render_tailoring_error(exc: Exception) -> None:
    if isinstance(exc, InsecureHostError):
        st.error(f"That URL was rejected for safety reasons: {exc}")
    elif isinstance(exc, AntiBotDetectedError):
        st.error(
            "That job board appears to be blocking automated access (a CAPTCHA or bot-detection "
            "wall). Try pasting the job description instead."
        )
    elif isinstance(exc, DomStructureDriftError):
        st.error(
            "Couldn't find the job description on that page -- the site's layout may not be "
            "supported. Try pasting the job description instead."
        )
    elif isinstance(exc, TransientScrapingError):
        st.error(f"Couldn't load that page after retrying: {exc}. Try again in a moment.")
    elif isinstance(exc, ResourceLimitExceededError):
        st.error(f"That input is too large: {exc}")
    elif isinstance(exc, RefusalError):
        st.error(
            "The AI model declined this request for policy reasons. Try removing sensitive "
            "content or rephrasing the job description."
        )
    elif isinstance(exc, EvidenceValidationError):
        st.error(
            f"Couldn't produce a resume grounded in your actual experience for this job: {exc}"
        )
    elif isinstance(exc, UnsupportedModelCapabilityError):
        st.error(f"Configuration error: {exc}")
    elif isinstance(exc, ApplicationError):
        st.error(f"Tailoring failed: {exc}")
    else:  # pragma: no cover -- defense in depth against a truly unexpected exception type
        st.error(f"Unexpected error: {exc}")


def _render_tailoring_result(result: pipeline.TailoringResult) -> None:
    tailored = result.tailored_resume
    st.success(f"Tailored resume ready for {tailored.job_title} at {tailored.company_name}.")

    file_name = f"{tailored.company_name}_{tailored.job_title}.docx".replace(" ", "_")
    st.download_button(
        "Download tailored resume (.docx)",
        data=result.docx_bytes,
        file_name=file_name,
        mime="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    )

    if tailored.skills_missing_not_safe_to_claim:
        st.warning(
            "Skills this job wants that your resume doesn't evidence (not added to the "
            "document -- treat these as areas to develop before applying):"
        )
        st.write(", ".join(tailored.skills_missing_not_safe_to_claim))

    if tailored.critical_warnings:
        with st.expander("Model warnings"):
            for warning in tailored.critical_warnings:
                st.write(f"- {warning}")

    if not result.evidence.is_valid:
        with st.expander("Evidence check found issues (already excluded from the document)"):
            for reason in result.evidence.invalid_bullet_reasons:
                st.write(f"- {reason}")


def _render_new_application_tab() -> None:
    st.subheader("1. Your resume")
    resume_text = st.text_area(
        "Paste your resume text",
        value=st.session_state.get("resume_text", ""),
        height=240,
        max_chars=settings.max_resume_profile_chars,
    )

    if st.button("Parse resume"):
        if not resume_text.strip():
            st.warning("Paste your resume text first.")
        else:
            with st.spinner("Parsing resume…"):
                try:
                    profile = pipeline.parse_resume(resume_text)
                except ApplicationError as exc:
                    st.error(f"Couldn't parse that resume: {exc}")
                else:
                    st.session_state["resume_profile"] = profile
                    st.session_state["resume_text"] = resume_text
                    st.success("Resume parsed.")

    profile = st.session_state.get("resume_profile")
    if profile is None:
        st.info("Parse your resume above before tailoring an application.")
        return

    with st.expander("Parsed resume preview"):
        st.write(profile.professional_summary)
        st.write(", ".join(profile.skills))
        for section in profile.experience:
            st.markdown(f"**{section.role_title} — {section.company}** ({section.timeframe})")
            for bullet in section.bullets:
                st.write(f"- {bullet.text}")

    st.subheader("2. Job posting")
    st.caption(
        "Your resume and this job description are sent to the configured Anthropic API "
        "account to generate the tailored version."
    )
    source_mode = st.radio("Source", ["Job URL", "Paste job description"], horizontal=True)
    job_url: str | None = None
    manual_job_text: str | None = None
    if source_mode == "Job URL":
        job_url = st.text_input("Job posting URL", max_chars=settings.max_url_length) or None
    else:
        manual_job_text = (
            st.text_area("Paste job description", height=240, max_chars=settings.max_job_description_chars)
            or None
        )

    if st.button("Tailor resume", type="primary"):
        if source_mode == "Job URL" and not job_url:
            st.warning("Enter a job URL.")
            return
        if source_mode == "Paste job description" and not manual_job_text:
            st.warning("Paste a job description.")
            return

        with st.spinner("Scraping, tailoring, and building your resume… this can take a minute."):
            try:
                result = pipeline.tailor_and_save_application(
                    resume_profile=profile,
                    resume_text=st.session_state["resume_text"],
                    job_url=job_url,
                    manual_job_text=manual_job_text,
                )
            except ApplicationError as exc:
                _render_tailoring_error(exc)
                return

        _render_tailoring_result(result)


def _render_purge_confirmation(application_id: int) -> None:
    confirm_key = f"confirm-delete-{application_id}"
    st.error("This permanently deletes the application, its resume files, and its history. This cannot be undone.")
    confirm_cols = st.columns(2)
    if confirm_cols[0].button("Confirm delete", key=f"confirm-{application_id}"):
        pipeline.purge_application(application_id)
        st.session_state.pop(confirm_key, None)
        st.rerun()
    if confirm_cols[1].button("Cancel", key=f"cancel-{application_id}"):
        st.session_state.pop(confirm_key, None)
        st.rerun()


def _render_pipeline_tab() -> None:
    st.subheader("Application pipeline")
    status_options = ["All"] + [status.value for status in ApplicationStatus]
    status_filter = st.selectbox("Filter by status", status_options)
    status = None if status_filter == "All" else ApplicationStatus(status_filter)

    records = pipeline.list_pipeline_matrix(status=status)
    if not records:
        st.info("No applications yet.")
        return

    status_values = [s.value for s in ApplicationStatus]

    for record in records:
        with st.container(border=True):
            header_cols = st.columns([3, 2, 2, 1])
            header_cols[0].markdown(f"**{record.job_title}** at {record.company_name}")
            header_cols[1].write(f"Status: {record.status.value}")

            new_status_value = header_cols[2].selectbox(
                "Update status",
                status_values,
                index=status_values.index(record.status.value),
                key=f"status-{record.id}",
                label_visibility="collapsed",
            )
            if new_status_value != record.status.value and header_cols[2].button("Save", key=f"save-{record.id}"):
                pipeline.update_application_status(record.id, ApplicationStatus(new_status_value))
                st.rerun()

            if header_cols[3].button("Delete", key=f"delete-{record.id}"):
                st.session_state[f"confirm-delete-{record.id}"] = True

            if st.session_state.get(f"confirm-delete-{record.id}"):
                _render_purge_confirmation(record.id)

            with st.expander("Resume versions"):
                for version in pipeline.list_resume_versions(record.id):
                    version_cols = st.columns([2, 2, 2])
                    version_cols[0].write(version.version_tag)
                    version_cols[1].write(_format_timestamp(version.created_at))
                    docx_bytes = pipeline.get_resume_document_bytes(version.file_uuid)
                    version_cols[2].download_button(
                        "Download",
                        data=docx_bytes,
                        file_name=f"{record.company_name}_{version.version_tag}.docx".replace(" ", "_"),
                        key=f"dl-{version.id}",
                    )

            with st.expander("Status history"):
                for entry in pipeline.get_status_history(record.id):
                    old = entry.old_status.value if entry.old_status else "—"
                    st.write(f"{_format_timestamp(entry.changed_at)} — {old} → {entry.new_status.value}")


def main() -> None:
    st.title("Job Application Tailoring Pipeline")
    if not _require_boot():
        st.stop()

    new_tab, pipeline_tab = st.tabs(["New Application", "Pipeline"])
    with new_tab:
        _render_new_application_tab()
    with pipeline_tab:
        _render_pipeline_tab()


if __name__ == "__main__":
    main()
