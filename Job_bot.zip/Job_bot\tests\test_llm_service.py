from __future__ import annotations

import anthropic
import httpx
import pytest

import llm_service
from exceptions import (
    AuthenticationError,
    EvidenceValidationError,
    LLMError,
    RefusalError,
    ResourceLimitExceededError,
    StructuredOutputAnomalyError,
    UnsupportedModelCapabilityError,
)
from models import (
    EducationEntry,
    ExperienceUpdateSection,
    JobUpdateBullet,
    ResumeBullet,
    ResumeExperienceSection,
    ResumeProfile,
    TailoredResumeSchema,
)


# =============================================================================
# Fakes -- never touch the real Anthropic API.
# =============================================================================


def _api_status_error(cls, status_code: int, message: str = "error"):
    request = httpx.Request("POST", "https://api.anthropic.com/v1/messages")
    response = httpx.Response(
        status_code,
        request=request,
        json={"type": "error", "error": {"type": "x", "message": message}},
    )
    return cls(message, response=response, body=None)


def _connection_error(message: str = "connection failed"):
    request = httpx.Request("POST", "https://api.anthropic.com/v1/messages")
    return anthropic.APIConnectionError(message=message, request=request)


class _FakeCapabilitySupport:
    def __init__(self, supported):
        self.supported = supported


class _FakeCapabilities:
    def __init__(self, structured_outputs_supported):
        self.structured_outputs = _FakeCapabilitySupport(structured_outputs_supported)


class _FakeModelInfo:
    def __init__(self, structured_outputs_supported=True, capabilities=...):
        if capabilities is ...:
            self.capabilities = _FakeCapabilities(structured_outputs_supported)
        else:
            self.capabilities = capabilities


class _FakeModelsResource:
    def __init__(self, info=None, error=None):
        self._info = info if info is not None else _FakeModelInfo()
        self._error = error

    def retrieve(self, model_id):
        if self._error:
            raise self._error
        return self._info


class _FakeResponse:
    def __init__(self, parsed_output=None, stop_reason="end_turn"):
        self.parsed_output = parsed_output
        self.stop_reason = stop_reason


class _FakeMessagesResource:
    def __init__(self, response=None, error=None):
        self._response = response
        self._error = error
        self.calls: list[dict] = []

    def parse(self, **kwargs):
        self.calls.append(kwargs)
        if self._error:
            raise self._error
        return self._response


class _FakeAnthropicClient:
    def __init__(self, models=None, messages=None):
        self.models = models or _FakeModelsResource()
        self.messages = messages or _FakeMessagesResource()


# =============================================================================
# Fixtures -- a realistic profile/schema pair for evidence-sanitization tests.
# =============================================================================


@pytest.fixture()
def profile() -> ResumeProfile:
    return ResumeProfile(
        contact_info="Jane Doe · jane@example.com",
        professional_summary="Backend engineer with 8 years of distributed systems experience in Python.",
        experience=[
            ResumeExperienceSection(
                role_title="Senior Backend Engineer",
                company="Acme Corp",
                timeframe="2020-2024",
                bullets=[
                    ResumeBullet(id="acme-0", text="Led migration of billing service to Kubernetes."),
                    ResumeBullet(id="acme-1", text="Reduced p99 latency by 40% via caching layer redesign."),
                ],
            )
        ],
        skills=["Python", "Kubernetes", "PostgreSQL"],
        education=[
            EducationEntry(institution="State University", credential="B.S. CS", timeframe="2012-2016")
        ],
    )


def _sample_schema(**overrides) -> TailoredResumeSchema:
    base = dict(
        job_title="Staff Backend Engineer",
        company_name="Globex",
        professional_summary="Backend engineer specializing in distributed systems.",
        skills_to_emphasize=["Python", "Kubernetes"],
        skills_missing_not_safe_to_claim=["Rust"],
        experience_updates=[
            ExperienceUpdateSection(
                role_title="Senior Backend Engineer",
                company="Acme Corp",
                timeframe="2020-2024",
                bullet_updates=[
                    JobUpdateBullet(
                        source_bullet_id="acme-0",
                        optimized_bullet="Led migration of billing service to Kubernetes, cutting infra cost 25%.",
                        rationalization="Emphasizes cost impact already present in the original bullet.",
                        evidence_preserved=True,
                    )
                ],
            )
        ],
        critical_warnings=[],
    )
    base.update(overrides)
    return TailoredResumeSchema(**base)


# =============================================================================
# verify_structured_outputs_capability
# =============================================================================


def test_capability_check_passes_when_supported():
    client = _FakeAnthropicClient(models=_FakeModelsResource(_FakeModelInfo(True)))
    llm_service.verify_structured_outputs_capability(client=client, model="claude-sonnet-5")


def test_capability_check_raises_when_unsupported():
    client = _FakeAnthropicClient(models=_FakeModelsResource(_FakeModelInfo(False)))
    with pytest.raises(UnsupportedModelCapabilityError):
        llm_service.verify_structured_outputs_capability(client=client, model="claude-sonnet-5")


def test_capability_check_raises_when_capabilities_missing():
    client = _FakeAnthropicClient(models=_FakeModelsResource(_FakeModelInfo(capabilities=None)))
    with pytest.raises(UnsupportedModelCapabilityError):
        llm_service.verify_structured_outputs_capability(client=client, model="claude-sonnet-5")


def test_capability_check_raises_on_model_not_found():
    error = _api_status_error(anthropic.NotFoundError, 404, "model not found")
    client = _FakeAnthropicClient(models=_FakeModelsResource(error=error))
    with pytest.raises(UnsupportedModelCapabilityError):
        llm_service.verify_structured_outputs_capability(client=client, model="claude-does-not-exist")


def test_capability_check_raises_authentication_error_on_bad_credentials():
    error = _api_status_error(anthropic.AuthenticationError, 401, "invalid api key")
    client = _FakeAnthropicClient(models=_FakeModelsResource(error=error))
    with pytest.raises(AuthenticationError):
        llm_service.verify_structured_outputs_capability(client=client, model="claude-sonnet-5")


def test_capability_check_raises_authentication_error_when_no_credentials_configured_at_all():
    # The SDK raises a bare TypeError (not anthropic.AuthenticationError) when
    # it can't resolve ANY credential source -- no API key, no auth token, no
    # `ant auth login` profile -- before it ever sends a request. Regression
    # test for a real bug caught by manually running the Streamlit app with
    # no credentials configured: this used to crash with an unhandled
    # TypeError instead of showing app.py's friendly AuthenticationError UI.
    error = TypeError(
        "Could not resolve authentication method. Expected one of api_key, auth_token, "
        "or credentials to be set."
    )
    client = _FakeAnthropicClient(models=_FakeModelsResource(error=error))
    with pytest.raises(AuthenticationError):
        llm_service.verify_structured_outputs_capability(client=client, model="claude-sonnet-5")


# =============================================================================
# tailor_resume -- happy path, refusal, truncation, error mapping
# =============================================================================


def test_tailor_resume_happy_path_returns_sanitized_schema_and_evidence(profile):
    schema = _sample_schema()
    client = _FakeAnthropicClient(messages=_FakeMessagesResource(_FakeResponse(parsed_output=schema)))

    sanitized, evidence = llm_service.tailor_resume(profile, "We need a backend engineer.", client=client)

    assert sanitized.job_title == "Staff Backend Engineer"
    assert evidence.is_valid is True
    assert evidence.invalid_bullet_reasons == []


def test_tailor_resume_uses_output_format_and_configured_model(profile):
    schema = _sample_schema()
    messages = _FakeMessagesResource(_FakeResponse(parsed_output=schema))
    client = _FakeAnthropicClient(messages=messages)

    llm_service.tailor_resume(profile, "job text", client=client)

    assert len(messages.calls) == 1
    call = messages.calls[0]
    assert call["output_format"] is TailoredResumeSchema
    from config import settings

    assert call["model"] == settings.anthropic_model
    assert call["max_tokens"] == settings.llm_max_output_tokens


def test_tailor_resume_raises_refusal_error_on_refusal_stop_reason(profile):
    response = _FakeResponse(parsed_output=None, stop_reason="refusal")
    client = _FakeAnthropicClient(messages=_FakeMessagesResource(response))

    with pytest.raises(RefusalError):
        llm_service.tailor_resume(profile, "job text", client=client)


def test_tailor_resume_raises_structured_output_anomaly_on_max_tokens_truncation(profile):
    response = _FakeResponse(parsed_output=None, stop_reason="max_tokens")
    client = _FakeAnthropicClient(messages=_FakeMessagesResource(response))

    with pytest.raises(StructuredOutputAnomalyError):
        llm_service.tailor_resume(profile, "job text", client=client)


def test_tailor_resume_raises_structured_output_anomaly_when_parsed_output_missing(profile):
    response = _FakeResponse(parsed_output=None, stop_reason="end_turn")
    client = _FakeAnthropicClient(messages=_FakeMessagesResource(response))

    with pytest.raises(StructuredOutputAnomalyError):
        llm_service.tailor_resume(profile, "job text", client=client)


@pytest.mark.parametrize(
    "sdk_error_factory,expected_exception",
    [
        (lambda: _connection_error(), StructuredOutputAnomalyError),
        (lambda: _api_status_error(anthropic.RateLimitError, 429), StructuredOutputAnomalyError),
        (lambda: _api_status_error(anthropic.InternalServerError, 500), StructuredOutputAnomalyError),
        (lambda: _api_status_error(anthropic.AuthenticationError, 401), AuthenticationError),
        (lambda: _api_status_error(anthropic.BadRequestError, 400), LLMError),
        (lambda: TypeError("Could not resolve authentication method."), AuthenticationError),
    ],
)
def test_tailor_resume_maps_sdk_errors_to_typed_exceptions(profile, sdk_error_factory, expected_exception):
    client = _FakeAnthropicClient(messages=_FakeMessagesResource(error=sdk_error_factory()))
    with pytest.raises(expected_exception):
        llm_service.tailor_resume(profile, "job text", client=client)


def test_tailor_resume_rejects_oversized_job_description(profile, monkeypatch):
    monkeypatch.setattr("config.settings.max_job_description_chars", 10)
    client = _FakeAnthropicClient(messages=_FakeMessagesResource(_FakeResponse(_sample_schema())))
    with pytest.raises(ResourceLimitExceededError):
        llm_service.tailor_resume(profile, "x" * 100, client=client)


# =============================================================================
# retry policy
# =============================================================================


def test_retry_wrapper_retries_once_on_structured_output_anomaly_then_succeeds(profile, monkeypatch):
    schema = _sample_schema()
    calls = {"n": 0}

    def fake_tailor_resume(prof, job_text, *, client=None):
        calls["n"] += 1
        if calls["n"] == 1:
            raise StructuredOutputAnomalyError("flaky")
        return schema, llm_service.EvidenceCheckResult(is_valid=True)

    monkeypatch.setattr(llm_service, "tailor_resume", fake_tailor_resume)

    result_schema, evidence = llm_service.tailor_resume_with_retry(profile, "job text")

    assert result_schema is schema
    assert calls["n"] == 2


def test_retry_wrapper_raises_after_exhausting_retries(profile, monkeypatch):
    calls = {"n": 0}

    def fake_tailor_resume(prof, job_text, *, client=None):
        calls["n"] += 1
        raise StructuredOutputAnomalyError("still flaky")

    monkeypatch.setattr(llm_service, "tailor_resume", fake_tailor_resume)

    with pytest.raises(StructuredOutputAnomalyError):
        llm_service.tailor_resume_with_retry(profile, "job text")

    assert calls["n"] == 2  # 1 initial + 1 retry, per structured_output_retry_limit=1


@pytest.mark.parametrize("error", [RefusalError("nope"), EvidenceValidationError("nope"), LLMError("nope")])
def test_retry_wrapper_never_retries_non_anomaly_errors(profile, monkeypatch, error):
    calls = {"n": 0}

    def fake_tailor_resume(prof, job_text, *, client=None):
        calls["n"] += 1
        raise error

    monkeypatch.setattr(llm_service, "tailor_resume", fake_tailor_resume)

    with pytest.raises(type(error)):
        llm_service.tailor_resume_with_retry(profile, "job text")

    assert calls["n"] == 1


# =============================================================================
# verify_and_sanitize_tailored_resume -- the anti-fabrication enforcement
# =============================================================================


def test_sanitize_keeps_fully_valid_response_unchanged(profile):
    schema = _sample_schema()
    sanitized, evidence = llm_service.verify_and_sanitize_tailored_resume(profile, schema)

    assert evidence.is_valid is True
    assert len(sanitized.experience_updates) == 1
    assert sanitized.skills_to_emphasize == ["Python", "Kubernetes"]


def test_sanitize_drops_bullet_with_unknown_source_bullet_id(profile):
    schema = _sample_schema(
        experience_updates=[
            ExperienceUpdateSection(
                role_title="Senior Backend Engineer",
                company="Acme Corp",
                timeframe="2020-2024",
                bullet_updates=[
                    JobUpdateBullet(
                        source_bullet_id="acme-0",
                        optimized_bullet="Real bullet.",
                        rationalization="ok",
                        evidence_preserved=True,
                    ),
                    JobUpdateBullet(
                        source_bullet_id="acme-does-not-exist",
                        optimized_bullet="Fabricated bullet.",
                        rationalization="hallucinated",
                        evidence_preserved=True,
                    ),
                ],
            )
        ]
    )

    sanitized, evidence = llm_service.verify_and_sanitize_tailored_resume(profile, schema)

    assert evidence.is_valid is False
    assert "acme-does-not-exist" in evidence.unknown_source_bullet_ids
    kept_ids = {b.source_bullet_id for s in sanitized.experience_updates for b in s.bullet_updates}
    assert kept_ids == {"acme-0"}


def test_sanitize_drops_bullet_with_evidence_preserved_false_even_with_valid_id(profile):
    schema = _sample_schema(
        experience_updates=[
            ExperienceUpdateSection(
                role_title="Senior Backend Engineer",
                company="Acme Corp",
                timeframe="2020-2024",
                bullet_updates=[
                    JobUpdateBullet(
                        source_bullet_id="acme-1",
                        optimized_bullet="Speculative rewrite.",
                        rationalization="guessed",
                        evidence_preserved=False,
                    ),
                ],
            )
        ]
    )

    sanitized, evidence = llm_service.verify_and_sanitize_tailored_resume(profile, schema)

    assert evidence.is_valid is False
    assert sanitized.experience_updates == []
    assert any("evidence_preserved=False" in reason for reason in evidence.invalid_bullet_reasons)


def test_sanitize_drops_experience_section_with_unmatched_role_and_company(profile):
    schema = _sample_schema(
        experience_updates=[
            ExperienceUpdateSection(
                role_title="VP of Engineering",  # never existed in the source profile
                company="Initech",
                timeframe="1999-2003",
                bullet_updates=[
                    JobUpdateBullet(
                        source_bullet_id="acme-0",
                        optimized_bullet="Fabricated role entirely.",
                        rationalization="hallucinated employer",
                        evidence_preserved=True,
                    )
                ],
            )
        ]
    )

    sanitized, evidence = llm_service.verify_and_sanitize_tailored_resume(profile, schema)

    assert sanitized.experience_updates == []
    assert any("unmatched role/company" in reason for reason in evidence.invalid_bullet_reasons)


def test_sanitize_demotes_unevidenced_skill_to_missing_list(profile):
    schema = _sample_schema(skills_to_emphasize=["Python", "Rust"])  # Rust not in profile

    sanitized, evidence = llm_service.verify_and_sanitize_tailored_resume(profile, schema)

    assert "Rust" not in sanitized.skills_to_emphasize
    assert "Python" in sanitized.skills_to_emphasize
    assert "Rust" in sanitized.skills_missing_not_safe_to_claim
    assert evidence.is_valid is False


def test_sanitize_matches_skill_evidenced_in_bullet_text_not_just_skills_list(profile):
    # "billing service" appears only in bullet text, not the skills list -- still
    # counts as evidenced since the check scans bullet text too.
    schema = _sample_schema(skills_to_emphasize=["Python", "billing service"])

    sanitized, _ = llm_service.verify_and_sanitize_tailored_resume(profile, schema)

    assert "billing service" in sanitized.skills_to_emphasize


def test_sanitize_raises_evidence_validation_error_when_nothing_survives(profile):
    schema = _sample_schema(
        skills_to_emphasize=["Rust"],  # unevidenced -> demoted
        experience_updates=[
            ExperienceUpdateSection(
                role_title="Senior Backend Engineer",
                company="Acme Corp",
                timeframe="2020-2024",
                bullet_updates=[
                    JobUpdateBullet(
                        source_bullet_id="acme-0",
                        optimized_bullet="x",
                        rationalization="x",
                        evidence_preserved=False,  # dropped
                    )
                ],
            )
        ],
    )

    with pytest.raises(EvidenceValidationError):
        llm_service.verify_and_sanitize_tailored_resume(profile, schema)


def test_sanitize_is_case_insensitive_for_role_company_and_skill_matching(profile):
    schema = _sample_schema(
        skills_to_emphasize=["PYTHON"],
        experience_updates=[
            ExperienceUpdateSection(
                role_title="senior backend engineer",
                company="ACME CORP",
                timeframe="2020-2024",
                bullet_updates=[
                    JobUpdateBullet(
                        source_bullet_id="acme-0",
                        optimized_bullet="x",
                        rationalization="x",
                        evidence_preserved=True,
                    )
                ],
            )
        ],
    )

    sanitized, evidence = llm_service.verify_and_sanitize_tailored_resume(profile, schema)

    assert evidence.is_valid is True
    assert len(sanitized.experience_updates) == 1
    assert "PYTHON" in sanitized.skills_to_emphasize


# =============================================================================
# parse_resume_profile -- extraction + deterministic bullet ID assignment
# =============================================================================


def _extracted_profile(bullet_id: str = "model-made-this-up") -> ResumeProfile:
    return ResumeProfile(
        contact_info="Jane Doe · jane@example.com",
        professional_summary="Backend engineer.",
        experience=[
            ResumeExperienceSection(
                role_title="Senior Backend Engineer",
                company="Acme Corp",
                timeframe="2020-2024",
                bullets=[ResumeBullet(id=bullet_id, text="Led migration of billing service to Kubernetes.")],
            )
        ],
        skills=["Python"],
    )


def test_parse_resume_profile_happy_path_discards_model_assigned_bullet_id():
    extracted = _extracted_profile(bullet_id="not-a-real-hash")
    client = _FakeAnthropicClient(messages=_FakeMessagesResource(_FakeResponse(parsed_output=extracted)))

    profile = llm_service.parse_resume_profile("raw resume text", client=client)

    assert profile.experience[0].bullets[0].id != "not-a-real-hash"
    assert len(profile.experience[0].bullets[0].id) == 16
    assert profile.experience[0].bullets[0].text == "Led migration of billing service to Kubernetes."


def test_parse_resume_profile_calls_with_output_format_resume_profile():
    extracted = _extracted_profile()
    messages = _FakeMessagesResource(_FakeResponse(parsed_output=extracted))
    client = _FakeAnthropicClient(messages=messages)

    llm_service.parse_resume_profile("raw resume text", client=client)

    assert messages.calls[0]["output_format"] is ResumeProfile


def test_parse_resume_profile_deterministic_id_is_stable_across_calls():
    profile_a = llm_service._assign_deterministic_bullet_ids(_extracted_profile(bullet_id="aaa"))
    profile_b = llm_service._assign_deterministic_bullet_ids(_extracted_profile(bullet_id="zzz"))

    # Same (company, role, position, text) -> same id, regardless of what
    # placeholder id the model happened to assign.
    assert profile_a.experience[0].bullets[0].id == profile_b.experience[0].bullets[0].id


def test_parse_resume_profile_different_bullet_text_yields_different_id():
    profile_a = llm_service._assign_deterministic_bullet_ids(_extracted_profile())
    variant = _extracted_profile()
    variant.experience[0].bullets[0] = ResumeBullet(id="x", text="A completely different bullet.")
    profile_b = llm_service._assign_deterministic_bullet_ids(variant)

    assert profile_a.experience[0].bullets[0].id != profile_b.experience[0].bullets[0].id


def test_parse_resume_profile_raises_refusal_error_on_refusal_stop_reason():
    response = _FakeResponse(parsed_output=None, stop_reason="refusal")
    client = _FakeAnthropicClient(messages=_FakeMessagesResource(response))

    with pytest.raises(RefusalError):
        llm_service.parse_resume_profile("raw resume text", client=client)


def test_parse_resume_profile_raises_anomaly_on_max_tokens_truncation():
    response = _FakeResponse(parsed_output=None, stop_reason="max_tokens")
    client = _FakeAnthropicClient(messages=_FakeMessagesResource(response))

    with pytest.raises(StructuredOutputAnomalyError):
        llm_service.parse_resume_profile("raw resume text", client=client)


def test_parse_resume_profile_raises_authentication_error_when_no_credentials_configured_at_all():
    error = TypeError("Could not resolve authentication method.")
    client = _FakeAnthropicClient(messages=_FakeMessagesResource(error=error))

    with pytest.raises(AuthenticationError):
        llm_service.parse_resume_profile("raw resume text", client=client)


def test_parse_resume_profile_rejects_oversized_resume_text(monkeypatch):
    monkeypatch.setattr("config.settings.max_resume_profile_chars", 10)
    client = _FakeAnthropicClient(messages=_FakeMessagesResource(_FakeResponse(_extracted_profile())))
    with pytest.raises(ResourceLimitExceededError):
        llm_service.parse_resume_profile("x" * 100, client=client)


def test_parse_resume_profile_retry_wrapper_retries_once_then_succeeds(monkeypatch):
    profile = _extracted_profile()
    calls = {"n": 0}

    def fake_parse(text, *, client=None):
        calls["n"] += 1
        if calls["n"] == 1:
            raise StructuredOutputAnomalyError("flaky")
        return profile

    monkeypatch.setattr(llm_service, "parse_resume_profile", fake_parse)

    result = llm_service.parse_resume_profile_with_retry("raw resume text")

    assert result is profile
    assert calls["n"] == 2


def test_parse_resume_profile_retry_wrapper_never_retries_refusal(monkeypatch):
    calls = {"n": 0}

    def fake_parse(text, *, client=None):
        calls["n"] += 1
        raise RefusalError("nope")

    monkeypatch.setattr(llm_service, "parse_resume_profile", fake_parse)

    with pytest.raises(RefusalError):
        llm_service.parse_resume_profile_with_retry("raw resume text")

    assert calls["n"] == 1
