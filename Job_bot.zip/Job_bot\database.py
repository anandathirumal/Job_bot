"""Hardened relational storage layer.

Design invariants:

- Every mutating operation runs inside an explicit ``BEGIN IMMEDIATE``
  transaction (see :func:`_transaction`). SQLite grants the RESERVED write
  lock the instant ``BEGIN IMMEDIATE`` executes, so concurrent writers are
  serialized at the engine level rather than racing on read-then-write
  logic in Python -- this is what makes monotonic ``version_tag``
  generation in :func:`create_resume_version` safe under concurrency
  without any application-level locking.
- ``PRAGMA foreign_keys``, ``journal_mode=WAL``, and ``busy_timeout`` are
  applied on every connection open (``journal_mode`` persists at the file
  level once set, but the pragma is re-issued defensively; ``foreign_keys``
  and ``busy_timeout`` are genuinely per-connection and MUST be reapplied
  every time).
- All SQL is parameterized. Nothing in this module ever interpolates
  caller-supplied values into a query string.
- This module performs NO filesystem I/O. ``purge_application_record``
  returns the ``file_uuid`` values that existed for a purged application so
  a dedicated ``storage.py`` layer can delete the corresponding ``.docx``
  files -- keeping transactional integrity and filesystem side effects
  strictly separate.

RESIDUAL RISK -- ``BEGIN IMMEDIATE`` blocks a competing writer for up to
``settings.db_busy_timeout_ms`` before SQLite raises
``sqlite3.OperationalError('database is locked')``. That is an acceptable
trade-off for a single-user desktop pipeline tool with light write volume,
but this module does not attempt to queue or retry beyond what SQLite's own
busy handler provides; sustained heavy concurrent write load would need a
real client/server RDBMS instead.
"""

from __future__ import annotations

import sqlite3
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Iterator, Optional

from config import settings
from exceptions import DatabaseError
from models import (
    ApplicationStatus,
    PipelineRecord,
    ResumeVersionRecord,
    StatusHistoryEntry,
)

# Generated from the ApplicationStatus enum (rather than hardcoded) so the
# SQL CHECK constraints below can never drift out of sync with the Python
# type that is supposed to be the single source of truth for valid values.
_STATUS_VALUES_SQL = ", ".join(f"'{status.value}'" for status in ApplicationStatus)

_SCHEMA_SQL = f"""
CREATE TABLE IF NOT EXISTS applications (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    job_title TEXT NOT NULL,
    company_name TEXT NOT NULL,
    job_url TEXT,
    source_fingerprint TEXT NOT NULL UNIQUE,
    status TEXT NOT NULL DEFAULT 'Tailored',
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    CHECK (status IN ({_STATUS_VALUES_SQL})),
    -- source_fingerprint is already NOT NULL, so this CHECK is currently
    -- redundant with the column constraint. It is kept explicit because it
    -- is the literal, auditable statement of the product invariant ("a job
    -- URL or a manual source must be present, never neither") and stays
    -- correct even if source_fingerprint's NOT NULL is ever relaxed.
    CHECK (job_url IS NOT NULL OR source_fingerprint IS NOT NULL),
    CHECK (length(trim(source_fingerprint)) > 0)
);

CREATE INDEX IF NOT EXISTS idx_applications_status ON applications(status);

CREATE TABLE IF NOT EXISTS application_status_history (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    application_id INTEGER NOT NULL REFERENCES applications(id) ON DELETE CASCADE,
    old_status TEXT,
    new_status TEXT NOT NULL,
    changed_at TEXT NOT NULL,
    CHECK (old_status IS NULL OR old_status IN ({_STATUS_VALUES_SQL})),
    CHECK (new_status IN ({_STATUS_VALUES_SQL}))
);

CREATE INDEX IF NOT EXISTS idx_status_history_application_id
    ON application_status_history(application_id);

CREATE TABLE IF NOT EXISTS resume_versions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    application_id INTEGER NOT NULL REFERENCES applications(id) ON DELETE CASCADE,
    version_tag TEXT NOT NULL,
    source_job_text TEXT NOT NULL,
    source_resume_text TEXT NOT NULL,
    validated_analysis_json TEXT NOT NULL,
    file_uuid TEXT NOT NULL UNIQUE,
    created_at TEXT NOT NULL,
    UNIQUE (application_id, version_tag)
);

CREATE INDEX IF NOT EXISTS idx_resume_versions_application_id
    ON resume_versions(application_id);
"""


def _utcnow_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def _resolve_path(db_path: Optional[Path | str]) -> Path:
    path = Path(db_path) if db_path is not None else settings.database_path
    path.parent.mkdir(parents=True, exist_ok=True)
    return path


@contextmanager
def get_connection(db_path: Optional[Path | str] = None) -> Iterator[sqlite3.Connection]:
    """Open a single hardened connection. ``isolation_level=None`` puts the
    connection in autocommit mode so that transaction boundaries are always
    the explicit ``BEGIN IMMEDIATE`` / ``COMMIT`` / ``ROLLBACK`` issued by
    :func:`_transaction`, never sqlite3's own implicit transaction tracking.
    """
    path = _resolve_path(db_path)
    conn = sqlite3.connect(
        str(path),
        timeout=settings.db_busy_timeout_ms / 1000,
        isolation_level=None,
    )
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    conn.execute("PRAGMA journal_mode = WAL")
    conn.execute(f"PRAGMA busy_timeout = {settings.db_busy_timeout_ms}")
    try:
        yield conn
    finally:
        conn.close()


@contextmanager
def _transaction(conn: sqlite3.Connection) -> Iterator[sqlite3.Connection]:
    conn.execute("BEGIN IMMEDIATE")
    try:
        yield conn
        conn.execute("COMMIT")
    except BaseException:
        conn.execute("ROLLBACK")
        raise


def init_db(db_path: Optional[Path | str] = None) -> None:
    """Create the schema if it does not already exist. Safe to call on
    every application boot -- every statement is ``IF NOT EXISTS``.
    """
    with get_connection(db_path) as conn:
        conn.executescript(_SCHEMA_SQL)


def upsert_application_pipeline(
    *,
    job_title: str,
    company_name: str,
    source_fingerprint: str,
    job_url: Optional[str] = None,
    db_path: Optional[Path | str] = None,
) -> int:
    """Insert a new application, or update title/company/url on an existing
    one identified by ``source_fingerprint``. Deliberately does NOT touch
    ``status`` on conflict -- re-tailoring a job the user already applied
    to must not silently reset their tracked pipeline status back to
    'Tailored'. Returns the application's ``id`` either way.
    """
    if not source_fingerprint or not source_fingerprint.strip():
        raise DatabaseError("source_fingerprint is required and cannot be blank")

    now = _utcnow_iso()
    with get_connection(db_path) as conn:
        with _transaction(conn):
            try:
                cursor = conn.execute(
                    """
                    INSERT INTO applications (
                        job_title, company_name, job_url, source_fingerprint,
                        status, created_at, updated_at
                    ) VALUES (?, ?, ?, ?, ?, ?, ?)
                    ON CONFLICT(source_fingerprint) DO UPDATE SET
                        job_title = excluded.job_title,
                        company_name = excluded.company_name,
                        job_url = excluded.job_url,
                        updated_at = excluded.updated_at
                    RETURNING id
                    """,
                    (
                        job_title,
                        company_name,
                        job_url,
                        source_fingerprint,
                        ApplicationStatus.TAILORED.value,
                        now,
                        now,
                    ),
                )
            except sqlite3.IntegrityError as exc:
                raise DatabaseError(f"Failed to upsert application: {exc}") from exc
            row = cursor.fetchone()

    return row["id"]


def create_resume_version(
    application_id: int,
    *,
    source_job_text: str,
    source_resume_text: str,
    validated_analysis_json: str,
    file_uuid: str,
    db_path: Optional[Path | str] = None,
) -> ResumeVersionRecord:
    """Attach a new tailored resume version to an application with a
    monotonic ``version_tag`` ("v1", "v2", ...) scoped to that application.

    The count-then-insert sequence below is safe under concurrent callers
    only because it runs inside a ``BEGIN IMMEDIATE`` transaction: SQLite
    serializes writers at the ``BEGIN IMMEDIATE`` boundary itself, so no two
    concurrent calls can ever observe the same count and mint the same tag.
    """
    now = _utcnow_iso()
    with get_connection(db_path) as conn:
        with _transaction(conn):
            exists = conn.execute(
                "SELECT 1 FROM applications WHERE id = ?", (application_id,)
            ).fetchone()
            if exists is None:
                raise DatabaseError(
                    f"No application with id={application_id}; cannot attach a resume version"
                )

            count_row = conn.execute(
                "SELECT COUNT(*) AS n FROM resume_versions WHERE application_id = ?",
                (application_id,),
            ).fetchone()
            version_tag = f"v{count_row['n'] + 1}"

            try:
                cursor = conn.execute(
                    """
                    INSERT INTO resume_versions (
                        application_id, version_tag, source_job_text, source_resume_text,
                        validated_analysis_json, file_uuid, created_at
                    ) VALUES (?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        application_id,
                        version_tag,
                        source_job_text,
                        source_resume_text,
                        validated_analysis_json,
                        file_uuid,
                        now,
                    ),
                )
            except sqlite3.IntegrityError as exc:
                raise DatabaseError(f"Failed to create resume version: {exc}") from exc
            version_id = cursor.lastrowid

    return ResumeVersionRecord(
        id=version_id,
        application_id=application_id,
        version_tag=version_tag,
        source_job_text=source_job_text,
        source_resume_text=source_resume_text,
        validated_analysis_json=validated_analysis_json,
        file_uuid=file_uuid,
        created_at=now,
    )


def fetch_pipeline_matrix(
    *,
    status: Optional[ApplicationStatus] = None,
    db_path: Optional[Path | str] = None,
) -> list[PipelineRecord]:
    """Return applications, most recently updated first, optionally
    filtered to a single status.
    """
    query = (
        "SELECT id, job_title, company_name, job_url, source_fingerprint, "
        "status, created_at, updated_at FROM applications"
    )
    params: tuple = ()
    if status is not None:
        query += " WHERE status = ?"
        params = (status.value,)
    query += " ORDER BY updated_at DESC"

    with get_connection(db_path) as conn:
        rows = conn.execute(query, params).fetchall()

    return [PipelineRecord(**dict(row)) for row in rows]


def update_application_status(
    application_id: int,
    new_status: ApplicationStatus,
    *,
    db_path: Optional[Path | str] = None,
) -> None:
    """Atomically move an application to ``new_status`` and log the
    transition into ``application_status_history``. Both writes happen in
    one transaction: a crash between them is not observable as a partial
    state.
    """
    now = _utcnow_iso()
    with get_connection(db_path) as conn:
        with _transaction(conn):
            row = conn.execute(
                "SELECT status FROM applications WHERE id = ?", (application_id,)
            ).fetchone()
            if row is None:
                raise DatabaseError(f"No application with id={application_id}")
            old_status = row["status"]

            conn.execute(
                "UPDATE applications SET status = ?, updated_at = ? WHERE id = ?",
                (new_status.value, now, application_id),
            )
            conn.execute(
                """
                INSERT INTO application_status_history (
                    application_id, old_status, new_status, changed_at
                ) VALUES (?, ?, ?, ?)
                """,
                (application_id, old_status, new_status.value, now),
            )


def fetch_status_history(
    application_id: int, *, db_path: Optional[Path | str] = None
) -> list[StatusHistoryEntry]:
    with get_connection(db_path) as conn:
        rows = conn.execute(
            """
            SELECT id, application_id, old_status, new_status, changed_at
            FROM application_status_history
            WHERE application_id = ?
            ORDER BY changed_at ASC, id ASC
            """,
            (application_id,),
        ).fetchall()
    return [StatusHistoryEntry(**dict(row)) for row in rows]


def fetch_resume_version(
    file_uuid: str, *, db_path: Optional[Path | str] = None
) -> Optional[ResumeVersionRecord]:
    """Look up a resume version by its ``file_uuid`` -- the join key
    ``storage.py`` uses to locate the generated ``.docx`` on disk.
    """
    with get_connection(db_path) as conn:
        row = conn.execute(
            """
            SELECT id, application_id, version_tag, source_job_text, source_resume_text,
                   validated_analysis_json, file_uuid, created_at
            FROM resume_versions WHERE file_uuid = ?
            """,
            (file_uuid,),
        ).fetchone()
    return ResumeVersionRecord(**dict(row)) if row is not None else None


def list_resume_versions(
    application_id: int, *, db_path: Optional[Path | str] = None
) -> list[ResumeVersionRecord]:
    with get_connection(db_path) as conn:
        rows = conn.execute(
            """
            SELECT id, application_id, version_tag, source_job_text, source_resume_text,
                   validated_analysis_json, file_uuid, created_at
            FROM resume_versions WHERE application_id = ? ORDER BY id ASC
            """,
            (application_id,),
        ).fetchall()
    return [ResumeVersionRecord(**dict(row)) for row in rows]


def purge_application_record(
    application_id: int, *, db_path: Optional[Path | str] = None
) -> tuple[str, ...]:
    """Hard-delete an application. ``ON DELETE CASCADE`` removes its
    ``resume_versions`` and ``application_status_history`` rows as part of
    the same statement.

    Returns the ``file_uuid`` of every resume version that existed for this
    application BEFORE deletion, so a dedicated storage layer can unlink
    the corresponding ``.docx`` files from disk. This function performs no
    filesystem I/O itself.
    """
    with get_connection(db_path) as conn:
        with _transaction(conn):
            rows = conn.execute(
                "SELECT file_uuid FROM resume_versions WHERE application_id = ?",
                (application_id,),
            ).fetchall()
            file_uuids = tuple(row["file_uuid"] for row in rows)

            cursor = conn.execute("DELETE FROM applications WHERE id = ?", (application_id,))
            if cursor.rowcount == 0:
                raise DatabaseError(f"No application with id={application_id} to purge")

    return file_uuids
