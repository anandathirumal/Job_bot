"""Custom exception hierarchy for the job-tailoring pipeline.

Every exception carries a class-level ``retryable`` flag. ``pipeline.py`` is
the single place that decides whether to retry a failed operation, and it
must do so by inspecting this flag rather than pattern-matching error
messages or re-implementing retry logic ad hoc. Per the operational
security spec:

- At most ONE retry for a transient scraping failure (``TransientScrapingError``).
- At most ONE retry for a transient/incomplete/anomalous Structured Outputs
  response (``StructuredOutputAnomalyError``).
- Deterministic validation, authentication, unsupported-capability,
  insecure-host, and anti-bot failures are NEVER retried, and must never be
  "repaired" by re-prompting with free-form text parsing.
"""

from __future__ import annotations


class ApplicationError(Exception):
    """Base class for all application-raised errors."""

    retryable: bool = False


# --- Network / SSRF ---------------------------------------------------------

class InsecureHostError(ApplicationError):
    """A URL, or a redirect hop, or a DNS-rebind re-check failed host safety
    validation (embedded credentials, localhost, or a non-global IP
    allocation). Never retryable: the target is unsafe regardless of attempt
    count.
    """

    retryable = False


class TooManyRedirectsError(InsecureHostError):
    """A redirect chain exceeded the hard cap of 3 hops."""


class UrlTooLongError(ApplicationError):
    """A supplied URL exceeded the 2,048 character boundary."""

    retryable = False


# --- Resource boundaries -----------------------------------------------------

class ResourceLimitExceededError(ApplicationError):
    """An ingested payload (raw HTML, normalized job text, pasted resume
    text) exceeded a hard configured size boundary. Never retryable -- the
    input itself is the problem, not the attempt.
    """

    retryable = False


# --- Scraping ----------------------------------------------------------------

class ScrapingError(ApplicationError):
    """Base class for headless-browser scraping failures."""

    retryable = False


class TransientScrapingError(ScrapingError):
    """A navigation timeout, selector-readiness timeout, or other apparently
    transient network/browser condition. Eligible for exactly one retry
    (``config.Settings.scrape_retry_limit``).
    """

    retryable = True


class AntiBotDetectedError(ScrapingError):
    """A CAPTCHA or bot-detection wall was encountered. Never retryable --
    retrying immediately re-triggers the same defense and risks getting the
    source IP blocked outright.
    """

    retryable = False


class DomStructureDriftError(ScrapingError):
    """The selectors configured in ``job_registry.py`` no longer match the
    live page structure. Not retryable automatically -- this requires a
    human to update the selector configuration, not another attempt.
    """

    retryable = False


# --- LLM / Structured Outputs -------------------------------------------------

class LLMError(ApplicationError):
    """Base class for ``llm_service.py`` failures."""

    retryable = False


class UnsupportedModelCapabilityError(LLMError):
    """Raised by the boot-time capability handshake, or at call time, when
    the configured model/runtime does not support Anthropic's native
    Structured Outputs. Never retryable -- retrying will not make the
    capability appear; the model or API version must change.
    """

    retryable = False


class StructuredOutputAnomalyError(LLMError):
    """The API returned a transient, incomplete, or otherwise anomalous
    structured response (e.g. a stop reason indicating truncation, or the
    SDK surfacing a schema-conformance failure on its own structured-output
    path). Eligible for exactly one retry
    (``config.Settings.structured_output_retry_limit``). This must never be
    used as a signal to fall back to manual/free-form JSON text repair.
    """

    retryable = True


class AuthenticationError(LLMError):
    """Anthropic API credentials were rejected. Never retryable."""

    retryable = False


class RefusalError(LLMError):
    """The model declined the request for policy reasons
    (``stop_reason == "refusal"``). This is a deliberate content decision by
    the model, not a transient API condition, so it is never retryable --
    grouped with the other "never retry" categories (deterministic
    validation, authentication, unsupported-capability, insecure-host,
    anti-bot) rather than with transient scraping/structured-output
    failures.
    """

    retryable = False


class EvidenceValidationError(LLMError):
    """Raised by application-side (non-LLM) evidence verification when a
    ``JobUpdateBullet.source_bullet_id`` does not exist in the source
    ``ResumeProfile``, or generated content is not traceably grounded in the
    original resume text. This is a deterministic content-integrity check,
    not a transient API condition, so it is never retryable.
    """

    retryable = False


# --- Persistence & documents --------------------------------------------------

class DatabaseError(ApplicationError):
    """Base class for ``database.py`` failures."""

    retryable = False


class DocumentGenerationError(ApplicationError):
    """Raised by ``doc_builder.py`` when a ``.docx`` cannot be safely
    generated (e.g. content would violate parsing-compliance constraints).
    """

    retryable = False


class StorageError(ApplicationError):
    """Base class for ``storage.py`` filesystem-layer failures."""

    retryable = False


class InvalidFileIdentifierError(StorageError):
    """A ``file_uuid`` failed strict UUID validation before being used to
    build a filesystem path. Never retryable -- this is the primary defense
    against path traversal / arbitrary file access via a malformed or
    hostile identifier, so the request must be rejected outright rather
    than retried or "sanitized" and reattempted.
    """

    retryable = False
