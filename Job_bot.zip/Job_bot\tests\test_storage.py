from __future__ import annotations

import uuid

import pytest

import storage
from exceptions import DocumentGenerationError, InvalidFileIdentifierError, StorageError


@pytest.fixture()
def base_dir(tmp_path):
    return tmp_path / "resumes"


# --------------------------- UUID validation / path traversal ----------------

def test_generate_file_uuid_returns_valid_canonical_uuid():
    generated = storage.generate_file_uuid()
    assert str(uuid.UUID(generated)) == generated


@pytest.mark.parametrize(
    "bad_uuid",
    [
        "../../../etc/passwd",
        "..\\..\\windows\\system32\\config\\sam",
        "not-a-uuid",
        "",
        "12345",
        "550e8400-e29b-41d4-a716-446655440000/../../evil",
        "550e8400-e29b-41d4-a716-446655440000\x00.docx",
    ],
)
def test_resolve_resume_document_path_rejects_non_uuid_identifiers(base_dir, bad_uuid):
    with pytest.raises(InvalidFileIdentifierError):
        storage.resolve_resume_document_path(bad_uuid, base_dir=base_dir)


def test_resolve_resume_document_path_rejects_non_string_identifier(base_dir):
    with pytest.raises(InvalidFileIdentifierError):
        storage.resolve_resume_document_path(12345, base_dir=base_dir)  # type: ignore[arg-type]


def test_resolve_resume_document_path_normalizes_case_and_format(base_dir):
    canonical = "550e8400-e29b-41d4-a716-446655440000"
    upper = canonical.upper()
    no_hyphens = canonical.replace("-", "")

    path_canonical = storage.resolve_resume_document_path(canonical, base_dir=base_dir)
    path_upper = storage.resolve_resume_document_path(upper, base_dir=base_dir)
    path_no_hyphens = storage.resolve_resume_document_path(no_hyphens, base_dir=base_dir)

    assert path_canonical == path_upper == path_no_hyphens
    assert path_canonical.name == f"{canonical}.docx"


def test_resolve_resume_document_path_stays_within_base_dir(base_dir):
    file_uuid = storage.generate_file_uuid()
    path = storage.resolve_resume_document_path(file_uuid, base_dir=base_dir)
    assert path.resolve().is_relative_to(base_dir.resolve())


# --------------------------- save / read round trip ----------------------------

def test_save_and_read_resume_document_round_trip(base_dir):
    file_uuid = storage.generate_file_uuid()
    content = b"PK\x03\x04 fake docx bytes"

    saved_path = storage.save_resume_document(file_uuid, content, base_dir=base_dir)

    assert saved_path.is_file()
    assert storage.read_resume_document(file_uuid, base_dir=base_dir) == content


def test_save_resume_document_creates_storage_dir_if_missing(base_dir):
    assert not base_dir.exists()
    storage.save_resume_document(storage.generate_file_uuid(), b"content", base_dir=base_dir)
    assert base_dir.is_dir()


def test_save_resume_document_rejects_empty_content(base_dir):
    with pytest.raises(DocumentGenerationError):
        storage.save_resume_document(storage.generate_file_uuid(), b"", base_dir=base_dir)


def test_save_resume_document_overwrites_existing_file(base_dir):
    file_uuid = storage.generate_file_uuid()
    storage.save_resume_document(file_uuid, b"version one", base_dir=base_dir)
    storage.save_resume_document(file_uuid, b"version two", base_dir=base_dir)

    assert storage.read_resume_document(file_uuid, base_dir=base_dir) == b"version two"


def test_save_resume_document_leaves_no_temp_files_on_success(base_dir):
    file_uuid = storage.generate_file_uuid()
    storage.save_resume_document(file_uuid, b"content", base_dir=base_dir)

    leftovers = list(base_dir.glob("*.tmp"))
    assert leftovers == []


def test_save_resume_document_wraps_replace_failure_and_cleans_up_temp_file(base_dir, monkeypatch):
    file_uuid = storage.generate_file_uuid()

    def failing_replace(src, dst):
        raise OSError("simulated disk failure during rename")

    monkeypatch.setattr(storage.os, "replace", failing_replace)

    with pytest.raises(StorageError):
        storage.save_resume_document(file_uuid, b"content", base_dir=base_dir)

    monkeypatch.undo()
    assert not storage.resume_document_exists(file_uuid, base_dir=base_dir)
    assert list(base_dir.glob("*.tmp")) == []


def test_read_resume_document_raises_storage_error_when_missing(base_dir):
    with pytest.raises(StorageError):
        storage.read_resume_document(storage.generate_file_uuid(), base_dir=base_dir)


def test_resume_document_exists_true_and_false(base_dir):
    file_uuid = storage.generate_file_uuid()
    assert storage.resume_document_exists(file_uuid, base_dir=base_dir) is False

    storage.save_resume_document(file_uuid, b"content", base_dir=base_dir)
    assert storage.resume_document_exists(file_uuid, base_dir=base_dir) is True


# --------------------------- delete (single + bulk) -----------------------------

def test_delete_resume_document_returns_true_when_present(base_dir):
    file_uuid = storage.generate_file_uuid()
    storage.save_resume_document(file_uuid, b"content", base_dir=base_dir)

    assert storage.delete_resume_document(file_uuid, base_dir=base_dir) is True
    assert not storage.resume_document_exists(file_uuid, base_dir=base_dir)


def test_delete_resume_document_returns_false_when_absent_and_is_idempotent(base_dir):
    file_uuid = storage.generate_file_uuid()
    assert storage.delete_resume_document(file_uuid, base_dir=base_dir) is False
    # Calling again on the still-absent file must not raise.
    assert storage.delete_resume_document(file_uuid, base_dir=base_dir) is False


def test_delete_resume_document_rejects_invalid_identifier(base_dir):
    with pytest.raises(InvalidFileIdentifierError):
        storage.delete_resume_document("../../etc/passwd", base_dir=base_dir)


def test_delete_resume_documents_bulk_reports_deleted_and_missing(base_dir):
    present = storage.generate_file_uuid()
    absent = storage.generate_file_uuid()
    storage.save_resume_document(present, b"content", base_dir=base_dir)

    result = storage.delete_resume_documents([present, absent], base_dir=base_dir)

    assert result.deleted == (present,)
    assert result.missing == (absent,)
    assert result.failed == ()
    assert result.all_succeeded is True


def test_delete_resume_documents_bulk_reports_failed_without_aborting_batch(base_dir, monkeypatch):
    stubborn = storage.generate_file_uuid()
    normal = storage.generate_file_uuid()
    storage.save_resume_document(stubborn, b"content", base_dir=base_dir)
    storage.save_resume_document(normal, b"content", base_dir=base_dir)

    stubborn_path = storage.resolve_resume_document_path(stubborn, base_dir=base_dir)
    real_remove = storage.os.remove

    def flaky_remove(path):
        if str(path) == str(stubborn_path):
            raise PermissionError("simulated file lock")
        return real_remove(path)

    monkeypatch.setattr(storage.os, "remove", flaky_remove)

    result = storage.delete_resume_documents([stubborn, normal], base_dir=base_dir)

    monkeypatch.undo()

    assert result.deleted == (normal,)
    assert result.missing == ()
    assert len(result.failed) == 1
    assert result.failed[0][0] == stubborn
    assert result.all_succeeded is False
    # The file that failed to delete must still be there -- nothing silently lost.
    assert storage.resume_document_exists(stubborn, base_dir=base_dir)


def test_delete_resume_documents_bulk_raises_on_invalid_identifier(base_dir):
    with pytest.raises(InvalidFileIdentifierError):
        storage.delete_resume_documents(["not-a-uuid"], base_dir=base_dir)


def test_delete_resume_documents_bulk_handles_empty_input(base_dir):
    result = storage.delete_resume_documents([], base_dir=base_dir)
    assert result == storage.PurgeFileResult(deleted=(), missing=(), failed=())


# --------------------------- init_storage ---------------------------------------

def test_init_storage_creates_directory(base_dir):
    assert not base_dir.exists()
    returned = storage.init_storage(base_dir)
    assert base_dir.is_dir()
    assert returned == base_dir


def test_init_storage_is_idempotent(base_dir):
    storage.init_storage(base_dir)
    storage.init_storage(base_dir)  # must not raise
    assert base_dir.is_dir()
