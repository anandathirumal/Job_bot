"""Centralized structural types shared across the whole pipeline.

Every Pydantic model that either (a) crosses the Anthropic Structured
Outputs boundary, or (b) is persisted to / read from SQLite, is defined
exactly once here to prevent schema drift or circular imports between
``scraper.py``, ``llm_service.py``, ``database.py``, ``doc_builder.py`` and
``pipeline.py``.

All schemas use :class:`StrictModel`, which sets ``extra="forbid"``. This is
not just defensive hygiene: Anthropic's native Structured Outputs feature
requires ``additionalProperties: false`` on every object node of the JSON
Schema it is given, and ``extra="forbid"`` is what makes Pydantic emit that.
It also means a model attempting to smuggle an unrequested field into a
response (e.g. a fabricated confidence score standing in for real evidence)
is rejected at validation time rather than silently accepted.
"""

from __future__ import annotations

from datetime import datetime
from enum import Enum
from typing import List, Optional

from pydantic import BaseModel, ConfigDict, Field, field_validator


class StrictModel(BaseModel):
    """Base for all LLM-facing and persisted schemas."""

    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)


# ---------------------------------------------------------------------------
# Resume profile -- the source-of-truth baseline parsed once from the
# user's pasted resume text. Every downstream "optimized" bullet must trace
# back to a ResumeBullet.id from here.
# ---------------------------------------------------------------------------

class ResumeBullet(StrictModel):
    id: str = Field(
        description=(
            "A unique, deterministic identifier (e.g. a stable hash of "
            "role + index + text) mapping directly to this one source "
            "bullet. Must never be regenerated once assigned -- evidence "
            "tracing in later pipeline stages depends on this ID staying "
            "stable across the life of the application record."
        )
    )
    text: str


class ResumeExperienceSection(StrictModel):
    role_title: str
    company: str
    timeframe: str
    bullets: List[ResumeBullet]


class EducationEntry(StrictModel):
    institution: str
    credential: str
    timeframe: str
    details: List[str] = Field(default_factory=list)


class CertificationEntry(StrictModel):
    name: str
    issuer: str
    date_earned: Optional[str] = None
    credential_id: Optional[str] = None


class AdditionalSection(StrictModel):
    """Generic catch-all for resume content that doesn't fit the fixed
    experience/education/certifications shape (publications, volunteer
    work, languages, projects, etc.), so ``ResumeProfile`` doesn't need a
    bespoke field per possible resume section.
    """

    title: str
    items: List[str]


_KNOWN_SECTIONS = frozenset(
    {
        "professional_summary",
        "experience",
        "skills",
        "education",
        "certifications",
        "additional_sections",
    }
)


class ResumeProfile(StrictModel):
    contact_info: str
    professional_summary: str
    experience: List[ResumeExperienceSection]
    skills: List[str]
    education: List[EducationEntry] = Field(default_factory=list)
    certifications: List[CertificationEntry] = Field(default_factory=list)
    additional_sections: List[AdditionalSection] = Field(default_factory=list)
    section_order: List[str] = Field(
        default_factory=lambda: [
            "professional_summary",
            "experience",
            "skills",
            "education",
            "certifications",
            "additional_sections",
        ],
        description=(
            "Canonical top-level section ordering as it appeared in the "
            "source resume, so doc_builder.py can render a linear document "
            "that matches the candidate's original structure instead of a "
            "hardcoded layout."
        ),
    )

    @field_validator("section_order")
    @classmethod
    def _section_order_known(cls, v: List[str]) -> List[str]:
        unknown = set(v) - _KNOWN_SECTIONS
        if unknown:
            raise ValueError(f"section_order references unknown sections: {sorted(unknown)}")
        return v


# ---------------------------------------------------------------------------
# Job board registry metadata (job_registry.py)
# ---------------------------------------------------------------------------

class JobBoardMetadata(StrictModel):
    name: str
    canonical_domains: List[str]
    aliases: List[str] = Field(default_factory=list)
    requires_javascript: bool
    target_selectors: List[str]


# ---------------------------------------------------------------------------
# Tailored resume output -- the native Structured Outputs schema handed to
# the Anthropic API. Split-schema design: verified matches vs. missing
# qualifications are separate fields so missing skills can never leak into
# rendered resume text by accident.
# ---------------------------------------------------------------------------

class JobUpdateBullet(StrictModel):
    source_bullet_id: str = Field(
        description=(
            "The stable ResumeBullet.id of the original bullet being "
            "optimized. Application code -- not this field, and not "
            "evidence_preserved alone -- verifies that this ID actually "
            "exists in the source ResumeProfile before the bullet is "
            "accepted."
        )
    )
    optimized_bullet: str
    rationalization: str
    evidence_preserved: bool = Field(
        description=(
            "The model's own self-assessment that this optimization relies "
            "entirely on existing source resume facts. This is NEVER "
            "trusted in isolation: llm_service.py cross-checks "
            "source_bullet_id against the real ResumeProfile and applies "
            "additional evidence checks before a bullet is accepted into "
            "the final document."
        )
    )


class ExperienceUpdateSection(StrictModel):
    role_title: str
    company: str
    timeframe: str
    bullet_updates: List[JobUpdateBullet]


class TailoredResumeSchema(StrictModel):
    job_title: str
    company_name: str
    professional_summary: str
    skills_to_emphasize: List[str] = Field(
        description="Skills explicitly evidenced in the original profile to highlight."
    )
    skills_missing_not_safe_to_claim: List[str] = Field(
        description=(
            "Required skills completely missing from the original profile. "
            "Application code must never insert these into the rendered "
            "resume document text; they exist only to surface as "
            "'areas to address' guidance to the candidate."
        )
    )
    experience_updates: List[ExperienceUpdateSection]
    critical_warnings: List[str]


class EvidenceCheckResult(StrictModel):
    """Application-level (non-LLM) verification result produced after
    cross-checking a :class:`TailoredResumeSchema` against the source
    :class:`ResumeProfile`. Persisted alongside a resume version's
    ``validated_analysis_json`` so a stored version can be audited later
    without recomputing the evidence check.
    """

    is_valid: bool
    invalid_bullet_reasons: List[str] = Field(default_factory=list)
    unknown_source_bullet_ids: List[str] = Field(default_factory=list)


# ---------------------------------------------------------------------------
# Application pipeline state (database.py)
# ---------------------------------------------------------------------------

class ApplicationStatus(str, Enum):
    TAILORED = "Tailored"
    APPLIED = "Applied"
    INTERVIEWING = "Interviewing"
    OFFER = "Offer"
    REJECTED = "Rejected"
    WITHDRAWN = "Withdrawn"
    ARCHIVED = "Archived"


class PipelineRecord(StrictModel):
    """Read model for a row returned by ``database.fetch_pipeline_matrix()``."""

    id: int
    job_title: str
    company_name: str
    job_url: Optional[str] = None
    source_fingerprint: str = Field(
        description=(
            "SHA-256 hex digest of the source content: computed from the "
            "job_url when the posting was scraped from a link, or from the "
            "manually pasted job text otherwise. Always present -- this is "
            "what guarantees every application record is traceable to a "
            "concrete source, mirroring the DB-level CHECK constraint that "
            "job_url or a manual source must exist, never neither."
        )
    )
    status: ApplicationStatus = ApplicationStatus.TAILORED
    created_at: datetime
    updated_at: datetime


class StatusHistoryEntry(StrictModel):
    """Read model for a row in ``application_status_history``."""

    id: int
    application_id: int
    old_status: Optional[ApplicationStatus] = None
    new_status: ApplicationStatus
    changed_at: datetime


class ResumeVersionRecord(StrictModel):
    """Read model for a row in ``resume_versions``.

    ``file_uuid`` is the join key ``storage.py`` uses to locate the
    generated ``.docx`` on disk -- this model, not ``database.py``, is the
    contract other modules rely on for that lookup.
    """

    id: int
    application_id: int
    version_tag: str = Field(
        description="Monotonic per-application tag ('v1', 'v2', ...) assigned by database.create_resume_version()."
    )
    source_job_text: str
    source_resume_text: str
    validated_analysis_json: str = Field(
        description="Raw JSON serialization of the application-verified TailoredResumeSchema output for this version."
    )
    file_uuid: str
    created_at: datetime


class ScrapedJobPosting(StrictModel):
    """Result of ``scraper.scrape_job_posting()``: the sanitized, bounded
    text handed to ``llm_service.py``, plus enough provenance to explain
    where it came from and whether it was truncated.
    """

    source_url: str
    final_url: str = Field(
        description="page.url after navigation settled. May differ from source_url if the page redirected client-side after the pre-flight HTTP redirect walk already validated it."
    )
    job_board_name: Optional[str] = Field(
        default=None, description="job_registry board name if the domain was recognized, else None."
    )
    matched_selector: str
    raw_html_bytes: int
    normalized_text: str
    truncated: bool = Field(
        description="True if normalized_text was cut down to config.Settings.max_job_description_chars."
    )
