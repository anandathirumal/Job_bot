# Job_bot

A security-hardened pipeline that ingests a job posting (by URL or pasted
text), tailors a candidate's resume against it using Anthropic's native
Structured Outputs, tracks the resulting application through a relational
pipeline, and compiles the tailored resume into a linear, ATS-parsing-
compliant `.docx`.

Every module documents its own residual risks in its module docstring —
this README summarizes the architecture and how to run things; treat each
file's docstring as the authoritative security/behavior reference for that
piece.

## Quick install (Windows)

```powershell
git clone https://github.com/<your-account>/Job_bot.git
cd Job_bot
powershell -ExecutionPolicy Bypass -File install.ps1
```

`install.ps1` is safe to re-run and:

1. Checks for Python 3.11+ on `PATH` (with a clear error and download link if missing).
2. Creates a `.venv` virtual environment in the repo (reused if it already exists).
3. Installs Job_bot and all its Python dependencies into that environment.
4. Downloads the Playwright Chromium browser `scraper.py` needs to fetch job postings from a URL (`-SkipPlaywright` to skip this and paste job descriptions manually instead).
5. Creates `.env` from `.env.example` if one doesn't already exist (never overwrites an existing `.env`).

Then:

```powershell
notepad .env          # set JOBPORTAL_ANTHROPIC_API_KEY (or ANTHROPIC_API_KEY)
.\run.ps1              # launches the app at http://localhost:8501
```

`run.ps1` just activates the installed virtual environment and runs
`streamlit run app.py` — use it any time after the initial install.

### Manual setup (any OS)

If you're not on Windows, or prefer to do it by hand:

```bash
python -m venv .venv
source .venv/bin/activate          # .venv\Scripts\Activate.ps1 on Windows
pip install -e ".[dev]"
python -m playwright install chromium
cp .env.example .env               # then edit it
streamlit run app.py
```

## Architecture

```
app.py            Streamlit UI -- the only module that talks to pipeline.py
pipeline.py        Orchestration facade: boot sequence, tailor-and-save flow,
                    purge coordination, thin read wrappers for the UI

url_security.py    SSRF / DNS-rebinding-hardened URL validation
job_registry.py     50-board registry, domain -> selector lookup (tldextract)
scraper.py          Playwright-driven scraping, gated by url_security.py

llm_service.py      Anthropic Structured Outputs: resume parsing, tailoring,
                    boot-time capability handshake, independent evidence
                    verification (never trusts the model's own claims)
doc_builder.py      Renders a ResumeProfile + sanitized TailoredResumeSchema
                    into a linear, ATS-compliant .docx (python-docx)

database.py         Hardened SQLite layer (WAL, FK cascades, CHECK
                    constraints generated from models.py, monotonic
                    resume-version tags)
storage.py           Filesystem layer for generated .docx files (UUID-
                    validated paths, atomic writes, no import of database.py)

models.py            All Pydantic schemas -- single source of truth
config.py            Centralized, environment-driven settings
exceptions.py         Exception hierarchy with per-type retry policy
```

`pipeline.py` is the only module `app.py` imports from directly; `storage.py`
never imports `database.py` (or vice versa) -- `pipeline.py` is what
coordinates a purge across both.

## Configuration

Edit `.env` (created from `.env.example` by `install.ps1`) and set at
minimum `JOBPORTAL_ANTHROPIC_API_KEY` (or export `ANTHROPIC_API_KEY`
directly). Every other setting has a hardened default -- see
`.env.example` for the full list of tunables (resource limits, timeouts,
retry counts, storage paths).

## Running the app

```powershell
.\run.ps1
```

On first boot, `pipeline.initialize_application()` runs the database
migration, ensures the resume storage directory exists, and performs the
mandatory Structured Outputs capability handshake against the configured
model -- startup halts with a clear message (not a traceback) if credentials
are missing or the model doesn't support Structured Outputs.

## Running tests

```bash
pytest
```

The scraper test suite drives a real headless Chromium instance against a
local `http.server` fixture (no external network calls); the LLM test suite
mocks the Anthropic client entirely (no real API calls, no cost). Neither
requires credentials to run.

## Security posture (summary)

- **SSRF / DNS rebinding** — every URL goes through `url_security.py`'s
  full pipeline (format validation, DNS resolution against a strict
  global-IP allowlist, a bounded manual redirect walk) before
  `scraper.py` ever launches a browser, plus a DNS-rebind recheck
  immediately before navigation and a post-navigation hostname
  re-validation. See `url_security.py` and `scraper.py` docstrings for the
  precise mechanism and documented residual gaps.
- **Resource limits** — URL length, HTML size, job-description length,
  resume length, navigation/selector timeouts, and retry counts are all
  centralized in `config.py` and enforced at the boundary that receives
  each input.
- **Anti-fabrication** — `llm_service.py` never trusts the model's
  self-reported `evidence_preserved` flag or its own judgment about which
  skills are evidenced. Every bullet's `source_bullet_id` and every
  emphasized skill is independently re-checked against the real
  `ResumeProfile` in application code, and anything that doesn't check out
  is stripped (or demoted to "missing", never claimed) before the document
  is built.
- **Structured Outputs only** — no manual prompt-formatting-plus-`json.loads()`
  text parsing anywhere; every LLM call uses
  `client.messages.parse(..., output_format=<schema>)`, and a boot-time
  handshake refuses to start if the configured model doesn't support it.
- **Retry policy** — exactly one retry, only for exception types marked
  `retryable = True` in `exceptions.py` (transient scraping failures,
  transient/incomplete structured-output responses). Deterministic
  validation, auth, capability, insecure-host, and anti-bot failures are
  never retried.
- **Privacy** — purging an application hard-deletes the database row
  (cascading to its resume versions and status history) and the
  corresponding `.docx` file(s) on disk. Every tailoring call transmits the
  full resume and job description to the configured Anthropic account —
  disclosed to the user in the app UI, not hidden.

## Known residual risks (see module docstrings for full detail)

- Headless browser resource consumption is unthrottled at the module level
  (`scraper.py`).
- DNS-rebinding defenses narrow, but cannot fully close, the gap between
  application-layer revalidation and the browser's own DNS resolution
  (`url_security.py`, `scraper.py`).
- `job_registry.py`'s per-board selectors and `scraper.py`'s anti-bot
  heuristics are best-effort snapshots that will drift as sites change and
  need periodic manual revalidation.
- A crash between saving a `.docx` to disk and committing its database row
  (or between deleting the database row and deleting its files on purge)
  can leave an orphaned file with no matching row — there is no real
  two-phase commit across SQLite and the filesystem (`pipeline.py`,
  `storage.py`).
- Free-text prose (the tailored professional summary, reworded bullet
  phrasing) is trusted to the model's system-prompt instructions, not
  mechanically fact-checked sentence-by-sentence — only structural
  traceability (bullet-to-source mapping) and skill-name evidence are
  independently verified (`llm_service.py`, `doc_builder.py`).
