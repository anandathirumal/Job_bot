from __future__ import annotations

import pytest

import database
import pipeline
import storage
from exceptions import InsecureHostError, RefusalError, UnsupportedModelCapabilityError
from models import (
    ApplicationStatus,
    EvidenceCheckResult,
    ExperienceUpdateSection,
    JobUpdateBullet,
    ResumeBullet,
    ResumeExperienceSection,
    ResumeProfile,
    ScrapedJobPosting,
    TailoredResumeSchema,
)


@pytest.fixture()
def db_path(tmp_path):
    return tmp_path / "pipeline.db"


@pytest.fixture()
def storage_dir(tmp_path):
    return tmp_path / "resumes"


@pytest.fixture()
def initialized(db_path, storage_dir):
    database.init_db(db_path)
    storage.init_storage(storage_dir)
    return db_path, storage_dir


@pytest.fixture()
def resume_profile() -> ResumeProfile:
    return ResumeProfile(
        contact_info="Jane Doe · jane@example.com",
        professional_summary="Backend engineer.",
        experience=[
            ResumeExperienceSection(
                role_title="Senior Backend Engineer",
                company="Acme Corp",
                timeframe="2020-2024",
                bullets=[ResumeBullet(id="acme-0", text="Led migration of billing service to Kubernetes.")],
            )
        ],
        skills=["Python", "Kubernetes"],
    )


def _sample_tailored() -> TailoredResumeSchema:
    return TailoredResumeSchema(
        job_title="Staff Backend Engineer",
        company_name="Globex",
        professional_summary="Backend engineer specializing in distributed systems.",
        skills_to_emphasize=["Python"],
        skills_missing_not_safe_to_claim=[],
        experience_updates=[
            ExperienceUpdateSection(
                role_title="Senior Backend Engineer",
                company="Acme Corp",
                timeframe="2020-2024",
                bullet_updates=[
                    JobUpdateBullet(
                        source_bullet_id="acme-0",
                        optimized_bullet="Led Kubernetes migration of billing service.",
                        rationalization="ok",
                        evidence_preserved=True,
                    )
                ],
            )
        ],
        critical_warnings=[],
    )


def _stub_tailor(monkeypatch, tailored=None, evidence=None):
    tailored = tailored or _sample_tailored()
    evidence = evidence if evidence is not None else EvidenceCheckResult(is_valid=True)

    def fake_tailor(profile, job_text, *, client=None):
        return tailored, evidence

    monkeypatch.setattr(pipeline.llm_service, "tailor_resume_with_retry", fake_tailor)
    return tailored, evidence


# =============================================================================
# initialize_application
# =============================================================================


def test_initialize_application_runs_full_boot_sequence(db_path, storage_dir, monkeypatch):
    calls = {"n": 0}

    def fake_capability(*, client=None, model=None):
        calls["n"] += 1

    monkeypatch.setattr(pipeline.llm_service, "verify_structured_outputs_capability", fake_capability)

    pipeline.initialize_application(db_path=db_path, storage_base_dir=storage_dir)

    assert db_path.exists()
    assert storage_dir.is_dir()
    assert calls["n"] == 1


def test_initialize_application_propagates_unsupported_capability_error(db_path, storage_dir, monkeypatch):
    def fake_capability(*, client=None, model=None):
        raise UnsupportedModelCapabilityError("model does not support structured outputs")

    monkeypatch.setattr(pipeline.llm_service, "verify_structured_outputs_capability", fake_capability)

    with pytest.raises(UnsupportedModelCapabilityError):
        pipeline.initialize_application(db_path=db_path, storage_base_dir=storage_dir)


# =============================================================================
# compute_source_fingerprint
# =============================================================================


def test_compute_source_fingerprint_requires_exactly_one_source():
    with pytest.raises(ValueError):
        pipeline.compute_source_fingerprint()
    with pytest.raises(ValueError):
        pipeline.compute_source_fingerprint(job_url="https://a.example/1", manual_job_text="text")


def test_compute_source_fingerprint_is_deterministic():
    fp1 = pipeline.compute_source_fingerprint(job_url="https://a.example/job/1")
    fp2 = pipeline.compute_source_fingerprint(job_url="https://a.example/job/1")
    assert fp1 == fp2
    assert len(fp1) == 64


def test_compute_source_fingerprint_url_and_manual_never_collide_on_identical_text():
    fp_url = pipeline.compute_source_fingerprint(job_url="identical string")
    fp_manual = pipeline.compute_source_fingerprint(manual_job_text="identical string")
    assert fp_url != fp_manual


# =============================================================================
# parse_resume
# =============================================================================


def test_parse_resume_delegates_to_llm_service_with_retry(monkeypatch, resume_profile):
    def fake_parse(text, *, client=None):
        assert text == "raw resume text"
        return resume_profile

    monkeypatch.setattr(pipeline.llm_service, "parse_resume_profile_with_retry", fake_parse)

    result = pipeline.parse_resume("raw resume text")
    assert result is resume_profile


# =============================================================================
# tailor_and_save_application -- manual source
# =============================================================================


def test_tailor_and_save_application_requires_exactly_one_source(initialized, resume_profile):
    db_path, storage_dir = initialized
    with pytest.raises(ValueError):
        pipeline.tailor_and_save_application(
            resume_profile=resume_profile, resume_text="raw", db_path=db_path, storage_base_dir=storage_dir
        )
    with pytest.raises(ValueError):
        pipeline.tailor_and_save_application(
            resume_profile=resume_profile,
            resume_text="raw",
            job_url="https://a.example/1",
            manual_job_text="text",
            db_path=db_path,
            storage_base_dir=storage_dir,
        )


def test_tailor_and_save_application_manual_source_end_to_end(initialized, resume_profile, monkeypatch):
    db_path, storage_dir = initialized
    tailored, evidence = _stub_tailor(monkeypatch)

    result = pipeline.tailor_and_save_application(
        resume_profile=resume_profile,
        resume_text="raw resume text",
        manual_job_text="We need a backend engineer with Python and Kubernetes.",
        db_path=db_path,
        storage_base_dir=storage_dir,
    )

    assert result.application_id > 0
    assert result.tailored_resume == tailored
    assert result.evidence == evidence
    assert result.docx_bytes

    [record] = database.fetch_pipeline_matrix(db_path=db_path)
    assert record.job_title == "Staff Backend Engineer"
    assert record.company_name == "Globex"
    assert record.job_url is None
    assert record.source_fingerprint == pipeline.compute_source_fingerprint(
        manual_job_text="We need a backend engineer with Python and Kubernetes."
    )

    assert storage.resume_document_exists(result.resume_version.file_uuid, base_dir=storage_dir)
    on_disk = storage.read_resume_document(result.resume_version.file_uuid, base_dir=storage_dir)
    assert on_disk == result.docx_bytes

    loaded_tailored, loaded_evidence = pipeline.load_validated_analysis(
        result.resume_version.validated_analysis_json
    )
    assert loaded_tailored == tailored
    assert loaded_evidence == evidence


def test_tailor_and_save_application_url_source_end_to_end(initialized, resume_profile, monkeypatch):
    db_path, storage_dir = initialized
    _stub_tailor(monkeypatch)

    scraped = ScrapedJobPosting(
        source_url="https://boards.greenhouse.io/acme/jobs/1",
        final_url="https://boards.greenhouse.io/acme/jobs/1",
        job_board_name="Greenhouse",
        matched_selector="main",
        raw_html_bytes=1000,
        normalized_text="We need a backend engineer.",
        truncated=False,
    )

    def fake_scrape(url):
        assert url == "https://boards.greenhouse.io/acme/jobs/1"
        return scraped

    monkeypatch.setattr(pipeline, "scrape_job_posting_with_retry", fake_scrape)

    result = pipeline.tailor_and_save_application(
        resume_profile=resume_profile,
        resume_text="raw resume text",
        job_url="https://boards.greenhouse.io/acme/jobs/1",
        db_path=db_path,
        storage_base_dir=storage_dir,
    )

    [record] = database.fetch_pipeline_matrix(db_path=db_path)
    assert record.job_url == scraped.final_url
    assert record.source_fingerprint == pipeline.compute_source_fingerprint(job_url=scraped.final_url)
    assert result.resume_version.source_job_text == scraped.normalized_text


def test_tailor_and_save_application_resubmit_reuses_application_id_and_creates_new_version(
    initialized, resume_profile, monkeypatch
):
    db_path, storage_dir = initialized
    _stub_tailor(monkeypatch)

    result1 = pipeline.tailor_and_save_application(
        resume_profile=resume_profile,
        resume_text="raw v1",
        manual_job_text="job text",
        db_path=db_path,
        storage_base_dir=storage_dir,
    )
    result2 = pipeline.tailor_and_save_application(
        resume_profile=resume_profile,
        resume_text="raw v2",
        manual_job_text="job text",
        db_path=db_path,
        storage_base_dir=storage_dir,
    )

    assert result1.application_id == result2.application_id
    versions = pipeline.list_resume_versions(result1.application_id, db_path=db_path)
    assert [v.version_tag for v in versions] == ["v1", "v2"]
    assert versions[0].file_uuid != versions[1].file_uuid


def test_tailor_and_save_application_propagates_scraper_errors_without_partial_writes(
    initialized, resume_profile, monkeypatch
):
    db_path, storage_dir = initialized

    def fake_scrape(url):
        raise InsecureHostError("blocked by SSRF validation")

    monkeypatch.setattr(pipeline, "scrape_job_posting_with_retry", fake_scrape)

    with pytest.raises(InsecureHostError):
        pipeline.tailor_and_save_application(
            resume_profile=resume_profile,
            resume_text="raw",
            job_url="http://169.254.169.254/",
            db_path=db_path,
            storage_base_dir=storage_dir,
        )

    assert database.fetch_pipeline_matrix(db_path=db_path) == []


def test_tailor_and_save_application_propagates_llm_errors_without_partial_writes(
    initialized, resume_profile, monkeypatch
):
    db_path, storage_dir = initialized

    def fake_tailor(profile, job_text, *, client=None):
        raise RefusalError("model declined")

    monkeypatch.setattr(pipeline.llm_service, "tailor_resume_with_retry", fake_tailor)

    with pytest.raises(RefusalError):
        pipeline.tailor_and_save_application(
            resume_profile=resume_profile,
            resume_text="raw",
            manual_job_text="job text",
            db_path=db_path,
            storage_base_dir=storage_dir,
        )

    assert database.fetch_pipeline_matrix(db_path=db_path) == []


# =============================================================================
# purge_application
# =============================================================================


def test_purge_application_deletes_db_row_and_file(initialized, resume_profile, monkeypatch):
    db_path, storage_dir = initialized
    _stub_tailor(monkeypatch)

    result = pipeline.tailor_and_save_application(
        resume_profile=resume_profile,
        resume_text="raw",
        manual_job_text="job text",
        db_path=db_path,
        storage_base_dir=storage_dir,
    )

    purge_result = pipeline.purge_application(result.application_id, db_path=db_path, storage_base_dir=storage_dir)

    assert purge_result.deleted == (result.resume_version.file_uuid,)
    assert purge_result.failed == ()
    assert database.fetch_pipeline_matrix(db_path=db_path) == []
    assert not storage.resume_document_exists(result.resume_version.file_uuid, base_dir=storage_dir)


# =============================================================================
# thin read/status wrappers
# =============================================================================


def test_update_status_and_history_and_matrix_wrappers(initialized, resume_profile, monkeypatch):
    db_path, storage_dir = initialized
    _stub_tailor(monkeypatch)

    result = pipeline.tailor_and_save_application(
        resume_profile=resume_profile,
        resume_text="raw",
        manual_job_text="job text",
        db_path=db_path,
        storage_base_dir=storage_dir,
    )

    pipeline.update_application_status(result.application_id, ApplicationStatus.APPLIED, db_path=db_path)

    [record] = pipeline.list_pipeline_matrix(db_path=db_path)
    assert record.status is ApplicationStatus.APPLIED

    history = pipeline.get_status_history(result.application_id, db_path=db_path)
    assert history[-1].new_status is ApplicationStatus.APPLIED
    assert history[-1].old_status is ApplicationStatus.TAILORED


def test_get_resume_document_bytes_returns_saved_docx(initialized, resume_profile, monkeypatch):
    db_path, storage_dir = initialized
    _stub_tailor(monkeypatch)

    result = pipeline.tailor_and_save_application(
        resume_profile=resume_profile,
        resume_text="raw",
        manual_job_text="job text",
        db_path=db_path,
        storage_base_dir=storage_dir,
    )

    fetched = pipeline.get_resume_document_bytes(result.resume_version.file_uuid, storage_base_dir=storage_dir)
    assert fetched == result.docx_bytes
