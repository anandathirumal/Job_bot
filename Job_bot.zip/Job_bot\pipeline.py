"""Orchestration facade tying every module into the end-to-end workflows
``app.py`` actually needs. This is the only module the UI layer should
import from directly -- it in turn owns the calling order across
``url_security``/``scraper``, ``llm_service``, ``doc_builder``,
``storage``, and ``database``, so no two of those modules ever need to
know about each other directly.

Two workflows:

1. **Boot** (:func:`initialize_application`) -- run once at process
   startup. Initializes the database schema, ensures the resume storage
   directory exists, and runs the Structured Outputs capability handshake
   (``exceptions.UnsupportedModelCapabilityError`` halts startup here if
   the configured model doesn't support it, per spec).

2. **Tailor and save** (:func:`tailor_and_save_application`) -- the
   per-application flow: resolve the job source (scrape a URL through the
   full SSRF-hardened pipeline, or accept manually pasted text) ->
   Structured-Outputs tailoring against the caller's already-parsed
   ``ResumeProfile`` -> independent evidence sanitization -> render the
   sanitized result to a ``.docx`` -> persist the file, then the database
   row referencing it, in that order.

Everything else here (:func:`purge_application`,
:func:`list_pipeline_matrix`, :func:`update_application_status`, ...) is a
thin pass-through to ``database.py`` / ``storage.py`` -- kept here rather
than in ``app.py`` only so the UI layer never imports those modules
directly.

RESIDUAL RISK -- ``tailor_and_save_application`` saves the ``.docx`` to
disk *before* committing the ``resume_versions`` database row (the row's
``file_uuid`` column is ``NOT NULL``, so the file must already exist to
reference it). If the process crashes or the database write fails between
those two steps, the file is left orphaned on disk with no row pointing to
it -- the same class of residual risk already documented in
``storage.py`` for the reverse direction (DB-deleted-then-file-deletion),
just encountered on the write path instead of the purge path. There is no
real two-phase commit across SQLite and the filesystem here; this is an
accepted trade-off for a single-user desktop tool, not a gap this module
tries to close with retry/rollback machinery.
"""

from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

import anthropic

import database
import doc_builder
import llm_service
import storage
from models import (
    ApplicationStatus,
    EvidenceCheckResult,
    PipelineRecord,
    ResumeProfile,
    ResumeVersionRecord,
    StatusHistoryEntry,
    TailoredResumeSchema,
)
from scraper import scrape_job_posting_with_retry


def initialize_application(
    *,
    db_path: Optional[Path | str] = None,
    storage_base_dir: Optional[Path | str] = None,
    llm_client: Optional[anthropic.Anthropic] = None,
) -> None:
    """Run once at process startup, before serving any request. Raises
    ``exceptions.UnsupportedModelCapabilityError`` (and halts startup, per
    spec) if the configured Anthropic model doesn't report native
    Structured Outputs support.
    """
    database.init_db(db_path)
    storage.init_storage(storage_base_dir)
    llm_service.verify_structured_outputs_capability(client=llm_client)


def parse_resume(resume_text: str, *, llm_client: Optional[anthropic.Anthropic] = None) -> ResumeProfile:
    """Parse a raw pasted resume once per session; reuse the returned
    ``ResumeProfile`` across every subsequent tailoring call in that
    session rather than re-parsing per application (see
    ``llm_service.parse_resume_profile``'s docstring for why).
    """
    return llm_service.parse_resume_profile_with_retry(resume_text, client=llm_client)


def compute_source_fingerprint(*, job_url: Optional[str] = None, manual_job_text: Optional[str] = None) -> str:
    """SHA-256 hex digest identifying a job posting's source, unified
    across the URL and manual-paste cases (see ``database.py``'s schema
    notes on ``source_fingerprint``). Exactly one of the two arguments must
    be provided.

    The hash basis is tagged with its source type (``url:`` / ``manual:``)
    so a manually pasted job description can never collide with a URL that
    happens to be the same literal string -- an edge case unlikely in
    practice, but free to close outright.
    """
    if bool(job_url) == bool(manual_job_text):
        raise ValueError("Exactly one of job_url or manual_job_text must be provided")
    basis = f"url:{job_url}" if job_url else f"manual:{manual_job_text}"
    return hashlib.sha256(basis.encode("utf-8")).hexdigest()


@dataclass(frozen=True)
class TailoringResult:
    application_id: int
    resume_version: ResumeVersionRecord
    tailored_resume: TailoredResumeSchema
    evidence: EvidenceCheckResult
    docx_bytes: bytes


def _encode_validated_analysis(tailored: TailoredResumeSchema, evidence: EvidenceCheckResult) -> str:
    return json.dumps(
        {
            "tailored_resume": tailored.model_dump(mode="json"),
            "evidence_check": evidence.model_dump(mode="json"),
        }
    )


def load_validated_analysis(validated_analysis_json: str) -> tuple[TailoredResumeSchema, EvidenceCheckResult]:
    """Inverse of :func:`_encode_validated_analysis` -- decode a stored
    ``resume_versions.validated_analysis_json`` blob back into typed
    objects, e.g. for ``app.py`` to display audit detail on a historical
    version.
    """
    data = json.loads(validated_analysis_json)
    return (
        TailoredResumeSchema.model_validate(data["tailored_resume"]),
        EvidenceCheckResult.model_validate(data["evidence_check"]),
    )


def tailor_and_save_application(
    *,
    resume_profile: ResumeProfile,
    resume_text: str,
    job_url: Optional[str] = None,
    manual_job_text: Optional[str] = None,
    db_path: Optional[Path | str] = None,
    storage_base_dir: Optional[Path | str] = None,
    llm_client: Optional[anthropic.Anthropic] = None,
) -> TailoringResult:
    """The full per-application pipeline. Provide exactly one of ``job_url``
    (scraped through the SSRF-hardened pipeline) or ``manual_job_text``
    (pasted directly, no scraping).

    ``resume_profile`` should already be the result of :func:`parse_resume`
    for this session; ``resume_text`` is the raw pasted resume that
    produced it, stored verbatim as this version's historical record.
    """
    if bool(job_url) == bool(manual_job_text):
        raise ValueError("Exactly one of job_url or manual_job_text must be provided")

    if job_url:
        scraped = scrape_job_posting_with_retry(job_url)
        job_description_text = scraped.normalized_text
        final_job_url = scraped.final_url
        source_fingerprint = compute_source_fingerprint(job_url=final_job_url)
    else:
        job_description_text = manual_job_text
        final_job_url = None
        source_fingerprint = compute_source_fingerprint(manual_job_text=manual_job_text)

    tailored, evidence = llm_service.tailor_resume_with_retry(
        resume_profile, job_description_text, client=llm_client
    )

    docx_bytes = doc_builder.build_resume_docx(resume_profile, tailored)

    application_id = database.upsert_application_pipeline(
        job_title=tailored.job_title,
        company_name=tailored.company_name,
        source_fingerprint=source_fingerprint,
        job_url=final_job_url,
        db_path=db_path,
    )

    file_uuid = storage.generate_file_uuid()
    storage.save_resume_document(file_uuid, docx_bytes, base_dir=storage_base_dir)

    resume_version = database.create_resume_version(
        application_id,
        source_job_text=job_description_text,
        source_resume_text=resume_text,
        validated_analysis_json=_encode_validated_analysis(tailored, evidence),
        file_uuid=file_uuid,
        db_path=db_path,
    )

    return TailoringResult(
        application_id=application_id,
        resume_version=resume_version,
        tailored_resume=tailored,
        evidence=evidence,
        docx_bytes=docx_bytes,
    )


def purge_application(
    application_id: int,
    *,
    db_path: Optional[Path | str] = None,
    storage_base_dir: Optional[Path | str] = None,
) -> storage.PurgeFileResult:
    """Hard-delete an application: the database row (and, via
    ``ON DELETE CASCADE``, its resume versions and status history) first,
    then the corresponding ``.docx`` files on disk. See the module
    docstring's residual-risk note for the ordering trade-off.
    """
    file_uuids = database.purge_application_record(application_id, db_path=db_path)
    return storage.delete_resume_documents(file_uuids, base_dir=storage_base_dir)


def list_pipeline_matrix(
    *,
    status: Optional[ApplicationStatus] = None,
    db_path: Optional[Path | str] = None,
) -> list[PipelineRecord]:
    return database.fetch_pipeline_matrix(status=status, db_path=db_path)


def update_application_status(
    application_id: int,
    new_status: ApplicationStatus,
    *,
    db_path: Optional[Path | str] = None,
) -> None:
    database.update_application_status(application_id, new_status, db_path=db_path)


def get_status_history(
    application_id: int, *, db_path: Optional[Path | str] = None
) -> list[StatusHistoryEntry]:
    return database.fetch_status_history(application_id, db_path=db_path)


def list_resume_versions(
    application_id: int, *, db_path: Optional[Path | str] = None
) -> list[ResumeVersionRecord]:
    return database.list_resume_versions(application_id, db_path=db_path)


def get_resume_document_bytes(
    file_uuid: str, *, storage_base_dir: Optional[Path | str] = None
) -> bytes:
    return storage.read_resume_document(file_uuid, base_dir=storage_base_dir)
