"""Anthropic Structured Outputs integration and independent evidence
verification.

Two responsibilities live here, deliberately kept separate:

1. **Getting a structured response out of the model.** Both
   ``parse_resume_profile()`` (raw pasted resume text -> ``ResumeProfile``)
   and ``tailor_resume()`` (``ResumeProfile`` + job text -> tailored
   resume) use the Anthropic SDK's native Structured Outputs path
   (``client.messages.parse(..., output_format=<schema>)``) -- never
   manual prompt-formatting-plus-``json.loads()`` text parsing. Every
   schema targeted (``models.StrictModel`` subclasses) sets
   ``extra="forbid"``, which is what makes Pydantic emit the
   ``additionalProperties: false`` JSON Schema keyword the API requires.
   ``verify_structured_outputs_capability()`` is the boot-time handshake:
   call it once at application startup (not per-request) and let
   ``exceptions.UnsupportedModelCapabilityError`` halt startup if the
   configured model doesn't report Structured Outputs support.
   ``parse_resume_profile()`` additionally discards every bullet ID the
   model assigns and replaces it with one application code computes
   deterministically -- see ``_assign_deterministic_bullet_ids()`` -- since
   the evidence-tracing mechanism below depends on those IDs being
   genuinely stable, which an LLM cannot actually guarantee.

2. **Not trusting the model's own claims about itself.** The schema asks the
   model to set ``evidence_preserved: true`` and to only name skills it can
   back up -- but per the spec, that self-report is never sufficient on its
   own. ``verify_and_sanitize_tailored_resume()`` is the actual enforcement
   point: it independently checks every ``source_bullet_id`` against the
   real ``ResumeProfile``, checks every emphasized skill against text that
   is actually present in the profile, and *removes* (not just flags)
   anything that doesn't check out before the result is ever persisted or
   handed to ``doc_builder.py``. A bullet with ``evidence_preserved=False``
   is dropped even though its ``source_bullet_id`` is valid -- the model's
   own uncertainty is treated as a hard signal, not advisory.

Retry policy: ``tailor_resume_with_retry()`` and
``parse_resume_profile_with_retry()`` both retry only
``exceptions.StructuredOutputAnomalyError`` (transient network/server
errors, a response truncated at ``max_tokens`` before the schema could
complete, or a response that satisfied the JSON schema but failed one of
our Pydantic ``field_validator``s -- e.g. ``ResumeProfile.section_order``
naming something outside its fixed vocabulary; the Anthropic SDK raises
that case as a bare ``pydantic.ValidationError``, not an ``anthropic.*``
exception, so it's caught separately and remapped), at most
``settings.structured_output_retry_limit`` times (1, per policy). A policy
refusal (``stop_reason == "refusal"``) raises ``exceptions.RefusalError``
and is never retried -- retrying a refusal just asks the same classifier
the same question again. Evidence-sanitization failures
(``exceptions.EvidenceValidationError``) are also never retried -- they are
deterministic content-integrity findings about the response that already
arrived, not something a re-roll fixes.

RESIDUAL RISK -- data privacy. Every call to ``tailor_resume()`` transmits
the full source resume profile (name, contact info, full work history) and
the full target job description to the configured external Anthropic
account as request content. This module does not redact or minimize that
payload -- the tailoring task inherently needs the complete resume text.
Operators are responsible for whatever data-handling agreement governs their
Anthropic account and for informing end users that their resume content
leaves this application's boundary on every tailoring request.
"""

from __future__ import annotations

import hashlib
from typing import Optional

import anthropic
import pydantic

from config import settings
from exceptions import (
    AuthenticationError,
    EvidenceValidationError,
    LLMError,
    RefusalError,
    ResourceLimitExceededError,
    StructuredOutputAnomalyError,
    UnsupportedModelCapabilityError,
)
from models import (
    EvidenceCheckResult,
    ExperienceUpdateSection,
    JobUpdateBullet,
    ResumeBullet,
    ResumeExperienceSection,
    ResumeProfile,
    TailoredResumeSchema,
)

_SYSTEM_PROMPT = """You are an ATS resume-tailoring assistant. Given a candidate's existing resume \
profile and a target job description, propose an optimized version of the resume.

Non-negotiable rules:
- Never invent job titles, employers, dates, metrics, or skills that are not already present in the \
source resume profile.
- Every bullet you optimize must reference the source_bullet_id of the exact original bullet it is \
based on. Never invent a source_bullet_id.
- Only place a skill in skills_to_emphasize if it is explicitly evidenced by text in the source \
resume profile (its skills list, summary, or bullet text). If the job needs a skill the candidate's \
resume does not evidence, put it in skills_missing_not_safe_to_claim instead -- never fabricate it \
into the resume.
- Set evidence_preserved=true on a bullet only if your rewrite relies entirely on facts already \
present in that specific bullet. If you are uncertain, set it to false rather than guessing true.
- Use critical_warnings to flag anything you are unsure about, including any part of the job \
description you could not honestly address from the candidate's real experience.

Application code independently re-verifies every source_bullet_id and every emphasized skill against \
the original resume profile, and discards anything that does not check out -- accuracy here is \
required, not optional."""


def _build_client() -> anthropic.Anthropic:
    """Never called at import time -- constructing a client makes no network
    call by itself, but keeping it lazy avoids any surprise client-side
    side effect from simply importing this module.
    """
    if settings.anthropic_api_key:
        return anthropic.Anthropic(api_key=settings.anthropic_api_key)
    # No key configured here: let the SDK resolve credentials on its own
    # (ANTHROPIC_API_KEY env var, ANTHROPIC_AUTH_TOKEN, or an `ant auth
    # login` profile) rather than passing api_key="" and breaking auth.
    return anthropic.Anthropic()


def verify_structured_outputs_capability(
    *,
    client: Optional[anthropic.Anthropic] = None,
    model: Optional[str] = None,
) -> None:
    """Boot-time capability handshake. Call once at application startup --
    not per tailoring request. Raises ``UnsupportedModelCapabilityError`` if
    the configured model doesn't report native Structured Outputs support,
    which per the spec must halt startup entirely.
    """
    model = model or settings.anthropic_model
    client = client or _build_client()

    try:
        info = client.models.retrieve(model)
    except anthropic.NotFoundError as exc:
        raise UnsupportedModelCapabilityError(
            f"Model {model!r} was not found by the Anthropic API; cannot verify "
            f"Structured Outputs support"
        ) from exc
    except anthropic.AuthenticationError as exc:
        raise AuthenticationError(
            f"Anthropic API credentials rejected during the boot-time capability handshake: {exc}"
        ) from exc
    except TypeError as exc:
        # The SDK raises a bare TypeError (not an AuthenticationError) when
        # it can't resolve any credential source at all -- no API key, no
        # auth token, no `ant auth login` profile -- before it ever sends a
        # request. That's still an authentication configuration problem
        # from this application's point of view.
        raise AuthenticationError(f"No Anthropic API credentials are configured: {exc}") from exc

    capabilities = getattr(info, "capabilities", None)
    structured_outputs = getattr(capabilities, "structured_outputs", None) if capabilities else None
    supported = getattr(structured_outputs, "supported", None) if structured_outputs else None

    if not supported:
        raise UnsupportedModelCapabilityError(
            f"Model {model!r} does not report support for native Structured Outputs "
            f"(capabilities.structured_outputs.supported is {supported!r}); refusing to start."
        )


_PARSE_SYSTEM_PROMPT = """You are a resume-parsing assistant. Transcribe the pasted resume text into \
the structured ResumeProfile schema exactly as written -- this is extraction, not rewriting.

Rules:
- Do not add, infer, embellish, or correct any content. If something is ambiguous or missing, leave it \
out rather than guessing.
- Preserve the original wording of every bullet, the professional summary, and section content \
verbatim (only whitespace/formatting cleanup is allowed).
- Preserve the original ordering of experience entries and the bullets within each entry.
- section_order is a FIXED vocabulary, not the resume's own heading text. Every entry must be exactly \
one of: professional_summary, experience, skills, education, certifications, additional_sections -- \
lowercase, spelled exactly as shown, nothing else. Map the resume's actual headings onto this \
vocabulary yourself: e.g. "Objective", "Summary", "Profile" -> professional_summary; "Relevant \
Skills", "Technical Skills", "Core Competencies" -> skills; "Work Experience", "Employment History", \
"Professional Experience" -> experience; anything routed into additional_sections (see below) still \
appears in section_order as the literal string "additional_sections", never as its own original \
heading text. List each vocabulary term at most once, in the order that section first appeared in the \
source text, and only include terms for sections the resume actually has.
- The id field on each bullet is a required placeholder only -- put any short string there; \
application code discards it and assigns a real stable identifier afterward, so do not spend effort \
trying to make it meaningful.
- Route anything that doesn't fit contact_info, professional_summary, experience, skills, education, \
or certifications into additional_sections, using the resume's own section heading as that entry's \
title field (the heading text belongs in additional_sections[].title -- never in section_order)."""


def _assign_deterministic_bullet_ids(profile: ResumeProfile) -> ResumeProfile:
    """Replace every bullet's LLM-assigned ``id`` with one application code
    computes deterministically from (company, role, position, text).

    This is not a formatting nicety -- the entire evidence-tracing
    mechanism in :func:`verify_and_sanitize_tailored_resume` depends on
    bullet IDs being genuinely stable and collision-free within a profile.
    An LLM asked to "produce a stable hash" cannot actually guarantee
    either property (sampling variance, no real hashing capability), so
    its self-assigned IDs are discarded outright rather than trusted or
    merely validated.
    """
    new_sections: list[ResumeExperienceSection] = []
    for section in profile.experience:
        new_bullets: list[ResumeBullet] = []
        for index, bullet in enumerate(section.bullets):
            basis = f"{section.company}|{section.role_title}|{index}|{bullet.text}"
            stable_id = hashlib.sha256(basis.encode("utf-8")).hexdigest()[:16]
            new_bullets.append(ResumeBullet(id=stable_id, text=bullet.text))
        new_sections.append(
            ResumeExperienceSection(
                role_title=section.role_title,
                company=section.company,
                timeframe=section.timeframe,
                bullets=new_bullets,
            )
        )
    return profile.model_copy(update={"experience": new_sections})


def parse_resume_profile(
    resume_text: str,
    *,
    client: Optional[anthropic.Anthropic] = None,
) -> ResumeProfile:
    """Extract a raw pasted resume into a structured :class:`ResumeProfile`
    via native Structured Outputs -- also never manual text parsing.

    Callers should parse a resume once per session and reuse the resulting
    :class:`ResumeProfile` across every tailoring call in that session
    (``pipeline.py`` does this) -- re-parsing on every application both
    costs an extra LLM call and produces a fresh set of bullet IDs that
    won't line up with anything from a prior parse of the same text.
    """
    if len(resume_text) > settings.max_resume_profile_chars:
        raise ResourceLimitExceededError(
            f"resume_text ({len(resume_text)} chars) exceeds the "
            f"{settings.max_resume_profile_chars}-char limit"
        )

    client = client or _build_client()

    try:
        response = client.messages.parse(
            model=settings.anthropic_model,
            max_tokens=settings.llm_max_output_tokens,
            system=_PARSE_SYSTEM_PROMPT,
            messages=[{"role": "user", "content": resume_text}],
            output_format=ResumeProfile,
        )
    except anthropic.RateLimitError as exc:
        raise StructuredOutputAnomalyError(f"Rate limited by the Anthropic API: {exc}") from exc
    except anthropic.APIConnectionError as exc:
        raise StructuredOutputAnomalyError(f"Network error calling the Anthropic API: {exc}") from exc
    except anthropic.InternalServerError as exc:
        raise StructuredOutputAnomalyError(f"Anthropic API returned a server error: {exc}") from exc
    except anthropic.AuthenticationError as exc:
        raise AuthenticationError(f"Anthropic API credentials rejected: {exc}") from exc
    except anthropic.BadRequestError as exc:
        raise LLMError(f"Anthropic API rejected the request as malformed: {exc}") from exc
    except TypeError as exc:
        # See verify_structured_outputs_capability()'s identical guard: the
        # SDK raises a bare TypeError, not AuthenticationError, when no
        # credential source resolves at all.
        raise AuthenticationError(f"No Anthropic API credentials are configured: {exc}") from exc
    except pydantic.ValidationError as exc:
        # The model's response satisfied the JSON *schema* (Structured
        # Outputs guarantees that) but failed one of our Pydantic
        # field_validators -- e.g. section_order naming a value outside the
        # fixed vocabulary. The Anthropic SDK's own output_format parsing
        # raises this as a bare pydantic.ValidationError from inside
        # anthropic.lib._parse._response, not as any anthropic.* exception,
        # so it must be caught separately here. Treated as an anomalous
        # structured response (retryable once) rather than left to crash
        # uncaught, since a re-roll often produces a compliant response.
        raise StructuredOutputAnomalyError(
            f"Structured Outputs response satisfied the JSON schema but failed content "
            f"validation: {exc}"
        ) from exc

    stop_reason = getattr(response, "stop_reason", None)
    if stop_reason == "refusal":
        raise RefusalError(
            "The Anthropic model declined the resume-parsing request for policy reasons "
            "(stop_reason=refusal)"
        )
    if stop_reason == "max_tokens":
        raise StructuredOutputAnomalyError(
            f"Structured Outputs response was truncated at max_tokens="
            f"{settings.llm_max_output_tokens} before the schema could complete"
        )

    parsed = getattr(response, "parsed_output", None)
    if parsed is None:
        raise StructuredOutputAnomalyError(
            "Structured Outputs response completed but contained no parsed_output"
        )

    return _assign_deterministic_bullet_ids(parsed)


def parse_resume_profile_with_retry(
    resume_text: str,
    *,
    client: Optional[anthropic.Anthropic] = None,
) -> ResumeProfile:
    """Retrying counterpart to :func:`parse_resume_profile`, mirroring
    :func:`tailor_resume_with_retry`'s policy exactly: retries only
    ``StructuredOutputAnomalyError``, at most
    ``settings.structured_output_retry_limit`` times.
    """
    attempts = settings.structured_output_retry_limit + 1
    last_error: Optional[StructuredOutputAnomalyError] = None

    for attempt in range(attempts):
        try:
            return parse_resume_profile(resume_text, client=client)
        except StructuredOutputAnomalyError as exc:
            last_error = exc
            if attempt == attempts - 1:
                raise

    raise last_error  # pragma: no cover -- unreachable, loop always returns or raises


def _build_user_content(profile: ResumeProfile, job_description_text: str) -> str:
    if len(job_description_text) > settings.max_job_description_chars:
        raise ResourceLimitExceededError(
            f"job_description_text ({len(job_description_text)} chars) exceeds the "
            f"{settings.max_job_description_chars}-char limit; caller must validate upstream"
        )

    profile_json = profile.model_dump_json(indent=2)
    if len(profile_json) > settings.max_resume_profile_chars:
        raise ResourceLimitExceededError(
            f"Resume profile JSON ({len(profile_json)} chars) exceeds the "
            f"{settings.max_resume_profile_chars}-char limit"
        )

    return (
        "SOURCE RESUME PROFILE (JSON; every bullet carries a stable id):\n"
        f"{profile_json}\n\n"
        "TARGET JOB DESCRIPTION:\n"
        f"{job_description_text}"
    )


def verify_and_sanitize_tailored_resume(
    profile: ResumeProfile, schema: TailoredResumeSchema
) -> tuple[TailoredResumeSchema, EvidenceCheckResult]:
    """The real enforcement point for the anti-fabrication rules -- runs
    entirely in application code, never trusting the model's self-reported
    ``evidence_preserved`` flag or its own judgment about which skills are
    evidenced.

    Returns a **sanitized** schema with every unverifiable bullet update and
    skill removed (unevidenced skills are demoted into
    ``skills_missing_not_safe_to_claim`` instead of silently dropped), plus
    an :class:`EvidenceCheckResult` recording exactly what was removed and
    why, for audit/storage alongside the tailored resume version.

    Raises ``EvidenceValidationError`` if sanitization leaves nothing
    usable at all (no experience updates and no emphasized skills survive)
    -- that means the response could not be grounded in the source resume,
    and returning an empty result silently would be worse than failing
    loudly.
    """
    valid_bullet_ids = {bullet.id for section in profile.experience for bullet in section.bullets}
    real_roles = {
        (section.role_title.strip().lower(), section.company.strip().lower())
        for section in profile.experience
    }
    evidenced_skills = {skill.strip().lower() for skill in profile.skills}
    evidenced_text = " ".join(
        [
            profile.professional_summary,
            " ".join(profile.skills),
            " ".join(bullet.text for section in profile.experience for bullet in section.bullets),
        ]
    ).lower()

    unknown_ids: list[str] = []
    invalid_reasons: list[str] = []
    sanitized_sections: list[ExperienceUpdateSection] = []

    for section in schema.experience_updates:
        role_key = (section.role_title.strip().lower(), section.company.strip().lower())
        if role_key not in real_roles:
            invalid_reasons.append(
                f"Dropped experience_updates entry for unmatched role/company: "
                f"{section.role_title!r} at {section.company!r} (not found in source resume)"
            )
            continue

        kept_bullets: list[JobUpdateBullet] = []
        for bullet in section.bullet_updates:
            if bullet.source_bullet_id not in valid_bullet_ids:
                unknown_ids.append(bullet.source_bullet_id)
                invalid_reasons.append(
                    f"Dropped bullet update with unknown source_bullet_id {bullet.source_bullet_id!r}"
                )
                continue
            if not bullet.evidence_preserved:
                invalid_reasons.append(
                    f"Dropped bullet update for source_bullet_id {bullet.source_bullet_id!r}: "
                    f"model self-reported evidence_preserved=False"
                )
                continue
            kept_bullets.append(bullet)

        if kept_bullets:
            sanitized_sections.append(
                ExperienceUpdateSection(
                    role_title=section.role_title,
                    company=section.company,
                    timeframe=section.timeframe,
                    bullet_updates=kept_bullets,
                )
            )

    kept_skills: list[str] = []
    demoted_skills: list[str] = []
    for skill in schema.skills_to_emphasize:
        skill_lower = skill.strip().lower()
        if skill_lower in evidenced_skills or skill_lower in evidenced_text:
            kept_skills.append(skill)
        else:
            demoted_skills.append(skill)
            invalid_reasons.append(
                f"Skill {skill!r} was not evidenced in the source resume; demoted to "
                f"skills_missing_not_safe_to_claim"
            )

    merged_missing = list(dict.fromkeys([*schema.skills_missing_not_safe_to_claim, *demoted_skills]))
    merged_warnings = list(dict.fromkeys([*schema.critical_warnings, *invalid_reasons]))

    sanitized = TailoredResumeSchema(
        job_title=schema.job_title,
        company_name=schema.company_name,
        professional_summary=schema.professional_summary,
        skills_to_emphasize=kept_skills,
        skills_missing_not_safe_to_claim=merged_missing,
        experience_updates=sanitized_sections,
        critical_warnings=merged_warnings,
    )

    evidence_result = EvidenceCheckResult(
        is_valid=not unknown_ids and not invalid_reasons,
        invalid_bullet_reasons=invalid_reasons,
        unknown_source_bullet_ids=unknown_ids,
    )

    if not sanitized_sections and not kept_skills:
        raise EvidenceValidationError(
            "After evidence sanitization, the tailored resume has no usable experience "
            "updates or emphasized skills left -- the model's response could not be "
            "grounded in the source resume profile."
        )

    return sanitized, evidence_result


def tailor_resume(
    profile: ResumeProfile,
    job_description_text: str,
    *,
    client: Optional[anthropic.Anthropic] = None,
) -> tuple[TailoredResumeSchema, EvidenceCheckResult]:
    """Single-attempt tailoring call. Prefer :func:`tailor_resume_with_retry`
    in application code -- this function is the no-retry building block it
    wraps, exposed directly for tests and callers that want to manage
    retries themselves.
    """
    client = client or _build_client()
    user_content = _build_user_content(profile, job_description_text)

    try:
        response = client.messages.parse(
            model=settings.anthropic_model,
            max_tokens=settings.llm_max_output_tokens,
            system=_SYSTEM_PROMPT,
            messages=[{"role": "user", "content": user_content}],
            output_format=TailoredResumeSchema,
        )
    except anthropic.RateLimitError as exc:
        raise StructuredOutputAnomalyError(f"Rate limited by the Anthropic API: {exc}") from exc
    except anthropic.APIConnectionError as exc:
        raise StructuredOutputAnomalyError(f"Network error calling the Anthropic API: {exc}") from exc
    except anthropic.InternalServerError as exc:
        raise StructuredOutputAnomalyError(f"Anthropic API returned a server error: {exc}") from exc
    except anthropic.AuthenticationError as exc:
        raise AuthenticationError(f"Anthropic API credentials rejected: {exc}") from exc
    except anthropic.BadRequestError as exc:
        raise LLMError(f"Anthropic API rejected the request as malformed: {exc}") from exc
    except TypeError as exc:
        # See verify_structured_outputs_capability()'s identical guard: the
        # SDK raises a bare TypeError, not AuthenticationError, when no
        # credential source resolves at all.
        raise AuthenticationError(f"No Anthropic API credentials are configured: {exc}") from exc
    except pydantic.ValidationError as exc:
        # The model's response satisfied the JSON *schema* (Structured
        # Outputs guarantees that) but failed one of our Pydantic
        # field_validators -- e.g. section_order naming a value outside the
        # fixed vocabulary. The Anthropic SDK's own output_format parsing
        # raises this as a bare pydantic.ValidationError from inside
        # anthropic.lib._parse._response, not as any anthropic.* exception,
        # so it must be caught separately here. Treated as an anomalous
        # structured response (retryable once) rather than left to crash
        # uncaught, since a re-roll often produces a compliant response.
        raise StructuredOutputAnomalyError(
            f"Structured Outputs response satisfied the JSON schema but failed content "
            f"validation: {exc}"
        ) from exc

    stop_reason = getattr(response, "stop_reason", None)
    if stop_reason == "refusal":
        raise RefusalError(
            "The Anthropic model declined the tailoring request for policy reasons "
            "(stop_reason=refusal)"
        )
    if stop_reason == "max_tokens":
        raise StructuredOutputAnomalyError(
            f"Structured Outputs response was truncated at max_tokens="
            f"{settings.llm_max_output_tokens} before the schema could complete"
        )

    parsed = getattr(response, "parsed_output", None)
    if parsed is None:
        raise StructuredOutputAnomalyError(
            "Structured Outputs response completed but contained no parsed_output"
        )

    return verify_and_sanitize_tailored_resume(profile, parsed)


def tailor_resume_with_retry(
    profile: ResumeProfile,
    job_description_text: str,
    *,
    client: Optional[anthropic.Anthropic] = None,
) -> tuple[TailoredResumeSchema, EvidenceCheckResult]:
    """The entry point application code should call. Retries only
    ``StructuredOutputAnomalyError`` (transient/incomplete responses), at
    most ``settings.structured_output_retry_limit`` times (1, per policy).
    Every other exception -- ``RefusalError``, ``EvidenceValidationError``,
    ``UnsupportedModelCapabilityError``, ``AuthenticationError``,
    ``ResourceLimitExceededError`` -- propagates immediately on first
    occurrence.
    """
    attempts = settings.structured_output_retry_limit + 1
    last_error: Optional[StructuredOutputAnomalyError] = None

    for attempt in range(attempts):
        try:
            return tailor_resume(profile, job_description_text, client=client)
        except StructuredOutputAnomalyError as exc:
            last_error = exc
            if attempt == attempts - 1:
                raise

    raise last_error  # pragma: no cover -- unreachable, loop always returns or raises
