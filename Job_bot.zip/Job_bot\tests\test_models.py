from __future__ import annotations

import pytest
from pydantic import ValidationError

from models import (
    ApplicationStatus,
    CertificationEntry,
    EducationEntry,
    EvidenceCheckResult,
    ExperienceUpdateSection,
    JobBoardMetadata,
    JobUpdateBullet,
    PipelineRecord,
    ResumeBullet,
    ResumeExperienceSection,
    ResumeProfile,
    TailoredResumeSchema,
)


def _sample_resume_profile(**overrides) -> ResumeProfile:
    base = dict(
        contact_info="Jane Doe · jane@example.com",
        professional_summary="Backend engineer with 8 years of distributed systems experience.",
        experience=[
            ResumeExperienceSection(
                role_title="Senior Backend Engineer",
                company="Acme Corp",
                timeframe="2020-2024",
                bullets=[
                    ResumeBullet(id="acme-0", text="Led migration of billing service to Kubernetes."),
                    ResumeBullet(id="acme-1", text="Reduced p99 latency by 40% via caching layer redesign."),
                ],
            )
        ],
        skills=["Python", "Kubernetes", "PostgreSQL"],
    )
    base.update(overrides)
    return ResumeProfile(**base)


def _sample_tailored_schema() -> TailoredResumeSchema:
    return TailoredResumeSchema(
        job_title="Staff Backend Engineer",
        company_name="Globex",
        professional_summary="Backend engineer specializing in distributed systems.",
        skills_to_emphasize=["Python", "Kubernetes"],
        skills_missing_not_safe_to_claim=["Rust"],
        experience_updates=[
            ExperienceUpdateSection(
                role_title="Senior Backend Engineer",
                company="Acme Corp",
                timeframe="2020-2024",
                bullet_updates=[
                    JobUpdateBullet(
                        source_bullet_id="acme-0",
                        optimized_bullet="Led migration of billing service to Kubernetes, cutting infra cost 25%.",
                        rationalization="Emphasizes cost impact evidenced in the original bullet's metrics.",
                        evidence_preserved=True,
                    )
                ],
            )
        ],
        critical_warnings=[],
    )


# --------------------------- ResumeBullet / ResumeProfile --------------------

def test_resume_profile_defaults_are_empty_and_ordered():
    profile = _sample_resume_profile()
    assert profile.education == []
    assert profile.certifications == []
    assert profile.additional_sections == []
    assert profile.section_order[:2] == ["professional_summary", "experience"]


def test_resume_profile_preserves_education_and_certifications():
    profile = _sample_resume_profile(
        education=[
            EducationEntry(
                institution="State University",
                credential="B.S. Computer Science",
                timeframe="2012-2016",
            )
        ],
        certifications=[
            CertificationEntry(name="AWS Solutions Architect", issuer="AWS", date_earned="2022")
        ],
    )
    assert profile.education[0].institution == "State University"
    assert profile.certifications[0].issuer == "AWS"


def test_resume_profile_rejects_unknown_section_order_entry():
    with pytest.raises(ValidationError):
        _sample_resume_profile(section_order=["not_a_real_section"])


def test_resume_profile_forbids_unexpected_fields():
    with pytest.raises(ValidationError):
        _sample_resume_profile(hallucinated_field="should not be allowed")


def test_resume_bullet_forbids_extra_fields():
    with pytest.raises(ValidationError):
        ResumeBullet(id="x", text="did something", confidence=0.9)


# --------------------------- JobBoardMetadata ---------------------------------

def test_job_board_metadata_aliases_default_empty():
    board = JobBoardMetadata(
        name="LinkedIn",
        canonical_domains=["linkedin.com"],
        requires_javascript=True,
        target_selectors=["main"],
    )
    assert board.aliases == []


# --------------------------- TailoredResumeSchema / evidence -------------------

def test_tailored_resume_schema_round_trip():
    schema = _sample_tailored_schema()
    payload = schema.model_dump()
    rebuilt = TailoredResumeSchema.model_validate(payload)
    assert rebuilt == schema


def test_tailored_resume_schema_forbids_hallucinated_top_level_field():
    with pytest.raises(ValidationError):
        TailoredResumeSchema(
            job_title="x",
            company_name="y",
            professional_summary="z",
            skills_to_emphasize=[],
            skills_missing_not_safe_to_claim=[],
            experience_updates=[],
            critical_warnings=[],
            fabricated_years_experience=15,
        )


def test_job_update_bullet_forbids_extra_fields():
    with pytest.raises(ValidationError):
        JobUpdateBullet(
            source_bullet_id="acme-0",
            optimized_bullet="text",
            rationalization="why",
            evidence_preserved=True,
            confidence_score=0.99,
        )


def test_evidence_check_result_defaults():
    result = EvidenceCheckResult(is_valid=False)
    assert result.invalid_bullet_reasons == []
    assert result.unknown_source_bullet_ids == []


# --------------------------- JSON Schema / Structured Outputs compliance -------

def _assert_no_additional_properties(schema: dict) -> None:
    """Anthropic native Structured Outputs requires every object node in the
    JSON Schema to set additionalProperties: false. Walk $defs plus the
    root schema to confirm StrictModel's extra='forbid' produced that shape
    for every nested model, not just the top level.
    """
    defs = schema.get("$defs", {})
    nodes = [schema, *defs.values()]
    for node in nodes:
        if node.get("type") == "object" or "properties" in node:
            assert node.get("additionalProperties") is False, node


def test_tailored_resume_schema_json_schema_forbids_additional_properties():
    schema = TailoredResumeSchema.model_json_schema()
    _assert_no_additional_properties(schema)


def test_resume_profile_json_schema_forbids_additional_properties():
    schema = ResumeProfile.model_json_schema()
    _assert_no_additional_properties(schema)


# --------------------------- Application pipeline state ------------------------

def test_application_status_default_matches_db_default():
    assert ApplicationStatus.TAILORED.value == "Tailored"


def test_pipeline_record_round_trip():
    record = PipelineRecord(
        id=1,
        job_title="Staff Backend Engineer",
        company_name="Globex",
        job_url="https://jobs.globex.example/123",
        source_fingerprint="a" * 64,
        status=ApplicationStatus.APPLIED,
        created_at="2026-08-01T12:00:00",
        updated_at="2026-08-01T12:00:00",
    )
    assert record.status is ApplicationStatus.APPLIED
    assert record.job_url == "https://jobs.globex.example/123"


def test_pipeline_record_allows_null_job_url_for_manual_source():
    record = PipelineRecord(
        id=2,
        job_title="Data Engineer",
        company_name="Initech",
        job_url=None,
        source_fingerprint="b" * 64,
        created_at="2026-08-01T12:00:00",
        updated_at="2026-08-01T12:00:00",
    )
    assert record.job_url is None
    assert record.status is ApplicationStatus.TAILORED


def test_pipeline_record_requires_source_fingerprint():
    with pytest.raises(ValidationError):
        PipelineRecord(
            id=3,
            job_title="Data Engineer",
            company_name="Initech",
            created_at="2026-08-01T12:00:00",
            updated_at="2026-08-01T12:00:00",
        )
