from __future__ import annotations

import io

import pytest
from docx import Document as DocxDocument

import doc_builder
from models import (
    AdditionalSection,
    CertificationEntry,
    EducationEntry,
    ExperienceUpdateSection,
    JobUpdateBullet,
    ResumeBullet,
    ResumeExperienceSection,
    ResumeProfile,
    TailoredResumeSchema,
)


@pytest.fixture()
def profile() -> ResumeProfile:
    return ResumeProfile(
        contact_info="Jane Doe · jane@example.com · (555) 123-4567",
        professional_summary="Backend engineer with 8 years of distributed systems experience.",
        experience=[
            ResumeExperienceSection(
                role_title="Senior Backend Engineer",
                company="Acme Corp",
                timeframe="2020-2024",
                bullets=[
                    ResumeBullet(id="acme-0", text="Led migration of billing service to Kubernetes."),
                    ResumeBullet(id="acme-1", text="Reduced p99 latency by 40% via caching layer redesign."),
                ],
            ),
            ResumeExperienceSection(
                role_title="Backend Engineer",
                company="Initech",
                timeframe="2016-2020",
                bullets=[
                    ResumeBullet(id="initech-0", text="Built the original payments reconciliation pipeline."),
                ],
            ),
        ],
        skills=["Python", "Kubernetes", "PostgreSQL", "Terraform"],
        education=[
            EducationEntry(institution="State University", credential="B.S. Computer Science", timeframe="2012-2016")
        ],
        certifications=[
            CertificationEntry(name="AWS Solutions Architect", issuer="AWS", date_earned="2022")
        ],
        additional_sections=[
            AdditionalSection(title="Publications", items=["Scaling Billing Systems, 2023"]),
        ],
    )


@pytest.fixture()
def tailored() -> TailoredResumeSchema:
    return TailoredResumeSchema(
        job_title="Staff Backend Engineer",
        company_name="Globex",
        professional_summary="Backend engineer specializing in distributed billing systems.",
        skills_to_emphasize=["Kubernetes", "Python"],
        skills_missing_not_safe_to_claim=["Rust", "Go"],
        experience_updates=[
            # Only the Acme role is tailored -- Initech is deliberately left untouched
            # to test the full-work-history fallback.
            ExperienceUpdateSection(
                role_title="Senior Backend Engineer",
                company="Acme Corp",
                timeframe="2020-2024",
                bullet_updates=[
                    JobUpdateBullet(
                        source_bullet_id="acme-0",
                        optimized_bullet="Led Kubernetes migration of billing service, cutting infra cost 25%.",
                        rationalization="Adds cost framing evidenced in original bullet.",
                        evidence_preserved=True,
                    )
                ],
            )
        ],
        critical_warnings=["Job posting also wants 5 years of Go experience -- not evidenced in resume."],
    )


def _load(docx_bytes: bytes) -> DocxDocument:
    return DocxDocument(io.BytesIO(docx_bytes))


def _all_text(document: DocxDocument) -> str:
    return "\n".join(p.text for p in document.paragraphs)


def test_build_resume_docx_returns_loadable_document(profile, tailored):
    docx_bytes = doc_builder.build_resume_docx(profile, tailored)
    assert docx_bytes
    document = _load(docx_bytes)
    assert len(document.paragraphs) > 0


def test_full_work_history_always_present_even_for_untouched_role(profile, tailored):
    text = _all_text(_load(doc_builder.build_resume_docx(profile, tailored)))
    assert "Acme Corp" in text
    assert "Initech" in text  # never tailored, but must still appear


def test_untouched_role_falls_back_to_original_bullet_text(profile, tailored):
    text = _all_text(_load(doc_builder.build_resume_docx(profile, tailored)))
    assert "Built the original payments reconciliation pipeline." in text


def test_tailored_role_uses_optimized_bullet_not_original(profile, tailored):
    text = _all_text(_load(doc_builder.build_resume_docx(profile, tailored)))
    assert "Led Kubernetes migration of billing service, cutting infra cost 25%." in text
    assert "Led migration of billing service to Kubernetes." not in text


def test_second_untouched_bullet_of_a_tailored_role_is_dropped_not_leaked(profile, tailored):
    # acme-1 ("Reduced p99 latency...") had no bullet_update at all -- the
    # tailored section only rewrote acme-0. Since an update DID exist for
    # this role, we trust the tailored set as complete for that role rather
    # than silently mixing in an original bullet the model chose to drop.
    text = _all_text(_load(doc_builder.build_resume_docx(profile, tailored)))
    assert "Reduced p99 latency by 40%" not in text


def test_skills_missing_not_safe_to_claim_never_appears_in_document(profile, tailored):
    text = _all_text(_load(doc_builder.build_resume_docx(profile, tailored)))
    assert "Rust" not in text
    assert "Go" not in text


def test_critical_warnings_never_appears_in_document(profile, tailored):
    text = _all_text(_load(doc_builder.build_resume_docx(profile, tailored)))
    assert "5 years of Go experience" not in text


def test_emphasized_and_original_skills_both_appear(profile, tailored):
    text = _all_text(_load(doc_builder.build_resume_docx(profile, tailored)))
    for skill in ["Python", "Kubernetes", "PostgreSQL", "Terraform"]:
        assert skill in text


def test_emphasized_skills_ordered_before_remaining_skills(profile, tailored):
    document = _load(doc_builder.build_resume_docx(profile, tailored))
    skills_paragraph = next(p.text for p in document.paragraphs if "PostgreSQL" in p.text)
    assert skills_paragraph.index("Kubernetes") < skills_paragraph.index("PostgreSQL")


def test_document_has_no_tables_or_inline_images(profile, tailored):
    document = _load(doc_builder.build_resume_docx(profile, tailored))
    assert document.tables == []
    assert list(document.inline_shapes) == []


def test_section_headings_use_native_heading_style(profile, tailored):
    document = _load(doc_builder.build_resume_docx(profile, tailored))
    heading_texts = {p.text for p in document.paragraphs if p.style.name.startswith("Heading")}
    assert "Professional Summary" in heading_texts
    assert "Experience" in heading_texts
    assert "Skills" in heading_texts
    assert "Education" in heading_texts
    assert "Certifications" in heading_texts


def test_bullets_use_native_list_bullet_style(profile, tailored):
    document = _load(doc_builder.build_resume_docx(profile, tailored))
    bullet_paragraphs = [p for p in document.paragraphs if p.style.name == "List Bullet"]
    assert any("Led Kubernetes migration" in p.text for p in bullet_paragraphs)


def test_contact_info_in_body_not_header_or_footer(profile, tailored):
    document = _load(doc_builder.build_resume_docx(profile, tailored))
    assert any(profile.contact_info in p.text for p in document.paragraphs)
    for section in document.sections:
        assert profile.contact_info not in section.header.paragraphs[0].text
        assert profile.contact_info not in section.footer.paragraphs[0].text


def test_respects_custom_section_order(profile, tailored):
    reordered = profile.model_copy(
        update={"section_order": ["skills", "professional_summary", "experience", "education", "certifications"]}
    )
    document = _load(doc_builder.build_resume_docx(reordered, tailored))
    heading_order = [p.text for p in document.paragraphs if p.style.name.startswith("Heading") and p.style.name.endswith("1")]
    assert heading_order.index("Skills") < heading_order.index("Professional Summary")
    assert heading_order.index("Professional Summary") < heading_order.index("Experience")


def test_education_and_certifications_rendered(profile, tailored):
    text = _all_text(_load(doc_builder.build_resume_docx(profile, tailored)))
    assert "State University" in text
    assert "B.S. Computer Science" in text
    assert "AWS Solutions Architect" in text


def test_additional_sections_rendered_with_their_own_title(profile, tailored):
    text = _all_text(_load(doc_builder.build_resume_docx(profile, tailored)))
    assert "Publications" in text
    assert "Scaling Billing Systems, 2023" in text


def test_skips_empty_sections(profile, tailored):
    bare_profile = profile.model_copy(update={"certifications": [], "additional_sections": []})
    document = _load(doc_builder.build_resume_docx(bare_profile, tailored))
    heading_texts = {p.text for p in document.paragraphs if p.style.name.startswith("Heading")}
    assert "Certifications" not in heading_texts


def test_falls_back_to_original_summary_when_tailored_summary_blank(profile, tailored):
    blank_summary = tailored.model_copy(update={"professional_summary": ""})
    text = _all_text(_load(doc_builder.build_resume_docx(profile, blank_summary)))
    assert profile.professional_summary in text
