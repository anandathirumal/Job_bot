"""SSRF- and DNS-rebinding-hardened URL validation.

This module is the mandatory gate between any user-supplied URL and the
headless browser engine in ``scraper.py``. It performs two independent
layers of defense:

1. :func:`validate_url_security` -- a pre-flight check run BEFORE a URL is
   ever handed to the browser. It validates format/length, resolves DNS,
   rejects any resolved address that is not publicly routable (global),
   and then manually walks up to ``settings.max_redirects`` HTTP redirect
   hops using a bounded, non-body-downloading streaming ``httpx.Client``
   (``HEAD``, falling back to a ranged ``GET`` only when a server rejects
   ``HEAD``), re-validating the hostname and every resolved IP at each hop.

2. :func:`revalidate_before_navigation` -- a second, cheap DNS-only
   re-check that ``scraper.py`` MUST call immediately before
   ``page.goto()``, to catch DNS answers that changed between validation
   and navigation.

RESIDUAL RISK -- DNS rebinding cannot be fully eliminated at this
application layer. Between the moment :func:`revalidate_before_navigation`
re-resolves a hostname and the moment the headless browser performs its
own, independent DNS resolution to actually open the TCP connection, an
attacker who controls authoritative DNS for the target domain can still
rebind the answer to a private/internal address inside that narrow window.
Fully closing this gap requires connection-level IP pinning (e.g. routing
browser traffic through a proxy that resolves once and pins the connection
to that specific IP for the lifetime of the navigation), which is out of
scope for a pure Python validation module and is a documented limitation
callers in ``scraper.py`` must be aware of.
"""

from __future__ import annotations

import ipaddress
import socket
from dataclasses import dataclass
from typing import Callable, Sequence
from urllib.parse import SplitResult, urlsplit

import httpx

from config import settings
from exceptions import InsecureHostError, TooManyRedirectsError, UrlTooLongError

ALLOWED_SCHEMES = frozenset({"http", "https"})

# A resolver takes a hostname and returns the raw IP address strings it
# resolves to. Injectable so callers (and tests) never depend on live DNS.
Resolver = Callable[[str], Sequence[str]]


def _default_resolver(hostname: str) -> list[str]:
    try:
        infos = socket.getaddrinfo(hostname, None)
    except socket.gaierror as exc:
        raise InsecureHostError(f"DNS resolution failed for host {hostname!r}: {exc}") from exc
    return sorted({info[4][0] for info in infos})


@dataclass(frozen=True)
class ValidatedURL:
    """Result of a full SSRF-safe validation pass.

    ``resolved_ips`` are the IPs proven safe at validation time. Because
    they can go stale, :func:`revalidate_before_navigation` MUST be called
    again immediately before the browser actually navigates -- see the
    DNS-rebinding residual risk documented at module level.
    """

    url: str
    hostname: str
    resolved_ips: tuple[str, ...]


def is_global_ip(ip: "ipaddress.IPv4Address | ipaddress.IPv6Address") -> bool:
    """Reject everything that isn't a publicly routable, global address.

    Deliberately redundant (rather than relying solely on ``ip.is_global``)
    so that if any single Python ``ipaddress`` special-case classification
    ever changes across versions, the other explicit checks still catch it.

    Public (not module-private) because ``scraper.py`` reuses this exact
    classification to vet subresource request targets at the browser-route
    level -- IP-safety logic must have exactly one implementation, never a
    second copy that could quietly drift out of sync.
    """
    return (
        ip.is_global
        and not ip.is_private
        and not ip.is_loopback
        and not ip.is_link_local
        and not ip.is_multicast
        and not ip.is_reserved
        and not ip.is_unspecified
        and not getattr(ip, "is_site_local", False)
    )


def _reject_embedded_credentials(parts: SplitResult, original_url: str) -> None:
    if parts.username or parts.password:
        raise InsecureHostError(f"URL contains embedded credentials: {original_url!r}")


def parse_and_check_format(url: str) -> SplitResult:
    """Validate length, scheme, credentials, and obvious localhost targets.

    Does NOT resolve DNS -- see :func:`resolve_and_validate_host` for that.
    """
    if not isinstance(url, str) or not url.strip():
        raise InsecureHostError("URL must be a non-empty string")
    if len(url) > settings.max_url_length:
        raise UrlTooLongError(
            f"URL exceeds the maximum allowed length of {settings.max_url_length} characters"
        )

    parts = urlsplit(url.strip())

    if parts.scheme.lower() not in ALLOWED_SCHEMES:
        raise InsecureHostError(f"Unsupported URL scheme: {parts.scheme!r}")
    if not parts.hostname:
        raise InsecureHostError(f"URL has no resolvable hostname: {url!r}")

    _reject_embedded_credentials(parts, url)

    hostname = parts.hostname.lower()
    if hostname == "localhost" or hostname.endswith(".localhost"):
        raise InsecureHostError(f"URL targets localhost: {url!r}")

    return parts


def resolve_and_validate_host(hostname: str, resolver: Resolver = _default_resolver) -> tuple[str, ...]:
    """Resolve ``hostname`` and confirm EVERY returned address is global.

    A hostname that resolves to multiple records where even one is
    internal is rejected outright -- partial trust is not allowed, since an
    attacker only needs one A/AAAA record to point somewhere sensitive.
    """
    raw_ips = resolver(hostname)
    if not raw_ips:
        raise InsecureHostError(f"Host {hostname!r} did not resolve to any IP address")

    validated: list[str] = []
    for raw_ip in raw_ips:
        try:
            ip_obj = ipaddress.ip_address(raw_ip)
        except ValueError as exc:
            raise InsecureHostError(
                f"Host {hostname!r} resolved to an unparsable address {raw_ip!r}"
            ) from exc
        if not is_global_ip(ip_obj):
            raise InsecureHostError(
                f"Host {hostname!r} resolves to a non-global address {raw_ip!r}; refusing to proceed"
            )
        validated.append(str(ip_obj))
    return tuple(validated)


def _probe(client: httpx.Client, url: str) -> httpx.Response:
    """HEAD the target; only fall back to a ranged GET (never downloading
    more than a single byte) when the server rejects HEAD outright. This
    keeps validation from ever pulling attacker-controlled response bodies
    into memory.

    Note: httpx eagerly parses a redirect's ``Location`` header into a URL
    internally (to populate ``response.next_request``) even though this
    client is configured with ``follow_redirects=False``. A malformed or
    hostile Location value (e.g. ``javascript:alert(1)``) therefore
    surfaces as ``httpx.InvalidURL`` -- which, unlike most httpx failures,
    does not subclass ``httpx.HTTPError`` -- rather than as a normal
    response we could inspect and reject ourselves. Both are treated as an
    unsafe target here.
    """
    try:
        response = client.request("HEAD", url)
    except (httpx.HTTPError, httpx.InvalidURL) as exc:
        raise InsecureHostError(f"Failed to reach {url!r} during redirect validation: {exc}") from exc

    if response.status_code == 405:
        try:
            response = client.request("GET", url, headers={"Range": "bytes=0-0"})
        except (httpx.HTTPError, httpx.InvalidURL) as exc:
            raise InsecureHostError(f"Failed to reach {url!r} during redirect validation: {exc}") from exc

    return response


def validate_url_security(
    url: str,
    *,
    resolver: Resolver = _default_resolver,
    http_client: httpx.Client | None = None,
) -> ValidatedURL:
    """Full pre-flight validation: format -> DNS/IP safety -> manual, bounded
    redirect walk (at most ``settings.max_redirects`` hops), re-validating
    hostname and resolved IPs at every hop, including the final one.

    ``http_client`` may be injected (e.g. an ``httpx.Client`` built on
    ``httpx.MockTransport`` in tests); when omitted, a client is created and
    closed internally.
    """
    parts = parse_and_check_format(url)
    hostname = parts.hostname.lower()  # type: ignore[union-attr]
    resolved_ips = resolve_and_validate_host(hostname, resolver=resolver)

    owns_client = http_client is None
    client = http_client or httpx.Client(
        timeout=settings.http_validation_timeout_s,
        follow_redirects=False,
        headers={"User-Agent": settings.http_user_agent},
    )

    current_url = url.strip()
    current_hostname = hostname
    current_ips = resolved_ips

    try:
        for hop in range(settings.max_redirects + 1):
            response = _probe(client, current_url)

            if not response.is_redirect:
                return ValidatedURL(url=current_url, hostname=current_hostname, resolved_ips=current_ips)

            if hop == settings.max_redirects:
                raise TooManyRedirectsError(
                    f"Redirect chain from {url!r} exceeded the maximum of "
                    f"{settings.max_redirects} hops"
                )

            location = response.headers.get("location")
            if not location:
                raise InsecureHostError(
                    f"Redirect response from {current_url!r} had no Location header"
                )

            next_url = str(httpx.URL(current_url).join(location))
            next_parts = parse_and_check_format(next_url)
            current_hostname = next_parts.hostname.lower()  # type: ignore[union-attr]
            current_ips = resolve_and_validate_host(current_hostname, resolver=resolver)
            current_url = next_url

        # Unreachable in practice: the loop body always returns or raises
        # on its final iteration. Kept as a safety net against future edits.
        raise TooManyRedirectsError(
            f"Redirect chain from {url!r} exceeded the maximum of {settings.max_redirects} hops"
        )
    finally:
        if owns_client:
            client.close()


def revalidate_before_navigation(
    validated: ValidatedURL, resolver: Resolver = _default_resolver
) -> tuple[str, ...]:
    """DNS-rebinding mitigation: call immediately before
    ``Playwright.page.goto()``. Re-resolves the already-validated hostname
    and raises :class:`InsecureHostError` if any current answer is no
    longer global-safe (e.g. an attacker rebound the domain to an internal
    address after the initial validation pass).

    This narrows, but per the module-level RESIDUAL RISK notes does not
    eliminate, the DNS-rebinding window.
    """
    return resolve_and_validate_host(validated.hostname, resolver=resolver)
