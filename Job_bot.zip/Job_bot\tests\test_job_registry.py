from __future__ import annotations

import pytest

import job_registry
from job_registry import (
    TOP_PRIORITY_BOARD_NAMES,
    JOB_BOARDS,
    _build_domain_index,
    GENERIC_FALLBACK_SELECTORS,
    find_job_board_by_name,
    list_supported_boards,
    lookup_job_board,
)
from models import JobBoardMetadata


# --------------------------- registry shape / integrity ------------------------

def test_registry_tracks_exactly_50_boards():
    assert len(JOB_BOARDS) == 50


def test_no_duplicate_canonical_domains_across_registry():
    all_domains = [d for board in JOB_BOARDS for d in board.canonical_domains]
    assert len(all_domains) == len(set(d.lower() for d in all_domains))


def test_board_names_are_unique():
    names = [board.name for board in JOB_BOARDS]
    assert len(names) == len(set(names))


@pytest.mark.parametrize(
    "required_name",
    [
        "LinkedIn",
        "Indeed",
        "ZipRecruiter",
        "Glassdoor",
        "Wellfound",
        "Otta",
        "Dice",
        "Built In",
        "Hired",
        "Reed",
        "StepStone",
        "InfoJobs",
        "Seek",
        "Naukri",
        "Saramin",
        "Boss Zhipin",
    ],
)
def test_required_named_boards_are_present(required_name):
    assert find_job_board_by_name(required_name) is not None


def test_every_board_is_a_valid_job_board_metadata_instance():
    for board in JOB_BOARDS:
        assert isinstance(board, JobBoardMetadata)
        assert board.canonical_domains
        assert board.target_selectors


# --------------------------- selector configuration -----------------------------

def test_top_priority_boards_have_customized_selectors():
    assert TOP_PRIORITY_BOARD_NAMES == {"LinkedIn", "Indeed", "Greenhouse", "Lever", "Workday"}
    for board in JOB_BOARDS:
        if board.name in TOP_PRIORITY_BOARD_NAMES:
            custom_prefix = board.target_selectors[: -len(GENERIC_FALLBACK_SELECTORS)]
            assert custom_prefix, f"{board.name} should have at least one custom selector"


def test_non_priority_boards_use_only_generic_fallback_selectors():
    for board in JOB_BOARDS:
        if board.name not in TOP_PRIORITY_BOARD_NAMES:
            assert board.target_selectors == list(GENERIC_FALLBACK_SELECTORS)


def test_every_board_selector_list_ends_with_generic_fallback_in_order():
    for board in JOB_BOARDS:
        assert board.target_selectors[-len(GENERIC_FALLBACK_SELECTORS):] == list(GENERIC_FALLBACK_SELECTORS)


# --------------------------- lookup_job_board ------------------------------------

@pytest.mark.parametrize(
    "url,expected_name",
    [
        ("https://www.linkedin.com/jobs/view/12345", "LinkedIn"),
        ("https://de.indeed.com/jobs?q=python", "Indeed"),
        ("https://boards.greenhouse.io/acme/jobs/999", "Greenhouse"),
        ("https://jobs.lever.co/acme/abc-123", "Lever"),
        ("https://acme.wd5.myworkdayjobs.com/en-US/External/job/1", "Workday"),
        ("https://www.reed.co.uk/jobs/senior-engineer/12345", "Reed"),
        ("https://www.seek.com.au/job/12345", "Seek"),
        ("https://www.zhipin.com/job_detail/abc.html", "Boss Zhipin"),
    ],
)
def test_lookup_job_board_matches_known_domains(url, expected_name):
    board = lookup_job_board(url)
    assert board is not None
    assert board.name == expected_name


def test_lookup_job_board_is_scheme_and_case_agnostic():
    assert lookup_job_board("HTTPS://WWW.LINKEDIN.COM/jobs/view/1").name == "LinkedIn"
    assert lookup_job_board("linkedin.com").name == "LinkedIn"
    assert lookup_job_board("www.linkedin.com").name == "LinkedIn"


def test_lookup_job_board_handles_deep_subdomains_for_ats_platforms():
    board = lookup_job_board("https://some-tenant.wd1.myworkdayjobs.com/careers/job/1")
    assert board is not None
    assert board.name == "Workday"


def test_lookup_job_board_returns_none_for_unknown_domain():
    assert lookup_job_board("https://careers.some-random-company.example/job/1") is None


@pytest.mark.parametrize("bad_input", ["", None, "   ", 12345])
def test_lookup_job_board_returns_none_for_invalid_input(bad_input):
    assert lookup_job_board(bad_input) is None  # type: ignore[arg-type]


# --------------------------- find_job_board_by_name -------------------------------

def test_find_job_board_by_name_matches_canonical_name_case_insensitively():
    assert find_job_board_by_name("linkedin").name == "LinkedIn"
    assert find_job_board_by_name("LINKEDIN").name == "LinkedIn"


def test_find_job_board_by_name_matches_alias():
    assert find_job_board_by_name("AngelList").name == "Wellfound"
    assert find_job_board_by_name("Zhipin").name == "Boss Zhipin"


def test_find_job_board_by_name_returns_none_for_unknown_name():
    assert find_job_board_by_name("Definitely Not A Real Board") is None


def test_find_job_board_by_name_returns_none_for_blank_name():
    assert find_job_board_by_name("") is None


# --------------------------- list_supported_boards ---------------------------------

def test_list_supported_boards_returns_full_registry():
    boards = list_supported_boards()
    assert len(boards) == 50
    assert boards == JOB_BOARDS


# --------------------------- domain index integrity helper -------------------------

def test_build_domain_index_raises_on_duplicate_domain():
    duplicate_boards = (
        JobBoardMetadata(
            name="Board A",
            canonical_domains=["shared-domain.example"],
            aliases=[],
            requires_javascript=False,
            target_selectors=["main"],
        ),
        JobBoardMetadata(
            name="Board B",
            canonical_domains=["shared-domain.example"],
            aliases=[],
            requires_javascript=False,
            target_selectors=["main"],
        ),
    )
    with pytest.raises(ValueError):
        _build_domain_index(duplicate_boards)


def test_build_domain_index_rejects_blank_domain():
    boards = (
        JobBoardMetadata(
            name="Board A",
            canonical_domains=["   "],
            aliases=[],
            requires_javascript=False,
            target_selectors=["main"],
        ),
    )
    with pytest.raises(ValueError):
        _build_domain_index(boards)
