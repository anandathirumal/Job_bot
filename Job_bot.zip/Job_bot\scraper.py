"""Headless scraping engine.

Every navigation goes through, in order:

1. **Pre-flight validation** (``url_security.validate_url_security``) --
   already done by the time a URL reaches this module in the normal flow;
   ``scrape_job_posting()`` calls it itself as the first step.
2. **DNS-rebinding recheck** (``url_security.revalidate_before_navigation``)
   immediately before ``page.goto()``.
3. **Bounded navigation** with ``wait_until="domcontentloaded"`` -- never
   ``"networkidle"``, which would hang indefinitely on any page with a
   long-lived connection (chat widgets, analytics beacons, websockets) and
   provides no additional safety.
4. **Selective subresource blocking** at the browser-route level (see
   ``_make_route_handler``): images/fonts/media/known-download-extensions
   are always blocked; first-party scripts/stylesheets/xhr/fetch are
   allowed (SPA-style boards need their own JS to render content at all);
   third-party ones in those categories are blocked as trackers; and every
   allowed request's literal target IP (if it's a literal IP rather than a
   name) is still checked against the same global-IP rule
   ``url_security.is_global_ip`` uses, closing the classic
   embedded-script-probes-169.254.169.254 metadata-SSRF vector even for
   first-party requests.
5. **Raw HTML size boundary** (``settings.max_html_bytes``) checked against
   the main navigation response body before anything else happens.
6. **Post-navigation hostname re-validation** -- if ``page.url`` ended up on
   a different host than the one ``url_security`` validated (a client-side
   JS redirect or meta-refresh that happened after our HTTP-level redirect
   walk), the new host is run back through ``resolve_and_validate_host``
   before any content is read.
7. **Anti-bot wall detection** before spending the selector-wait budget.
8. **Selector-ready wait** (``settings.selector_ready_timeout_s``, shared
   across the whole fallback chain from ``job_registry.py``) then text
   extraction, normalization, and truncation to
   ``settings.max_job_description_chars``.

``scrape_job_posting_with_retry()`` is the only entry point that retries,
and only for ``exceptions.TransientScrapingError`` -- at most
``settings.scrape_retry_limit`` times (1, per policy). Every other
exception type (``InsecureHostError``, ``AntiBotDetectedError``,
``DomStructureDriftError``, ``ResourceLimitExceededError``, ...) propagates
on the first occurrence, exactly once, with no retry.

RESIDUAL RISKS:

1. **Headless browser resource consumption.** Each call launches and tears
   down a full Chromium process. That is deliberate -- it avoids any state
   (cookies, cache, service workers) leaking between unrelated scrape
   targets -- but it means this module is not suited to high call volume
   without an external worker pool / concurrency limiter; nothing in this
   module throttles concurrent invocations itself.
2. **Subresource requests are not put through the full SSRF pipeline.**
   Only the main navigation target gets the complete
   ``url_security.validate_url_security`` treatment (DNS resolution +
   redirect walk). Allowed subresources (first-party script/style/xhr/
   fetch/document) only get the cheap, synchronous literal-IP/localhost
   check described above -- a full DNS-resolution-and-redirect-walk per
   subresource would be far too slow for a route handler firing dozens of
   times per page load. A malicious first-party script that names an
   *internal hostname* (not a literal IP) as a fetch target would resolve
   through the browser's own DNS and is not caught here.
3. **Anti-bot detection is a heuristic, not a guarantee.** The selector and
   title markers in ``_ANTI_BOT_SELECTORS`` / ``_ANTI_BOT_TITLE_MARKERS``
   reflect common challenge pages (Cloudflare, generic CAPTCHA walls) at
   the time this was written. Anti-bot vendors change their markup and
   copy; this list will need periodic revalidation, the same as
   ``job_registry.py``'s selectors.
4. **Server-side (HTTP 3xx) redirect hops within a single navigation are
   not individually intercepted by the route handler.** Empirically (and
   consistent with how Chromium's network stack handles a request that was
   ``route.continue_()``-ed), a redirect chain following the initial
   navigation request is followed internally by the browser without
   surfacing each hop back through ``context.route()`` -- only the first
   request of a navigation, and genuinely separate subresource requests
   (``<img>``, ``<script src>``, ``fetch()``, ``XHR``, ...) that the page
   itself initiates, get a route callback. This means the browser WILL
   fetch content from a redirect target before this module gets a chance
   to object. ``_reject_if_navigation_host_changed`` is therefore the real
   (and only) defense against a malicious same-navigation redirect, and it
   is necessarily point-in-time: it runs on ``page.url`` after
   ``domcontentloaded`` fires, so it can refuse to trust/return content
   that already loaded from an unsafe redirect target, but it cannot
   prevent that content from being fetched over the network in the first
   place, and it does not catch a redirect triggered by later JS (e.g. on a
   timer, or after this check already ran).
"""

from __future__ import annotations

import ipaddress
import re
import time
from typing import Optional, Sequence
from urllib.parse import urlsplit

import tldextract
from playwright.sync_api import Error as PlaywrightError
from playwright.sync_api import Route, sync_playwright
from playwright.sync_api import TimeoutError as PlaywrightTimeoutError

from config import settings
from exceptions import (
    AntiBotDetectedError,
    DomStructureDriftError,
    ResourceLimitExceededError,
    TransientScrapingError,
)
from job_registry import TOP_PRIORITY_BOARD_NAMES, GENERIC_FALLBACK_SELECTORS, lookup_job_board
from models import JobBoardMetadata, ScrapedJobPosting
from url_security import (
    Resolver,
    ValidatedURL,
    is_global_ip,
    parse_and_check_format,
    resolve_and_validate_host,
    revalidate_before_navigation,
    validate_url_security,
)

# Offline (see job_registry.py for the same pattern/rationale) -- used only
# to classify subresource request hosts as first- vs third-party.
_route_extractor = tldextract.TLDExtract(suffix_list_urls=())

_BLOCKED_RESOURCE_TYPES = frozenset({"image", "font", "media", "other", "texttrack"})
_PARTY_SENSITIVE_RESOURCE_TYPES = frozenset(
    {"script", "stylesheet", "xhr", "fetch", "eventsource", "websocket", "manifest"}
)
_DANGEROUS_EXTENSIONS = (
    ".exe", ".msi", ".dmg", ".pkg", ".zip", ".rar", ".7z", ".apk", ".bat", ".cmd", ".sh", ".iso", ".jar",
)

_ANTI_BOT_SELECTORS = (
    "#challenge-running",
    "#challenge-form",
    "#cf-challenge-running",
    'iframe[src*="recaptcha"]',
    'iframe[title*="recaptcha" i]',
    "div.g-recaptcha",
    'iframe[title*="challenge" i]',
)

# Deliberately checked against the page TITLE only, not full body text --
# body text on a legitimate job posting can incidentally contain phrases
# like "captcha" (e.g. a security-engineer job description) and would
# false-positive. Challenge-page titles are much more reliable signals.
_ANTI_BOT_TITLE_MARKERS = (
    "just a moment",
    "attention required",
    "access denied",
    "checking your browser",
    "are you a robot",
    "unusual traffic",
    "verify you are human",
)


def _has_dangerous_extension(url: str) -> bool:
    path = urlsplit(url).path.lower()
    return path.endswith(_DANGEROUS_EXTENSIONS)


def _request_target_is_unsafe(url: str) -> bool:
    """Cheap, synchronous safety check for a subresource request target.
    Only catches literal IPs and localhost -- see residual risk #2 above
    for why a full DNS-based check isn't done per-request.
    """
    hostname = urlsplit(url).hostname
    if not hostname:
        return True
    hostname = hostname.lower()
    if hostname == "localhost" or hostname.endswith(".localhost"):
        return True
    try:
        ip_obj = ipaddress.ip_address(hostname)
    except ValueError:
        return False
    return not is_global_ip(ip_obj)


def _make_route_handler(first_party_registered_domain: str, *, pre_approved_hostname: str):
    """``pre_approved_hostname`` is the navigation target's own hostname --
    the one that already passed the full ``url_security`` pipeline (DNS
    resolution, redirect walk, DNS-rebind recheck) before ``page.goto()``
    was ever called. Requests to exactly that hostname skip the cheap
    literal-IP/localhost check in :func:`_request_target_is_unsafe`, since
    it would otherwise flag a perfectly legitimate navigation target
    whenever that target happens to BE a literal IP address (which is a
    valid, if unusual, thing for a validated public IP to be).

    Every other request -- i.e. any subresource the page itself initiates
    (``<img>``, ``<script src>``, ``fetch()``, ``XHR``, ...) -- still gets
    the full check. Note this does NOT cover server-side HTTP redirect hops
    within the same navigation: Chromium follows those internally without
    re-invoking this handler (see the module docstring's residual risks);
    ``_reject_if_navigation_host_changed`` is what actually defends against
    a malicious same-navigation redirect, after the fact.
    """
    pre_approved_hostname = pre_approved_hostname.lower()

    def handler(route: Route) -> None:
        request = route.request
        url = request.url
        hostname = (urlsplit(url).hostname or "").lower()

        if request.resource_type in _BLOCKED_RESOURCE_TYPES:
            route.abort()
            return

        if _has_dangerous_extension(url):
            route.abort()
            return

        if hostname != pre_approved_hostname and _request_target_is_unsafe(url):
            route.abort()
            return

        if request.resource_type in _PARTY_SENSITIVE_RESOURCE_TYPES:
            request_domain = _route_extractor(url).top_domain_under_public_suffix
            if request_domain != first_party_registered_domain:
                route.abort()
                return

        route.continue_()

    return handler


def _detect_anti_bot_wall(page) -> Optional[str]:
    for selector in _ANTI_BOT_SELECTORS:
        try:
            if page.locator(selector).count() > 0:
                return f"anti-bot selector matched: {selector}"
        except PlaywrightError:
            continue

    title = (page.title() or "").lower()
    for marker in _ANTI_BOT_TITLE_MARKERS:
        if marker in title:
            return f"anti-bot marker in page title: {marker!r}"

    return None


def _wait_for_content_selector(page, selectors: Sequence[str], timeout_s: float) -> tuple[str, str]:
    """Try each selector in ``selectors`` in order, sharing one overall
    ``timeout_s`` budget across the whole fallback chain (not per-selector
    -- see module docstring / config.Settings.selector_ready_timeout_s).
    """
    deadline = time.monotonic() + timeout_s
    for selector in selectors:
        remaining_s = deadline - time.monotonic()
        if remaining_s <= 0:
            break
        remaining_ms = remaining_s * 1000
        try:
            locator = page.locator(selector).first
            locator.wait_for(state="attached", timeout=remaining_ms)
            text = locator.inner_text(timeout=max(deadline - time.monotonic(), 0) * 1000)
        except PlaywrightTimeoutError:
            continue
        except PlaywrightError:
            continue
        if text and text.strip():
            return selector, text

    raise DomStructureDriftError(
        f"None of the configured selectors matched rendered content within {timeout_s}s: {list(selectors)}"
    )


def _reject_if_navigation_host_changed(final_url: str, validated_hostname: str, *, resolver: Resolver) -> None:
    """Raise ``InsecureHostError`` if navigation ended up on a different
    host than the one ``url_security`` already validated -- a client-side
    redirect or meta-refresh the pre-flight HTTP redirect walk never saw.

    A no-op when the host is unchanged (the common case: same-host
    path/query changes don't need a fresh DNS round trip). Pulled out of
    :func:`_scrape_validated` as its own function specifically so it can be
    unit-tested directly against fake URLs and an injected resolver,
    without needing a real browser or DNS to exercise this exact branch.
    """
    final_hostname = urlsplit(final_url).hostname
    if not final_hostname or final_hostname.lower() == validated_hostname.lower():
        return
    parse_and_check_format(final_url)
    resolve_and_validate_host(final_hostname.lower(), resolver=resolver)


def _normalize_job_text(raw_text: str, max_chars: int) -> tuple[str, bool]:
    collapsed = re.sub(r"[ \t\f\v]+", " ", raw_text)
    collapsed = re.sub(r"\n{3,}", "\n\n", collapsed)
    collapsed = collapsed.strip()
    if len(collapsed) > max_chars:
        return collapsed[:max_chars].rstrip(), True
    return collapsed, False


def _scrape_validated(
    validated: ValidatedURL,
    board: Optional[JobBoardMetadata],
    *,
    source_url: str,
    resolver: Optional[Resolver] = None,
) -> ScrapedJobPosting:
    """Everything after pre-flight URL validation: launches its own
    browser/context/page, always torn down via ``finally``, and returns a
    populated :class:`ScrapedJobPosting`.

    Split out from :func:`scrape_job_posting` so tests can drive real
    Playwright navigation against a local fixture server with an injected
    ``resolver`` -- see ``url_security.py``'s own resolver-injection
    pattern -- without needing a ``ValidatedURL`` that would pass the real,
    internet-facing SSRF checks in ``validate_url_security``.
    """
    from url_security import _default_resolver  # local import: keep the public API's default explicit

    resolve = resolver or _default_resolver
    selectors = board.target_selectors if board is not None else list(GENERIC_FALLBACK_SELECTORS)
    registered_domain = _route_extractor(validated.hostname).top_domain_under_public_suffix

    with sync_playwright() as playwright:
        browser = playwright.chromium.launch(headless=True)
        try:
            context = browser.new_context(user_agent=settings.http_user_agent)
            try:
                context.route(
                    "**/*", _make_route_handler(registered_domain, pre_approved_hostname=validated.hostname)
                )
                page = context.new_page()

                revalidate_before_navigation(validated, resolver=resolve)

                try:
                    response = page.goto(
                        validated.url,
                        wait_until="domcontentloaded",
                        timeout=settings.browser_navigation_timeout_s * 1000,
                    )
                except PlaywrightTimeoutError as exc:
                    raise TransientScrapingError(
                        f"Navigation to {validated.url!r} timed out after "
                        f"{settings.browser_navigation_timeout_s}s: {exc}"
                    ) from exc
                except PlaywrightError as exc:
                    raise TransientScrapingError(f"Navigation to {validated.url!r} failed: {exc}") from exc

                if response is None:
                    raise TransientScrapingError(f"Navigation to {validated.url!r} produced no response")

                body = response.body()
                if len(body) > settings.max_html_bytes:
                    raise ResourceLimitExceededError(
                        f"Raw HTML response ({len(body)} bytes) from {validated.url!r} exceeds "
                        f"the {settings.max_html_bytes}-byte limit"
                    )

                _reject_if_navigation_host_changed(page.url, validated.hostname, resolver=resolve)

                anti_bot_reason = _detect_anti_bot_wall(page)
                if anti_bot_reason:
                    raise AntiBotDetectedError(f"{validated.url!r}: {anti_bot_reason}")

                try:
                    matched_selector, raw_text = _wait_for_content_selector(
                        page, selectors, settings.selector_ready_timeout_s
                    )
                except DomStructureDriftError:
                    if board is not None and board.name in TOP_PRIORITY_BOARD_NAMES:
                        raise DomStructureDriftError(
                            f"{board.name}'s customized selector path (and the generic fallback "
                            f"chain) failed to match on {validated.url!r} -- this board's markup "
                            f"has likely drifted; job_registry.py needs revalidation."
                        ) from None
                    raise

                normalized_text, truncated = _normalize_job_text(raw_text, settings.max_job_description_chars)

                return ScrapedJobPosting(
                    source_url=source_url,
                    final_url=page.url,
                    job_board_name=board.name if board is not None else None,
                    matched_selector=matched_selector,
                    raw_html_bytes=len(body),
                    normalized_text=normalized_text,
                    truncated=truncated,
                )
            finally:
                context.close()
        finally:
            browser.close()


def scrape_job_posting(url: str) -> ScrapedJobPosting:
    """Full pipeline: pre-flight SSRF validation, then
    :func:`_scrape_validated`. This is the entry point production code
    should call -- it never accepts a pre-built ``ValidatedURL`` or a
    custom resolver, so it can't accidentally skip real DNS-backed safety
    checks the way the test-only seam in :func:`_scrape_validated` can.
    """
    validated = validate_url_security(url)
    board = lookup_job_board(validated.url)
    return _scrape_validated(validated, board, source_url=url)


def scrape_job_posting_with_retry(url: str) -> ScrapedJobPosting:
    """The only retrying entry point, and only for
    ``exceptions.TransientScrapingError`` -- at most
    ``settings.scrape_retry_limit`` retries (1, per policy). Every other
    exception type propagates immediately on first occurrence.
    """
    attempts = settings.scrape_retry_limit + 1
    last_error: Optional[TransientScrapingError] = None

    for attempt in range(attempts):
        try:
            return scrape_job_posting(url)
        except TransientScrapingError as exc:
            last_error = exc
            if attempt == attempts - 1:
                raise

    raise last_error  # pragma: no cover -- unreachable, loop always returns or raises
