from __future__ import annotations

import pytest
import httpx

from config import settings
from exceptions import InsecureHostError, TooManyRedirectsError, UrlTooLongError
from url_security import (
    ValidatedURL,
    parse_and_check_format,
    resolve_and_validate_host,
    revalidate_before_navigation,
    validate_url_security,
)


def _resolver(mapping: dict[str, list[str]]):
    def _resolve(hostname: str) -> list[str]:
        try:
            return mapping[hostname]
        except KeyError:
            raise AssertionError(f"unexpected DNS lookup for {hostname!r}")

    return _resolve


def _mock_transport(routes: dict[str, httpx.Response]) -> httpx.MockTransport:
    def handler(request: httpx.Request) -> httpx.Response:
        key = str(request.url)
        if key not in routes:
            raise AssertionError(f"unexpected request to {key!r}")
        return routes[key]

    return httpx.MockTransport(handler)


# --------------------------- format validation ------------------------------

def test_rejects_url_over_max_length():
    long_url = "https://example.com/" + "a" * settings.max_url_length
    with pytest.raises(UrlTooLongError):
        parse_and_check_format(long_url)


def test_rejects_empty_url():
    with pytest.raises(InsecureHostError):
        parse_and_check_format("   ")


@pytest.mark.parametrize(
    "url",
    [
        "ftp://example.com/resource",
        "file:///etc/passwd",
        "javascript:alert(1)",
        "data:text/html,<script>alert(1)</script>",
    ],
)
def test_rejects_disallowed_schemes(url):
    with pytest.raises(InsecureHostError):
        parse_and_check_format(url)


def test_rejects_embedded_credentials():
    with pytest.raises(InsecureHostError):
        parse_and_check_format("https://user:pass@example.com/jobs/1")


@pytest.mark.parametrize(
    "url",
    [
        "https://localhost/jobs",
        "https://sub.localhost/jobs",
        "http://LOCALHOST/jobs",
    ],
)
def test_rejects_localhost(url):
    with pytest.raises(InsecureHostError):
        parse_and_check_format(url)


def test_accepts_well_formed_https_url():
    parts = parse_and_check_format("https://boards.example.com/jobs/123")
    assert parts.hostname == "boards.example.com"


# --------------------------- DNS / IP validation -----------------------------

@pytest.mark.parametrize(
    "bad_ip",
    [
        "127.0.0.1",  # loopback
        "10.0.0.5",  # RFC1918 private
        "172.16.0.5",  # RFC1918 private
        "192.168.1.5",  # RFC1918 private
        "169.254.1.1",  # link-local
        "224.0.0.1",  # multicast
        "0.0.0.0",  # unspecified
        "::1",  # IPv6 loopback
        "fc00::1",  # IPv6 unique local
        "fe80::1",  # IPv6 link-local
    ],
)
def test_rejects_non_global_resolved_ip(bad_ip):
    resolver = _resolver({"evil.example.com": [bad_ip]})
    with pytest.raises(InsecureHostError):
        resolve_and_validate_host("evil.example.com", resolver=resolver)


def test_accepts_global_resolved_ip():
    resolver = _resolver({"good.example.com": ["93.184.216.34"]})
    ips = resolve_and_validate_host("good.example.com", resolver=resolver)
    assert ips == ("93.184.216.34",)


def test_rejects_when_any_resolved_ip_is_unsafe():
    # A hostname resolving to multiple A/AAAA records where even one is
    # internal must be rejected outright -- partial trust is not allowed.
    resolver = _resolver({"multi.example.com": ["93.184.216.34", "10.0.0.1"]})
    with pytest.raises(InsecureHostError):
        resolve_and_validate_host("multi.example.com", resolver=resolver)


def test_rejects_host_with_no_dns_records():
    resolver = _resolver({"empty.example.com": []})
    with pytest.raises(InsecureHostError):
        resolve_and_validate_host("empty.example.com", resolver=resolver)


def test_raises_when_dns_resolution_fails():
    def _resolve(hostname: str) -> list[str]:
        raise InsecureHostError("simulated resolution failure")

    with pytest.raises(InsecureHostError):
        resolve_and_validate_host("nowhere.example.com", resolver=_resolve)


# --------------------------- redirect chain walking ---------------------------

def test_validate_url_security_no_redirect():
    resolver = _resolver({"jobs.example.com": ["93.184.216.34"]})
    routes = {"https://jobs.example.com/posting/1": httpx.Response(200)}
    client = httpx.Client(transport=_mock_transport(routes))

    result = validate_url_security(
        "https://jobs.example.com/posting/1", resolver=resolver, http_client=client
    )

    assert isinstance(result, ValidatedURL)
    assert result.url == "https://jobs.example.com/posting/1"
    assert result.hostname == "jobs.example.com"
    assert result.resolved_ips == ("93.184.216.34",)


def test_validate_url_security_follows_up_to_three_redirects():
    resolver = _resolver(
        {
            "hop0.example.com": ["93.184.216.1"],
            "hop1.example.com": ["93.184.216.2"],
            "hop2.example.com": ["93.184.216.3"],
            "final.example.com": ["93.184.216.4"],
        }
    )
    routes = {
        "https://hop0.example.com/": httpx.Response(302, headers={"location": "https://hop1.example.com/"}),
        "https://hop1.example.com/": httpx.Response(302, headers={"location": "https://hop2.example.com/"}),
        "https://hop2.example.com/": httpx.Response(302, headers={"location": "https://final.example.com/"}),
        "https://final.example.com/": httpx.Response(200),
    }
    client = httpx.Client(transport=_mock_transport(routes))

    result = validate_url_security("https://hop0.example.com/", resolver=resolver, http_client=client)

    assert result.url == "https://final.example.com/"
    assert result.hostname == "final.example.com"


def test_validate_url_security_rejects_fourth_redirect():
    resolver = _resolver({f"hop{i}.example.com": [f"93.184.216.{i}"] for i in range(5)})
    routes = {
        f"https://hop{i}.example.com/": httpx.Response(
            302, headers={"location": f"https://hop{i + 1}.example.com/"}
        )
        for i in range(4)
    }
    client = httpx.Client(transport=_mock_transport(routes))

    with pytest.raises(TooManyRedirectsError):
        validate_url_security("https://hop0.example.com/", resolver=resolver, http_client=client)


def test_validate_url_security_rejects_redirect_into_private_network():
    resolver = _resolver(
        {
            "public.example.com": ["93.184.216.34"],
            "internal.example.com": ["10.0.0.7"],
        }
    )
    routes = {
        "https://public.example.com/": httpx.Response(
            302, headers={"location": "https://internal.example.com/"}
        ),
    }
    client = httpx.Client(transport=_mock_transport(routes))

    with pytest.raises(InsecureHostError):
        validate_url_security("https://public.example.com/", resolver=resolver, http_client=client)


def test_validate_url_security_rejects_redirect_with_missing_location():
    resolver = _resolver({"public.example.com": ["93.184.216.34"]})
    routes = {"https://public.example.com/": httpx.Response(302)}
    client = httpx.Client(transport=_mock_transport(routes))

    with pytest.raises(InsecureHostError):
        validate_url_security("https://public.example.com/", resolver=resolver, http_client=client)


def test_validate_url_security_falls_back_to_ranged_get_when_head_unsupported():
    resolver = _resolver({"nohead.example.com": ["93.184.216.34"]})

    def handler(request: httpx.Request) -> httpx.Response:
        if request.method == "HEAD":
            return httpx.Response(405)
        assert request.headers.get("range") == "bytes=0-0"
        return httpx.Response(200)

    client = httpx.Client(transport=httpx.MockTransport(handler))

    result = validate_url_security("https://nohead.example.com/", resolver=resolver, http_client=client)
    assert result.hostname == "nohead.example.com"


def test_validate_url_security_propagates_url_format_errors_on_redirect_target():
    resolver = _resolver({"public.example.com": ["93.184.216.34"]})
    routes = {
        "https://public.example.com/": httpx.Response(
            302, headers={"location": "javascript:alert(1)"}
        ),
    }
    client = httpx.Client(transport=_mock_transport(routes))

    with pytest.raises(InsecureHostError):
        validate_url_security("https://public.example.com/", resolver=resolver, http_client=client)


# --------------------------- revalidation (DNS rebinding) ---------------------

def test_revalidate_before_navigation_passes_when_dns_unchanged():
    validated = ValidatedURL(
        url="https://jobs.example.com/1", hostname="jobs.example.com", resolved_ips=("93.184.216.34",)
    )
    resolver = _resolver({"jobs.example.com": ["93.184.216.34"]})
    ips = revalidate_before_navigation(validated, resolver=resolver)
    assert ips == ("93.184.216.34",)


def test_revalidate_before_navigation_catches_rebind_to_private_ip():
    validated = ValidatedURL(
        url="https://jobs.example.com/1", hostname="jobs.example.com", resolved_ips=("93.184.216.34",)
    )
    # Simulates DNS rebinding: the attacker's authoritative server now
    # answers with an internal address for the same hostname.
    resolver = _resolver({"jobs.example.com": ["127.0.0.1"]})
    with pytest.raises(InsecureHostError):
        revalidate_before_navigation(validated, resolver=resolver)
