<#
.SYNOPSIS
    Runs Job_bot's Streamlit app using the virtual environment created by
    install.ps1.
#>

$ErrorActionPreference = "Stop"

$repoRoot = $PSScriptRoot
$venvStreamlit = Join-Path $repoRoot ".venv\Scripts\streamlit.exe"

if (-not (Test-Path $venvStreamlit)) {
    Write-Host "Virtual environment not found. Run install.ps1 first:" -ForegroundColor Red
    Write-Host "  powershell -ExecutionPolicy Bypass -File install.ps1"
    exit 1
}

Set-Location $repoRoot

# --server.headless true is required on a genuinely fresh install, not just
# a convenience: without it, Streamlit's first run blocks on an interactive
# "Welcome to Streamlit! ... Email:" onboarding prompt on the console before
# it ever starts the server, which looks like a hang.
$env:STREAMLIT_BROWSER_GATHER_USAGE_STATS = "false"
& $venvStreamlit run app.py --server.headless true
