"""Static registry of the 50 job boards this application knows how to
scrape, plus hostname/URL -> board lookup.

Domain parsing uses ``tldextract`` so subdomains and multi-part public
suffixes are separated correctly (``jobs.lever.co`` -> domain ``lever``,
suffix ``co``; ``www.reed.co.uk`` -> domain ``reed``, suffix ``co.uk``;
``acme.wd5.myworkdayjobs.com`` -> domain ``myworkdayjobs``, suffix ``com``,
with the tenant/region prefix folded into the subdomain). Lookup is keyed
on the resulting registrable domain (``top_domain_under_public_suffix``),
never on the raw hostname string, so an arbitrary subdomain a company puts
in front of an ATS platform (e.g. a Workday or Greenhouse tenant) still
resolves to the right board.

The extractor is configured with ``suffix_list_urls=()``, which forces
``tldextract`` to use only the Public Suffix List snapshot bundled with the
installed package version rather than fetching a live copy over the
network on first use. This keeps domain parsing deterministic and fully
offline -- consistent with the rest of this codebase's hardened, no-surprise-
network-calls posture -- at the cost of the snapshot slowly going stale as
new public suffixes are added upstream. Bumping the pinned ``tldextract``
version in ``pyproject.toml`` is the intended way to refresh it.

RESIDUAL RISK -- ``requires_javascript`` and ``target_selectors`` below are
best-effort operational defaults based on each board's publicly observable
behavior at the time this registry was written, not a guarantee. Every job
board redesigns its frontend on its own schedule; ``target_selectors`` WILL
drift out of date for some board eventually, which is exactly the "brittle
third-party DOM structure drift" risk called out at the top level of this
project. ``scraper.py`` is expected to treat every selector list here as
best-effort-with-fallback (see ``GENERIC_FALLBACK_SELECTORS``), raise
``exceptions.DomStructureDriftError`` when even the fallbacks don't match,
and this file is expected to need periodic manual revalidation against the
live sites -- there is no automated drift detection here.
"""

from __future__ import annotations

from typing import Optional, Sequence

import tldextract

from models import JobBoardMetadata

# Offline-only: never fetches the Public Suffix List over the network (see
# module docstring). Reused across calls -- constructing a TLDExtract loads
# and parses the snapshot once.
_extractor = tldextract.TLDExtract(suffix_list_urls=())

# Applied after any board-specific selectors, and used verbatim for the 45
# boards that don't have a customized selector path. Ordered from most to
# least specific; scraper.py tries each in turn against the rendered DOM.
GENERIC_FALLBACK_SELECTORS: tuple[str, ...] = (
    "main",
    "article",
    '[class*="job-description"]',
)


def _selectors(*custom: str) -> list[str]:
    """Custom selectors first, generic fallbacks appended so DOM drift on
    the custom path still has somewhere to land.
    """
    return [*custom, *GENERIC_FALLBACK_SELECTORS]


# ---------------------------------------------------------------------------
# The 50-board registry.
#
# Grouped for auditability: global general-purpose (10), niche/tech (10),
# regional -- Europe/EMEA (10), regional -- Asia-Pacific (10), regional --
# Americas (5), ATS-hosted aggregator platforms (5). = 50 total, enforced
# by an assertion at the bottom of this module.
#
# Only the five highest-traffic domains (LinkedIn, Indeed, Greenhouse,
# Lever, Workday) get customized selector paths; every other board uses
# GENERIC_FALLBACK_SELECTORS verbatim.
# ---------------------------------------------------------------------------

JOB_BOARDS: tuple[JobBoardMetadata, ...] = (
    # --- Global general-purpose (10) ---------------------------------------
    JobBoardMetadata(
        name="LinkedIn",
        canonical_domains=["linkedin.com"],
        aliases=["LinkedIn Jobs"],
        requires_javascript=True,
        target_selectors=_selectors(
            "div.description__text",
            "div.show-more-less-html__markup",
        ),
    ),
    JobBoardMetadata(
        name="Indeed",
        canonical_domains=["indeed.com", "indeed.co.uk", "indeed.de", "indeed.ca", "indeed.com.au"],
        aliases=[],
        requires_javascript=True,
        target_selectors=_selectors(
            "div#jobDescriptionText",
            '[id*="jobDescriptionText"]',
        ),
    ),
    JobBoardMetadata(
        name="ZipRecruiter",
        canonical_domains=["ziprecruiter.com"],
        aliases=[],
        requires_javascript=True,
        target_selectors=_selectors(),
    ),
    JobBoardMetadata(
        name="Glassdoor",
        canonical_domains=["glassdoor.com", "glassdoor.co.uk", "glassdoor.de", "glassdoor.ca"],
        aliases=[],
        requires_javascript=True,
        target_selectors=_selectors(),
    ),
    JobBoardMetadata(
        name="Monster",
        canonical_domains=["monster.com", "monster.co.uk", "monster.de"],
        aliases=[],
        requires_javascript=False,
        target_selectors=_selectors(),
    ),
    JobBoardMetadata(
        name="CareerBuilder",
        canonical_domains=["careerbuilder.com"],
        aliases=[],
        requires_javascript=False,
        target_selectors=_selectors(),
    ),
    JobBoardMetadata(
        name="SimplyHired",
        canonical_domains=["simplyhired.com"],
        aliases=[],
        requires_javascript=False,
        target_selectors=_selectors(),
    ),
    JobBoardMetadata(
        name="Adzuna",
        canonical_domains=["adzuna.com", "adzuna.co.uk"],
        aliases=[],
        requires_javascript=False,
        target_selectors=_selectors(),
    ),
    JobBoardMetadata(
        name="Jooble",
        canonical_domains=["jooble.org"],
        aliases=[],
        requires_javascript=False,
        target_selectors=_selectors(),
    ),
    JobBoardMetadata(
        name="Jora",
        canonical_domains=["jora.com"],
        aliases=[],
        requires_javascript=False,
        target_selectors=_selectors(),
    ),
    # --- Niche / tech (10) --------------------------------------------------
    JobBoardMetadata(
        name="Wellfound",
        canonical_domains=["wellfound.com"],
        aliases=["AngelList Talent", "AngelList"],
        requires_javascript=True,
        target_selectors=_selectors(),
    ),
    JobBoardMetadata(
        name="Otta",
        canonical_domains=["otta.com"],
        aliases=[],
        requires_javascript=True,
        target_selectors=_selectors(),
    ),
    JobBoardMetadata(
        name="Dice",
        canonical_domains=["dice.com"],
        aliases=[],
        requires_javascript=False,
        target_selectors=_selectors(),
    ),
    JobBoardMetadata(
        name="Built In",
        canonical_domains=["builtin.com"],
        aliases=["BuiltIn"],
        requires_javascript=True,
        target_selectors=_selectors(),
    ),
    JobBoardMetadata(
        name="Hired",
        canonical_domains=["hired.com"],
        aliases=[],
        requires_javascript=True,
        target_selectors=_selectors(),
    ),
    JobBoardMetadata(
        name="Work at a Startup",
        canonical_domains=["workatastartup.com"],
        aliases=["Y Combinator Work at a Startup", "YC Work at a Startup"],
        requires_javascript=True,
        target_selectors=_selectors(),
    ),
    JobBoardMetadata(
        name="RemoteOK",
        canonical_domains=["remoteok.com"],
        aliases=["Remote OK"],
        requires_javascript=False,
        target_selectors=_selectors(),
    ),
    JobBoardMetadata(
        name="We Work Remotely",
        canonical_domains=["weworkremotely.com"],
        aliases=["WeWorkRemotely"],
        requires_javascript=False,
        target_selectors=_selectors(),
    ),
    JobBoardMetadata(
        name="Remotive",
        canonical_domains=["remotive.com"],
        aliases=[],
        requires_javascript=False,
        target_selectors=_selectors(),
    ),
    JobBoardMetadata(
        name="Himalayas",
        canonical_domains=["himalayas.app"],
        aliases=[],
        requires_javascript=True,
        target_selectors=_selectors(),
    ),
    # --- Regional -- Europe / EMEA (10) -------------------------------------
    JobBoardMetadata(
        name="Reed",
        canonical_domains=["reed.co.uk"],
        aliases=[],
        requires_javascript=False,
        target_selectors=_selectors(),
    ),
    JobBoardMetadata(
        name="StepStone",
        canonical_domains=["stepstone.de", "stepstone.com"],
        aliases=[],
        requires_javascript=True,
        target_selectors=_selectors(),
    ),
    JobBoardMetadata(
        name="InfoJobs",
        canonical_domains=["infojobs.net"],
        aliases=[],
        requires_javascript=False,
        target_selectors=_selectors(),
    ),
    JobBoardMetadata(
        name="Xing Jobs",
        canonical_domains=["xing.com"],
        aliases=["Xing"],
        requires_javascript=True,
        target_selectors=_selectors(),
    ),
    JobBoardMetadata(
        name="APEC",
        canonical_domains=["apec.fr"],
        aliases=[],
        requires_javascript=False,
        target_selectors=_selectors(),
    ),
    JobBoardMetadata(
        name="France Travail",
        canonical_domains=["francetravail.fr"],
        aliases=["Pole Emploi", "Pôle emploi"],
        requires_javascript=False,
        target_selectors=_selectors(),
    ),
    JobBoardMetadata(
        name="Jobs.ch",
        canonical_domains=["jobs.ch"],
        aliases=[],
        requires_javascript=False,
        target_selectors=_selectors(),
    ),
    JobBoardMetadata(
        name="Totaljobs",
        canonical_domains=["totaljobs.com"],
        aliases=[],
        requires_javascript=False,
        target_selectors=_selectors(),
    ),
    JobBoardMetadata(
        name="CV-Library",
        canonical_domains=["cv-library.co.uk"],
        aliases=["CV Library"],
        requires_javascript=False,
        target_selectors=_selectors(),
    ),
    JobBoardMetadata(
        name="Trabajos.com",
        canonical_domains=["trabajos.com"],
        aliases=[],
        requires_javascript=False,
        target_selectors=_selectors(),
    ),
    # --- Regional -- Asia-Pacific (10) ---------------------------------------
    JobBoardMetadata(
        name="Seek",
        canonical_domains=["seek.com.au", "seek.co.nz"],
        aliases=[],
        requires_javascript=True,
        target_selectors=_selectors(),
    ),
    JobBoardMetadata(
        name="Naukri",
        canonical_domains=["naukri.com"],
        aliases=[],
        requires_javascript=True,
        target_selectors=_selectors(),
    ),
    JobBoardMetadata(
        name="Shine",
        canonical_domains=["shine.com"],
        aliases=[],
        requires_javascript=False,
        target_selectors=_selectors(),
    ),
    JobBoardMetadata(
        name="TimesJobs",
        canonical_domains=["timesjobs.com"],
        aliases=[],
        requires_javascript=False,
        target_selectors=_selectors(),
    ),
    JobBoardMetadata(
        name="Saramin",
        canonical_domains=["saramin.co.kr"],
        aliases=[],
        requires_javascript=True,
        target_selectors=_selectors(),
    ),
    JobBoardMetadata(
        name="JobKorea",
        canonical_domains=["jobkorea.co.kr"],
        aliases=[],
        requires_javascript=True,
        target_selectors=_selectors(),
    ),
    JobBoardMetadata(
        name="Boss Zhipin",
        canonical_domains=["zhipin.com"],
        aliases=["Zhipin", "BOSS直聘"],
        requires_javascript=True,
        target_selectors=_selectors(),
    ),
    JobBoardMetadata(
        name="51job",
        canonical_domains=["51job.com"],
        aliases=["Qiancheng Wuyou", "前程无忧"],
        requires_javascript=True,
        target_selectors=_selectors(),
    ),
    JobBoardMetadata(
        name="Liepin",
        canonical_domains=["liepin.com"],
        aliases=[],
        requires_javascript=True,
        target_selectors=_selectors(),
    ),
    JobBoardMetadata(
        name="JobStreet",
        canonical_domains=["jobstreet.com"],
        aliases=[],
        requires_javascript=True,
        target_selectors=_selectors(),
    ),
    # --- Regional -- Americas (5) --------------------------------------------
    JobBoardMetadata(
        name="CompuTrabajo",
        canonical_domains=["computrabajo.com"],
        aliases=[],
        requires_javascript=True,
        target_selectors=_selectors(),
    ),
    JobBoardMetadata(
        name="Catho",
        canonical_domains=["catho.com.br"],
        aliases=[],
        requires_javascript=True,
        target_selectors=_selectors(),
    ),
    JobBoardMetadata(
        name="Job Bank Canada",
        canonical_domains=["jobbank.gc.ca"],
        aliases=["Guichet Emplois"],
        requires_javascript=False,
        target_selectors=_selectors(),
    ),
    JobBoardMetadata(
        name="Eluta",
        canonical_domains=["eluta.ca"],
        aliases=[],
        requires_javascript=False,
        target_selectors=_selectors(),
    ),
    JobBoardMetadata(
        name="USAJobs",
        canonical_domains=["usajobs.gov"],
        aliases=["USA Jobs"],
        requires_javascript=False,
        target_selectors=_selectors(),
    ),
    # --- ATS-hosted aggregator platforms (5) ----------------------------------
    # Countless companies post directly through these platforms under their
    # own tenant subdomain (e.g. boards.greenhouse.io/<company>,
    # jobs.lever.co/<company>, <company>.myworkdayjobs.com) -- in practice a
    # large share of pasted job URLs will resolve to one of these five, not
    # to a traditional "job board" brand.
    JobBoardMetadata(
        name="Greenhouse",
        canonical_domains=["greenhouse.io"],
        aliases=[],
        requires_javascript=False,
        target_selectors=_selectors(
            "div#content",
            "div.job__description",
        ),
    ),
    JobBoardMetadata(
        name="Lever",
        canonical_domains=["lever.co"],
        aliases=[],
        requires_javascript=False,
        target_selectors=_selectors(
            "div.section-wrapper.page-full-width",
            '[data-qa="job-description"]',
        ),
    ),
    JobBoardMetadata(
        name="Workday",
        canonical_domains=["myworkdayjobs.com", "workday.com"],
        aliases=["Workday Careers"],
        requires_javascript=True,
        target_selectors=_selectors(
            '[data-automation-id="jobPostingDescription"]',
        ),
    ),
    JobBoardMetadata(
        name="iCIMS",
        canonical_domains=["icims.com"],
        aliases=[],
        requires_javascript=True,
        target_selectors=_selectors(),
    ),
    JobBoardMetadata(
        name="SmartRecruiters",
        canonical_domains=["smartrecruiters.com"],
        aliases=[],
        requires_javascript=True,
        target_selectors=_selectors(),
    ),
)

# Board names that received a customized selector path above; scraper.py
# can use this to decide whether a selector-match failure is "expected
# fallback territory" (any other board) or "our best-effort custom path
# just drifted" (one of these five).
TOP_PRIORITY_BOARD_NAMES: frozenset[str] = frozenset(
    {"LinkedIn", "Indeed", "Greenhouse", "Lever", "Workday"}
)


def _build_domain_index(boards: Sequence[JobBoardMetadata]) -> dict[str, JobBoardMetadata]:
    index: dict[str, JobBoardMetadata] = {}
    for board in boards:
        for domain in board.canonical_domains:
            key = domain.strip().lower()
            if not key:
                raise ValueError(f"{board.name!r} declares a blank canonical domain")
            if key in index:
                raise ValueError(
                    f"Duplicate canonical domain {key!r} claimed by both "
                    f"{index[key].name!r} and {board.name!r}"
                )
            index[key] = board
    return index


_DOMAIN_INDEX: dict[str, JobBoardMetadata] = _build_domain_index(JOB_BOARDS)

assert len(JOB_BOARDS) == 50, f"job_registry must track exactly 50 boards, found {len(JOB_BOARDS)}"


def lookup_job_board(url_or_hostname: str) -> Optional[JobBoardMetadata]:
    """Resolve a URL or bare hostname to its registered job board, using the
    registrable domain (subdomain- and suffix-aware) rather than a naive
    substring match. Returns ``None`` for anything not in the registry --
    callers fall back to the generic selector chain via ``job_registry``'s
    own default, or treat the site as fully unsupported, as appropriate.
    """
    if not url_or_hostname or not isinstance(url_or_hostname, str):
        return None

    extracted = _extractor(url_or_hostname.strip())
    registered_domain = extracted.top_domain_under_public_suffix
    if not registered_domain:
        return None

    return _DOMAIN_INDEX.get(registered_domain.lower())


def find_job_board_by_name(name: str) -> Optional[JobBoardMetadata]:
    """Look up a board by its canonical name or any registered alias,
    case-insensitively. Useful for UI-driven selection rather than URL
    parsing.
    """
    if not name:
        return None
    needle = name.strip().lower()
    for board in JOB_BOARDS:
        if board.name.lower() == needle:
            return board
        if needle in {alias.lower() for alias in board.aliases}:
            return board
    return None


def list_supported_boards() -> tuple[JobBoardMetadata, ...]:
    return JOB_BOARDS
