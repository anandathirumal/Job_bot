from __future__ import annotations

import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Optional
from unittest.mock import MagicMock

import pytest

import scraper
from exceptions import (
    AntiBotDetectedError,
    DomStructureDriftError,
    InsecureHostError,
    ResourceLimitExceededError,
    TransientScrapingError,
)
from job_registry import JOB_BOARDS
from models import JobBoardMetadata
from url_security import ValidatedURL


# =============================================================================
# Unit tests -- pure functions / mocked Playwright objects, no browser needed.
# =============================================================================

# --------------------------- _has_dangerous_extension ------------------------

@pytest.mark.parametrize(
    "url",
    [
        "https://example.com/download/malware.exe",
        "https://example.com/files/archive.zip",
        "https://example.com/setup.MSI",  # case-insensitive
        "https://example.com/app.dmg?token=abc",
    ],
)
def test_has_dangerous_extension_true(url):
    assert scraper._has_dangerous_extension(url) is True


@pytest.mark.parametrize(
    "url",
    [
        "https://example.com/jobs/123",
        "https://example.com/script.js",
        "https://example.com/style.css",
        "https://example.com/api/data.json",
    ],
)
def test_has_dangerous_extension_false(url):
    assert scraper._has_dangerous_extension(url) is False


# --------------------------- _request_target_is_unsafe -----------------------

@pytest.mark.parametrize(
    "url",
    [
        "http://localhost/beacon",
        "http://sub.localhost/beacon",
        "http://127.0.0.1/beacon",
        "http://169.254.169.254/latest/meta-data/",  # cloud metadata SSRF target
        "http://10.0.0.5/internal",
        "http://[::1]/beacon",
    ],
)
def test_request_target_is_unsafe_true(url):
    assert scraper._request_target_is_unsafe(url) is True


@pytest.mark.parametrize(
    "url",
    [
        "https://boards.greenhouse.io/acme/jobs/1",
        "https://93.184.216.34/beacon",  # literal but global IP
        "https://cdn.example.com/app.js",
    ],
)
def test_request_target_is_unsafe_false(url):
    assert scraper._request_target_is_unsafe(url) is False


# --------------------------- _normalize_job_text ------------------------------

def test_normalize_job_text_collapses_whitespace():
    raw = "We need   a Python   engineer.\n\n\n\nApply now."
    normalized, truncated = scraper._normalize_job_text(raw, max_chars=1000)
    assert "   " not in normalized
    assert "\n\n\n" not in normalized
    assert truncated is False


def test_normalize_job_text_truncates_when_over_limit():
    raw = "x" * 200
    normalized, truncated = scraper._normalize_job_text(raw, max_chars=50)
    assert len(normalized) <= 50
    assert truncated is True


def test_normalize_job_text_no_truncation_when_under_limit():
    raw = "short description"
    normalized, truncated = scraper._normalize_job_text(raw, max_chars=1000)
    assert normalized == raw
    assert truncated is False


# --------------------------- _detect_anti_bot_wall -----------------------------

def test_detect_anti_bot_wall_matches_challenge_selector():
    page = MagicMock()

    def locator_side_effect(selector):
        mock_locator = MagicMock()
        mock_locator.count.return_value = 1 if selector == "#challenge-running" else 0
        return mock_locator

    page.locator.side_effect = locator_side_effect
    page.title.return_value = "Totally Normal Careers Page"

    result = scraper._detect_anti_bot_wall(page)
    assert result is not None
    assert "challenge-running" in result


def test_detect_anti_bot_wall_matches_title_marker():
    page = MagicMock()
    page.locator.return_value.count.return_value = 0
    page.title.return_value = "Just a moment... | Cloudflare"

    result = scraper._detect_anti_bot_wall(page)
    assert result is not None
    assert "just a moment" in result.lower()


def test_detect_anti_bot_wall_returns_none_for_clean_page():
    page = MagicMock()
    page.locator.return_value.count.return_value = 0
    page.title.return_value = "Senior Backend Engineer at Acme"

    assert scraper._detect_anti_bot_wall(page) is None


def test_detect_anti_bot_wall_does_not_false_positive_on_body_text_only():
    # Body text mentioning "captcha" (e.g. a security-engineer job
    # description) must not trip the detector -- only title markers count.
    page = MagicMock()
    page.locator.return_value.count.return_value = 0
    page.title.return_value = "Security Engineer, Anti-Fraud & CAPTCHA Systems"

    assert scraper._detect_anti_bot_wall(page) is None


# --------------------------- _make_route_handler --------------------------------

def _mock_route(url: str, resource_type: str):
    request = MagicMock()
    request.url = url
    request.resource_type = resource_type
    route = MagicMock()
    route.request = request
    return route


def _handler(first_party_domain: str = "greenhouse.io", pre_approved_hostname: str = "boards.greenhouse.io"):
    return scraper._make_route_handler(first_party_domain, pre_approved_hostname=pre_approved_hostname)


@pytest.mark.parametrize("resource_type", ["image", "font", "media", "other", "texttrack"])
def test_route_handler_always_blocks_certain_resource_types(resource_type):
    route = _mock_route("https://boards.greenhouse.io/logo.png", resource_type)
    _handler()(route)
    route.abort.assert_called_once()
    route.continue_.assert_not_called()


@pytest.mark.parametrize("resource_type", ["script", "stylesheet", "xhr", "fetch"])
def test_route_handler_allows_first_party_party_sensitive_requests(resource_type):
    route = _mock_route("https://boards.greenhouse.io/assets/app.js", resource_type)
    _handler()(route)
    route.continue_.assert_called_once()
    route.abort.assert_not_called()


@pytest.mark.parametrize("resource_type", ["script", "stylesheet", "xhr", "fetch"])
def test_route_handler_blocks_third_party_party_sensitive_requests(resource_type):
    route = _mock_route("https://tracker.example.com/pixel.js", resource_type)
    _handler()(route)
    route.abort.assert_called_once()
    route.continue_.assert_not_called()


def test_route_handler_allows_document_requests_regardless_of_party():
    # "document" is never in the party-sensitive set -- the main frame
    # navigation itself must never be blocked by this handler.
    route = _mock_route("https://boards.greenhouse.io/acme/jobs/1", "document")
    _handler()(route)
    route.continue_.assert_called_once()


def test_route_handler_blocks_dangerous_extension_even_first_party():
    route = _mock_route("https://boards.greenhouse.io/download/setup.exe", "script")
    _handler()(route)
    route.abort.assert_called_once()


def test_route_handler_blocks_literal_private_ip_target_even_first_party_domain():
    route = _mock_route("http://10.0.0.5/probe", "xhr")
    _handler()(route)
    route.abort.assert_called_once()


def test_route_handler_blocks_cloud_metadata_endpoint():
    route = _mock_route("http://169.254.169.254/latest/meta-data/", "fetch")
    _handler()(route)
    route.abort.assert_called_once()


def test_route_handler_allows_navigation_to_pre_approved_literal_ip_target():
    # A validated public navigation target that happens to itself be a
    # literal IP (unusual but valid) must not be flagged by the cheap
    # subresource literal-IP heuristic -- it already passed the full
    # url_security pipeline before page.goto() was ever called.
    handler = scraper._make_route_handler("", pre_approved_hostname="93.184.216.34")
    route = _mock_route("https://93.184.216.34/job/1", "document")
    handler(route)
    route.continue_.assert_called_once()


def test_route_handler_only_exempts_the_exact_pre_approved_hostname():
    # The literal-IP/localhost exemption is scoped to exactly
    # pre_approved_hostname -- any other "document" request (e.g. an
    # iframe navigation) must not inherit that pass just for sharing
    # resource_type "document". (Server-side HTTP redirect hops within a
    # single navigation are a separate case Chromium doesn't route through
    # this handler at all -- see the module docstring's residual risks;
    # that path is defended by _reject_if_navigation_host_changed instead.)
    handler = scraper._make_route_handler("greenhouse.io", pre_approved_hostname="boards.greenhouse.io")
    route = _mock_route("http://169.254.169.254/not-the-approved-host", "document")
    handler(route)
    route.abort.assert_called_once()


# --------------------------- _reject_if_navigation_host_changed ------------------

def test_reject_if_navigation_host_changed_is_noop_when_host_unchanged():
    scraper._reject_if_navigation_host_changed(
        "http://127.0.0.1:1234/final", "127.0.0.1", resolver=lambda h: ["93.184.216.34"]
    )  # must not raise


def test_reject_if_navigation_host_changed_is_case_insensitive():
    scraper._reject_if_navigation_host_changed(
        "http://EXAMPLE.com/final", "example.com", resolver=lambda h: ["93.184.216.34"]
    )  # must not raise


def test_reject_if_navigation_host_changed_rejects_literal_localhost_target():
    with pytest.raises(InsecureHostError):
        scraper._reject_if_navigation_host_changed(
            "http://localhost:1234/final", "127.0.0.1", resolver=lambda h: ["93.184.216.34"]
        )


def test_reject_if_navigation_host_changed_rejects_when_new_host_resolves_privately():
    def resolver(hostname):
        return ["10.0.0.5"]

    with pytest.raises(InsecureHostError):
        scraper._reject_if_navigation_host_changed(
            "https://some-other-domain.example/final", "127.0.0.1", resolver=resolver
        )


def test_reject_if_navigation_host_changed_passes_when_new_host_resolves_safely():
    scraper._reject_if_navigation_host_changed(
        "https://some-other-domain.example/final", "127.0.0.1", resolver=lambda h: ["93.184.216.34"]
    )  # must not raise


# --------------------------- scrape_job_posting_with_retry ------------------------

def test_retry_wrapper_retries_once_on_transient_error_then_succeeds(monkeypatch):
    calls = {"n": 0}
    sentinel = MagicMock()

    def fake_scrape(url):
        calls["n"] += 1
        if calls["n"] == 1:
            raise TransientScrapingError("flaky navigation")
        return sentinel

    monkeypatch.setattr(scraper, "scrape_job_posting", fake_scrape)

    result = scraper.scrape_job_posting_with_retry("https://example.com/job")

    assert result is sentinel
    assert calls["n"] == 2


def test_retry_wrapper_raises_after_exhausting_retries(monkeypatch):
    calls = {"n": 0}

    def fake_scrape(url):
        calls["n"] += 1
        raise TransientScrapingError("still flaky")

    monkeypatch.setattr(scraper, "scrape_job_posting", fake_scrape)

    with pytest.raises(TransientScrapingError):
        scraper.scrape_job_posting_with_retry("https://example.com/job")

    assert calls["n"] == 2  # 1 initial attempt + 1 retry, per scrape_retry_limit=1


def test_retry_wrapper_never_retries_non_transient_errors(monkeypatch):
    calls = {"n": 0}

    def fake_scrape(url):
        calls["n"] += 1
        raise InsecureHostError("nope")

    monkeypatch.setattr(scraper, "scrape_job_posting", fake_scrape)

    with pytest.raises(InsecureHostError):
        scraper.scrape_job_posting_with_retry("https://example.com/job")

    assert calls["n"] == 1


@pytest.mark.parametrize(
    "error",
    [
        AntiBotDetectedError("bot wall"),
        DomStructureDriftError("selectors missed"),
        ResourceLimitExceededError("too big"),
    ],
)
def test_retry_wrapper_never_retries_other_non_transient_scraping_errors(monkeypatch, error):
    calls = {"n": 0}

    def fake_scrape(url):
        calls["n"] += 1
        raise error

    monkeypatch.setattr(scraper, "scrape_job_posting", fake_scrape)

    with pytest.raises(type(error)):
        scraper.scrape_job_posting_with_retry("https://example.com/job")

    assert calls["n"] == 1


# =============================================================================
# Integration tests -- real headless Chromium against a local HTTP fixture.
#
# The public scrape_job_posting() entry point always runs URLs through
# url_security.validate_url_security(), which correctly refuses to navigate
# anywhere on localhost/loopback -- so these tests exercise
# scraper._scrape_validated() directly with a hand-built ValidatedURL and an
# injected DNS resolver, the same test-only seam url_security.py's own tests
# use. Playwright still performs a REAL navigation against a REAL local
# server; only the Python-level safety-check's DNS answers are faked.
# =============================================================================


class _RoutedHandler(BaseHTTPRequestHandler):
    routes: dict = {}
    hit_counts: dict = {}

    def do_GET(self):
        self.hit_counts[self.path] = self.hit_counts.get(self.path, 0) + 1
        entry = self.routes.get(self.path)
        if entry is None:
            self.send_response(404)
            self.end_headers()
            return
        status, headers, body = entry
        self.send_response(status)
        for key, value in headers.items():
            self.send_header(key, value)
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, format, *args):  # noqa: A002 -- matches BaseHTTPRequestHandler signature
        pass


class _TestServer:
    def __init__(self, server: ThreadingHTTPServer, handler_cls):
        self._server = server
        self._handler_cls = handler_cls

    @property
    def port(self) -> int:
        return self._server.server_address[1]

    @property
    def base_url(self) -> str:
        return f"http://127.0.0.1:{self.port}"

    def set_route(self, path: str, *, status: int = 200, headers: Optional[dict] = None, body: bytes = b"") -> None:
        default_headers = {"Content-Type": "text/html; charset=utf-8"}
        if headers:
            default_headers.update(headers)
        self._handler_cls.routes[path] = (status, default_headers, body)

    def hits(self, path: str) -> int:
        return self._handler_cls.hit_counts.get(path, 0)


@pytest.fixture()
def http_server():
    class Handler(_RoutedHandler):
        routes: dict = {}
        hit_counts: dict = {}

    server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    try:
        yield _TestServer(server, Handler)
    finally:
        server.shutdown()
        server.server_close()
        thread.join(timeout=5)


def _always_safe_resolver(hostname: str):
    return ["93.184.216.34"]


@pytest.fixture()
def fast_timeouts(monkeypatch):
    """Shrink the selector-ready and navigation timeouts for tests that
    deliberately exercise the "nothing matched" / failure paths, so they
    don't sit at the full production 8s/30s budget.
    """
    monkeypatch.setattr(scraper.settings, "selector_ready_timeout_s", 1.5)
    monkeypatch.setattr(scraper.settings, "browser_navigation_timeout_s", 5.0)


def _validated_for(server: "_TestServer", path: str = "/job") -> ValidatedURL:
    return ValidatedURL(
        url=f"{server.base_url}{path}", hostname="127.0.0.1", resolved_ips=("93.184.216.34",)
    )


def test_scrape_validated_extracts_main_content(http_server):
    html = b"""
    <html><head><title>Senior Backend Engineer</title></head>
    <body><main>We are looking for a Senior Python Engineer with 5 years experience.</main></body>
    </html>
    """
    http_server.set_route("/job", body=html)
    validated = _validated_for(http_server)

    result = scraper._scrape_validated(
        validated, board=None, source_url=validated.url, resolver=_always_safe_resolver
    )

    assert result.matched_selector == "main"
    assert "Senior Python Engineer" in result.normalized_text
    assert result.truncated is False
    assert result.raw_html_bytes > 0
    assert result.final_url == validated.url
    assert result.job_board_name is None


def test_scrape_validated_uses_board_specific_selector_when_provided(http_server):
    html = b"""
    <html><head><title>Job</title></head>
    <body>
      <main>Generic wrapper text that should be skipped.</main>
      <div id="jobDescriptionText">Board-specific description content here.</div>
    </body></html>
    """
    http_server.set_route("/job", body=html)
    validated = _validated_for(http_server)
    indeed_board = next(b for b in JOB_BOARDS if b.name == "Indeed")

    result = scraper._scrape_validated(
        validated, board=indeed_board, source_url=validated.url, resolver=_always_safe_resolver
    )

    assert result.matched_selector == "div#jobDescriptionText"
    assert "Board-specific description content" in result.normalized_text
    assert result.job_board_name == "Indeed"


def test_scrape_validated_raises_dom_structure_drift_when_nothing_matches(http_server, fast_timeouts):
    html = b"<html><head><title>Job</title></head><body><div>no recognizable container</div></body></html>"
    http_server.set_route("/job", body=html)
    validated = _validated_for(http_server)

    with pytest.raises(DomStructureDriftError):
        scraper._scrape_validated(validated, board=None, source_url=validated.url, resolver=_always_safe_resolver)


def test_scrape_validated_raises_resource_limit_exceeded_for_oversized_html(http_server, monkeypatch):
    monkeypatch.setattr(scraper.settings, "max_html_bytes", 100)
    html = b"<html><body><main>" + (b"x" * 500) + b"</main></body></html>"
    http_server.set_route("/job", body=html)
    validated = _validated_for(http_server)

    with pytest.raises(ResourceLimitExceededError):
        scraper._scrape_validated(validated, board=None, source_url=validated.url, resolver=_always_safe_resolver)


def test_scrape_validated_raises_anti_bot_detected_on_challenge_title(http_server):
    html = b"<html><head><title>Just a moment...</title></head><body></body></html>"
    http_server.set_route("/job", body=html)
    validated = _validated_for(http_server)

    with pytest.raises(AntiBotDetectedError):
        scraper._scrape_validated(validated, board=None, source_url=validated.url, resolver=_always_safe_resolver)


def test_scrape_validated_blocks_image_subresource_at_browser_level(http_server):
    html = b"""
    <html><body>
      <main>Job description text is right here for extraction.</main>
      <img src="/tracked.png">
    </body></html>
    """
    http_server.set_route("/job", body=html)
    http_server.set_route("/tracked.png", body=b"not-really-a-png", headers={"Content-Type": "image/png"})
    validated = _validated_for(http_server)

    result = scraper._scrape_validated(
        validated, board=None, source_url=validated.url, resolver=_always_safe_resolver
    )

    assert "Job description text" in result.normalized_text
    # The image request must never have reached the server -- proves the
    # route handler is actually wired into the browser context, not just
    # correct in isolation.
    assert http_server.hits("/tracked.png") == 0


def test_scrape_validated_aborts_before_navigation_on_dns_rebind(http_server):
    http_server.set_route("/job", body=b"<html><body><main>should never be fetched</main></body></html>")
    validated = _validated_for(http_server)

    def rebound_resolver(hostname: str):
        # Simulates DNS having been rebound to an internal address between
        # the original validation pass and this navigation attempt.
        return ["10.0.0.5"]

    with pytest.raises(InsecureHostError):
        scraper._scrape_validated(validated, board=None, source_url=validated.url, resolver=rebound_resolver)

    assert http_server.hits("/job") == 0


def test_scrape_validated_rejects_client_side_redirect_to_localhost(http_server):
    # As established by test_route_handler_only_exempts_the_exact_pre_approved_hostname's
    # sibling finding (see module docstring residual risk #4): Chromium
    # follows a server-side redirect internally without re-invoking the
    # route handler, so the browser DOES fetch /final before Python-level
    # code gets a look at page.url. The safety property this module
    # actually guarantees is that _reject_if_navigation_host_changed then
    # refuses to trust that content -- it raises InsecureHostError rather
    # than returning a ScrapedJobPosting built from an unvalidated host.
    http_server.set_route(
        "/redirect-away",
        status=302,
        headers={"Location": f"http://localhost:{http_server.port}/final"},
    )
    http_server.set_route("/final", body=b"<html><body><main>should not be trusted</main></body></html>")
    validated = _validated_for(http_server, path="/redirect-away")

    with pytest.raises(InsecureHostError):
        scraper._scrape_validated(
            validated, board=None, source_url=validated.url, resolver=_always_safe_resolver
        )


def test_scrape_validated_truncates_long_descriptions(http_server, monkeypatch):
    monkeypatch.setattr(scraper.settings, "max_job_description_chars", 50)
    long_text = "Senior Engineer role. " * 20
    html = f"<html><body><main>{long_text}</main></body></html>".encode()
    http_server.set_route("/job", body=html)
    validated = _validated_for(http_server)

    result = scraper._scrape_validated(
        validated, board=None, source_url=validated.url, resolver=_always_safe_resolver
    )

    assert result.truncated is True
    assert len(result.normalized_text) <= 50


def test_scrape_job_posting_rejects_loopback_before_touching_browser(http_server):
    # The public entry point must refuse a loopback target outright via
    # url_security, never getting anywhere near Playwright.
    with pytest.raises(InsecureHostError):
        scraper.scrape_job_posting(f"{http_server.base_url}/job")
    assert http_server.hits("/job") == 0
