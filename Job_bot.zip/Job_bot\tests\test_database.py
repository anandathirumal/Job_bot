from __future__ import annotations

import sqlite3
import threading

import pytest

import database
from exceptions import DatabaseError
from models import ApplicationStatus


@pytest.fixture()
def db_path(tmp_path):
    path = tmp_path / "pipeline.db"
    database.init_db(path)
    return path


def _make_application(db_path, **overrides) -> int:
    fields = dict(
        job_title="Senior Backend Engineer",
        company_name="Acme Corp",
        source_fingerprint="fp-acme-1",
        job_url="https://jobs.acme.example/posting/1",
    )
    fields.update(overrides)
    return database.upsert_application_pipeline(db_path=db_path, **fields)


# --------------------------- init_db / pragmas -------------------------------

def test_init_db_creates_all_tables(db_path):
    with database.get_connection(db_path) as conn:
        tables = {
            row["name"]
            for row in conn.execute(
                "SELECT name FROM sqlite_master WHERE type = 'table'"
            ).fetchall()
        }
    assert {"applications", "application_status_history", "resume_versions"} <= tables


def test_init_db_is_idempotent(db_path):
    database.init_db(db_path)  # second call must not raise
    with database.get_connection(db_path) as conn:
        count = conn.execute("SELECT COUNT(*) AS n FROM applications").fetchone()["n"]
    assert count == 0


def test_journal_mode_is_wal(db_path):
    with database.get_connection(db_path) as conn:
        mode = conn.execute("PRAGMA journal_mode").fetchone()[0]
    assert mode.lower() == "wal"


def test_foreign_keys_pragma_is_on(db_path):
    with database.get_connection(db_path) as conn:
        value = conn.execute("PRAGMA foreign_keys").fetchone()[0]
    assert value == 1


def test_busy_timeout_matches_configured_value(db_path):
    with database.get_connection(db_path) as conn:
        value = conn.execute("PRAGMA busy_timeout").fetchone()[0]
    from config import settings

    assert value == settings.db_busy_timeout_ms


def test_foreign_key_violation_is_enforced(db_path):
    with database.get_connection(db_path) as conn:
        with pytest.raises(sqlite3.IntegrityError):
            conn.execute(
                """
                INSERT INTO resume_versions (
                    application_id, version_tag, source_job_text, source_resume_text,
                    validated_analysis_json, file_uuid, created_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?)
                """,
                (9999, "v1", "job text", "resume text", "{}", "uuid-orphan", "2026-01-01T00:00:00+00:00"),
            )


# --------------------------- CHECK constraints --------------------------------

def test_status_check_constraint_rejects_invalid_status(db_path):
    with database.get_connection(db_path) as conn:
        with pytest.raises(sqlite3.IntegrityError):
            conn.execute(
                """
                INSERT INTO applications (job_title, company_name, source_fingerprint, status, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?, ?)
                """,
                ("Role", "Co", "fp-bad-status", "NotARealStatus", "2026-01-01T00:00:00+00:00", "2026-01-01T00:00:00+00:00"),
            )


def test_blank_source_fingerprint_check_constraint_rejected(db_path):
    with database.get_connection(db_path) as conn:
        with pytest.raises(sqlite3.IntegrityError):
            conn.execute(
                """
                INSERT INTO applications (job_title, company_name, source_fingerprint, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?)
                """,
                ("Role", "Co", "   ", "2026-01-01T00:00:00+00:00", "2026-01-01T00:00:00+00:00"),
            )


def test_source_fingerprint_uniqueness_enforced_at_sql_level(db_path):
    with database.get_connection(db_path) as conn:
        conn.execute(
            """
            INSERT INTO applications (job_title, company_name, source_fingerprint, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?)
            """,
            ("Role A", "Co A", "fp-dupe", "2026-01-01T00:00:00+00:00", "2026-01-01T00:00:00+00:00"),
        )
        with pytest.raises(sqlite3.IntegrityError):
            conn.execute(
                """
                INSERT INTO applications (job_title, company_name, source_fingerprint, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?)
                """,
                ("Role B", "Co B", "fp-dupe", "2026-01-01T00:00:00+00:00", "2026-01-01T00:00:00+00:00"),
            )


# --------------------------- upsert_application_pipeline ----------------------

def test_upsert_application_pipeline_inserts_new_row(db_path):
    app_id = _make_application(db_path)
    assert isinstance(app_id, int)

    [record] = database.fetch_pipeline_matrix(db_path=db_path)
    assert record.id == app_id
    assert record.status is ApplicationStatus.TAILORED
    assert record.source_fingerprint == "fp-acme-1"


def test_upsert_application_pipeline_updates_on_conflict_without_resetting_status(db_path):
    app_id = _make_application(db_path)
    database.update_application_status(app_id, ApplicationStatus.APPLIED, db_path=db_path)

    same_id = _make_application(
        db_path,
        job_title="Staff Backend Engineer",
        company_name="Acme Corporation",
        job_url="https://jobs.acme.example/posting/1?utm=refresh",
    )

    assert same_id == app_id
    [record] = database.fetch_pipeline_matrix(db_path=db_path)
    assert record.job_title == "Staff Backend Engineer"
    assert record.company_name == "Acme Corporation"
    # Status must survive a re-tailoring upsert -- re-running the pipeline
    # on a job the user already applied to must not silently reset tracking.
    assert record.status is ApplicationStatus.APPLIED


def test_upsert_application_pipeline_rejects_blank_fingerprint(db_path):
    with pytest.raises(DatabaseError):
        database.upsert_application_pipeline(
            job_title="Role", company_name="Co", source_fingerprint="   ", db_path=db_path
        )


def test_upsert_application_pipeline_allows_null_job_url_for_manual_source(db_path):
    app_id = database.upsert_application_pipeline(
        job_title="Data Engineer",
        company_name="Initech",
        source_fingerprint="fp-manual-1",
        job_url=None,
        db_path=db_path,
    )
    [record] = database.fetch_pipeline_matrix(db_path=db_path)
    assert record.id == app_id
    assert record.job_url is None


# --------------------------- create_resume_version / monotonic tags -----------

def test_create_resume_version_assigns_sequential_tags(db_path):
    app_id = _make_application(db_path)

    v1 = database.create_resume_version(
        app_id,
        source_job_text="job text 1",
        source_resume_text="resume text",
        validated_analysis_json="{}",
        file_uuid="uuid-1",
        db_path=db_path,
    )
    v2 = database.create_resume_version(
        app_id,
        source_job_text="job text 2",
        source_resume_text="resume text",
        validated_analysis_json="{}",
        file_uuid="uuid-2",
        db_path=db_path,
    )

    assert v1.version_tag == "v1"
    assert v2.version_tag == "v2"
    assert v1.file_uuid != v2.file_uuid


def test_create_resume_version_unknown_application_raises(db_path):
    with pytest.raises(DatabaseError):
        database.create_resume_version(
            999,
            source_job_text="job text",
            source_resume_text="resume text",
            validated_analysis_json="{}",
            file_uuid="uuid-orphan",
            db_path=db_path,
        )
    with database.get_connection(db_path) as conn:
        count = conn.execute("SELECT COUNT(*) AS n FROM resume_versions").fetchone()["n"]
    assert count == 0


def test_create_resume_version_generates_unique_monotonic_tags_under_concurrency(db_path):
    app_id = _make_application(db_path)
    worker_count = 8
    results: list[str] = []
    errors: list[BaseException] = []
    lock = threading.Lock()

    def worker(i: int) -> None:
        try:
            record = database.create_resume_version(
                app_id,
                source_job_text=f"job text {i}",
                source_resume_text="resume text",
                validated_analysis_json="{}",
                file_uuid=f"uuid-concurrent-{i}",
                db_path=db_path,
            )
            with lock:
                results.append(record.version_tag)
        except BaseException as exc:  # noqa: BLE001 -- surfaced via errors list, not swallowed
            with lock:
                errors.append(exc)

    threads = [threading.Thread(target=worker, args=(i,)) for i in range(worker_count)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()

    assert not errors, errors
    expected = [f"v{n}" for n in range(1, worker_count + 1)]
    assert sorted(results, key=lambda tag: int(tag[1:])) == expected
    assert len(set(results)) == worker_count  # no duplicate tags handed out


# --------------------------- update_application_status / history --------------

def test_update_application_status_writes_history_atomically(db_path):
    app_id = _make_application(db_path)
    database.update_application_status(app_id, ApplicationStatus.APPLIED, db_path=db_path)

    [record] = database.fetch_pipeline_matrix(db_path=db_path)
    assert record.status is ApplicationStatus.APPLIED

    history = database.fetch_status_history(app_id, db_path=db_path)
    assert len(history) == 1
    assert history[0].old_status is ApplicationStatus.TAILORED
    assert history[0].new_status is ApplicationStatus.APPLIED


def test_update_application_status_records_multiple_transitions_in_order(db_path):
    app_id = _make_application(db_path)
    database.update_application_status(app_id, ApplicationStatus.APPLIED, db_path=db_path)
    database.update_application_status(app_id, ApplicationStatus.INTERVIEWING, db_path=db_path)

    history = database.fetch_status_history(app_id, db_path=db_path)
    assert [h.new_status for h in history] == [ApplicationStatus.APPLIED, ApplicationStatus.INTERVIEWING]
    assert history[1].old_status is ApplicationStatus.APPLIED


def test_update_application_status_unknown_application_raises(db_path):
    with pytest.raises(DatabaseError):
        database.update_application_status(999, ApplicationStatus.APPLIED, db_path=db_path)


# --------------------------- fetch_pipeline_matrix -----------------------------

def test_fetch_pipeline_matrix_filters_by_status(db_path):
    a1 = _make_application(db_path, source_fingerprint="fp-a")
    a2 = _make_application(db_path, source_fingerprint="fp-b", job_title="Other Role")
    database.update_application_status(a2, ApplicationStatus.APPLIED, db_path=db_path)

    tailored = database.fetch_pipeline_matrix(status=ApplicationStatus.TAILORED, db_path=db_path)
    applied = database.fetch_pipeline_matrix(status=ApplicationStatus.APPLIED, db_path=db_path)

    assert [r.id for r in tailored] == [a1]
    assert [r.id for r in applied] == [a2]


# --------------------------- resume version lookups ----------------------------

def test_fetch_resume_version_by_file_uuid(db_path):
    app_id = _make_application(db_path)
    created = database.create_resume_version(
        app_id,
        source_job_text="job text",
        source_resume_text="resume text",
        validated_analysis_json='{"job_title": "x"}',
        file_uuid="uuid-lookup",
        db_path=db_path,
    )

    found = database.fetch_resume_version("uuid-lookup", db_path=db_path)
    assert found == created

    missing = database.fetch_resume_version("does-not-exist", db_path=db_path)
    assert missing is None


def test_list_resume_versions_returns_all_in_order(db_path):
    app_id = _make_application(db_path)
    for i in range(3):
        database.create_resume_version(
            app_id,
            source_job_text=f"job text {i}",
            source_resume_text="resume text",
            validated_analysis_json="{}",
            file_uuid=f"uuid-list-{i}",
            db_path=db_path,
        )

    versions = database.list_resume_versions(app_id, db_path=db_path)
    assert [v.version_tag for v in versions] == ["v1", "v2", "v3"]


# --------------------------- purge / cascade deletion --------------------------

def test_purge_application_record_returns_file_uuids_and_cascades(db_path):
    app_id = _make_application(db_path)
    database.update_application_status(app_id, ApplicationStatus.APPLIED, db_path=db_path)
    database.create_resume_version(
        app_id,
        source_job_text="job text",
        source_resume_text="resume text",
        validated_analysis_json="{}",
        file_uuid="uuid-purge-1",
        db_path=db_path,
    )
    database.create_resume_version(
        app_id,
        source_job_text="job text 2",
        source_resume_text="resume text",
        validated_analysis_json="{}",
        file_uuid="uuid-purge-2",
        db_path=db_path,
    )

    file_uuids = database.purge_application_record(app_id, db_path=db_path)

    assert sorted(file_uuids) == ["uuid-purge-1", "uuid-purge-2"]
    assert database.fetch_pipeline_matrix(db_path=db_path) == []
    assert database.list_resume_versions(app_id, db_path=db_path) == []
    assert database.fetch_status_history(app_id, db_path=db_path) == []


def test_purge_application_record_unknown_id_raises(db_path):
    with pytest.raises(DatabaseError):
        database.purge_application_record(999, db_path=db_path)


# --------------------------- transaction rollback semantics --------------------

def test_transaction_rolls_back_on_python_exception(db_path):
    with database.get_connection(db_path) as conn:
        with pytest.raises(RuntimeError):
            with database._transaction(conn):
                conn.execute(
                    """
                    INSERT INTO applications (job_title, company_name, source_fingerprint, created_at, updated_at)
                    VALUES (?, ?, ?, ?, ?)
                    """,
                    ("Ghost Role", "Ghost Co", "fp-ghost", "2026-01-01T00:00:00+00:00", "2026-01-01T00:00:00+00:00"),
                )
                raise RuntimeError("simulated failure mid-transaction")

    with database.get_connection(db_path) as conn:
        count = conn.execute(
            "SELECT COUNT(*) AS n FROM applications WHERE source_fingerprint = ?", ("fp-ghost",)
        ).fetchone()["n"]
    assert count == 0


def test_transaction_rolls_back_on_check_constraint_violation(db_path):
    with database.get_connection(db_path) as conn:
        with pytest.raises(sqlite3.IntegrityError):
            with database._transaction(conn):
                conn.execute(
                    """
                    INSERT INTO applications (job_title, company_name, source_fingerprint, status, created_at, updated_at)
                    VALUES (?, ?, ?, ?, ?, ?)
                    """,
                    (
                        "Bad Status Role",
                        "Bad Co",
                        "fp-bad-status-txn",
                        "NotARealStatus",
                        "2026-01-01T00:00:00+00:00",
                        "2026-01-01T00:00:00+00:00",
                    ),
                )

    with database.get_connection(db_path) as conn:
        count = conn.execute(
            "SELECT COUNT(*) AS n FROM applications WHERE source_fingerprint = ?", ("fp-bad-status-txn",)
        ).fetchone()["n"]
    assert count == 0


def test_create_resume_version_wraps_integrity_error_and_rolls_back(db_path):
    app_id = _make_application(db_path)

    # Pre-seed a row claiming the file_uuid the next call will also try to
    # use, forcing a genuine UNIQUE constraint violation on file_uuid --
    # exercising the same sqlite3.IntegrityError -> DatabaseError path a
    # real (if extremely unlikely) UUID collision would hit.
    with database.get_connection(db_path) as conn:
        with database._transaction(conn):
            conn.execute(
                """
                INSERT INTO resume_versions (
                    application_id, version_tag, source_job_text, source_resume_text,
                    validated_analysis_json, file_uuid, created_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?)
                """,
                (app_id, "v1", "job text", "resume text", "{}", "uuid-dupe", "2026-01-01T00:00:00+00:00"),
            )

    with pytest.raises(DatabaseError):
        database.create_resume_version(
            app_id,
            source_job_text="job text 2",
            source_resume_text="resume text",
            validated_analysis_json="{}",
            file_uuid="uuid-dupe",
            db_path=db_path,
        )

    # The failed attempt must not have consumed a version_tag or left an
    # orphaned row: only the one pre-seeded version should remain, and the
    # next successful call must still get "v2", not "v3".
    versions = database.list_resume_versions(app_id, db_path=db_path)
    assert [v.file_uuid for v in versions] == ["uuid-dupe"]

    next_version = database.create_resume_version(
        app_id,
        source_job_text="job text 3",
        source_resume_text="resume text",
        validated_analysis_json="{}",
        file_uuid="uuid-after-conflict",
        db_path=db_path,
    )
    assert next_version.version_tag == "v2"
