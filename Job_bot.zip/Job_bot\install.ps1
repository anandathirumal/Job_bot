<#
.SYNOPSIS
    Installs Job_bot: creates a virtual environment, installs Python
    dependencies, downloads the Playwright Chromium browser, and bootstraps
    the .env configuration file.

.DESCRIPTION
    Run this once, from the root of a freshly cloned Job_bot repository:

        powershell -ExecutionPolicy Bypass -File install.ps1

    Safe to re-run -- it reuses an existing virtual environment and never
    overwrites an existing .env file.

.PARAMETER SkipPlaywright
    Skip downloading the Playwright Chromium browser (scraper.py needs it
    to fetch job postings from URLs; the rest of the app still works
    without it -- job descriptions can be pasted manually instead).
#>

[CmdletBinding()]
param(
    [switch]$SkipPlaywright
)

$ErrorActionPreference = "Stop"

function Write-Step {
    param([string]$Message)
    Write-Host ""
    Write-Host "==> $Message" -ForegroundColor Cyan
}

function Find-Python {
    foreach ($candidate in @("python", "python3", "py")) {
        $cmd = Get-Command $candidate -ErrorAction SilentlyContinue
        if (-not $cmd) { continue }
        try {
            $versionOutput = & $candidate --version 2>&1
        } catch {
            continue
        }
        if ($versionOutput -match "Python 3\.(1[1-9]|[2-9]\d)") {
            return $candidate
        }
    }
    return $null
}

Write-Step "Checking for Python 3.11+"
$python = Find-Python
if (-not $python) {
    Write-Host "Python 3.11 or newer is required but was not found on PATH." -ForegroundColor Red
    Write-Host "Install it from https://www.python.org/downloads/ (check 'Add python.exe to PATH' during setup), then re-run this script."
    exit 1
}
Write-Host "Using: $python ($(& $python --version))"

$repoRoot = $PSScriptRoot
Set-Location $repoRoot

$venvPath = Join-Path $repoRoot ".venv"
$venvPython = Join-Path $venvPath "Scripts\python.exe"

if (-not (Test-Path $venvPython)) {
    Write-Step "Creating virtual environment at .venv"
    & $python -m venv $venvPath
    if (-not (Test-Path $venvPython)) {
        Write-Host "Virtual environment creation failed -- $venvPython was not created." -ForegroundColor Red
        exit 1
    }
} else {
    Write-Host "Virtual environment already exists at .venv -- reusing it."
}

Write-Step "Upgrading pip"
& $venvPython -m pip install --upgrade pip
if ($LASTEXITCODE -ne 0) {
    Write-Host "Failed to upgrade pip. See the output above." -ForegroundColor Red
    exit 1
}

Write-Step "Installing Job_bot and its Python dependencies"
& $venvPython -m pip install -e ".[dev]"
if ($LASTEXITCODE -ne 0) {
    Write-Host "Dependency installation failed. See the pip output above." -ForegroundColor Red
    exit 1
}

if (-not $SkipPlaywright) {
    Write-Step "Installing the Playwright Chromium browser (used by scraper.py to fetch job postings)"
    & $venvPython -m playwright install chromium
    if ($LASTEXITCODE -ne 0) {
        Write-Host "Playwright browser install failed. You can retry later with:" -ForegroundColor Yellow
        Write-Host "  .venv\Scripts\python.exe -m playwright install chromium"
    }
} else {
    Write-Host "Skipping Playwright browser install (-SkipPlaywright)."
}

$envExample = Join-Path $repoRoot ".env.example"
$envFile = Join-Path $repoRoot ".env"
if ((Test-Path $envExample) -and (-not (Test-Path $envFile))) {
    Write-Step "Creating .env from .env.example"
    Copy-Item $envExample $envFile
    Write-Host "Created .env -- edit it and set JOBPORTAL_ANTHROPIC_API_KEY before running the app."
} elseif (Test-Path $envFile) {
    Write-Host ".env already exists -- leaving it untouched."
} else {
    Write-Host ".env.example not found -- skipping .env bootstrap." -ForegroundColor Yellow
}

Write-Step "Installation complete"
Write-Host ""
Write-Host "Next steps:" -ForegroundColor Green
Write-Host "  1. Edit .env and set JOBPORTAL_ANTHROPIC_API_KEY (or ANTHROPIC_API_KEY)."
Write-Host "  2. Run the app:"
Write-Host "       .\run.ps1"
Write-Host "     or manually:"
Write-Host "       .venv\Scripts\Activate.ps1"
Write-Host "       streamlit run app.py"
Write-Host ""
