<#
.SYNOPSIS
    Installs Job_bot: creates a virtual environment, installs Python
    dependencies, downloads the Playwright Chromium browser, and bootstraps
    the .env configuration file.

.DESCRIPTION
    Run this once, from the root of a freshly cloned Job_bot repository:

        powershell -ExecutionPolicy Bypass -File install.ps1

    Safe to re-run -- it reuses an existing virtual environment and never
    overwrites an existing .env file.

.PARAMETER SkipPlaywright
    Skip downloading the Playwright Chromium browser (scraper.py needs it
    to fetch job postings from URLs; the rest of the app still works
    without it -- job descriptions can be pasted manually instead).
#>

[CmdletBinding()]
param(
    [switch]$SkipPlaywright
)

$ErrorActionPreference = "Stop"

function Write-Step {
    param([string]$Message)
    Write-Host ""
    Write-Host "==> $Message" -ForegroundColor Cyan
}

function Find-Python {
    # Returns a concrete python.exe FILE PATH (string), or $null.
    #
    # Deliberately never invokes the "py" launcher with a version flag plus
    # forwarded arguments (e.g. `py -3.11 -m venv ...`) -- that combination
    # has been observed to silently fail to pass the trailing arguments
    # through to the underlying interpreter in some non-interactive/
    # automated shell contexts, leaving python.exe to start in interactive
    # mode instead of running the intended command (which then hangs
    # waiting on stdin that will never arrive). `py -0p` (a pure listing
    # operation -- it never launches a child interpreter itself) and a
    # direct python.exe path invocation are both reliable; those are the
    # only two patterns used here and everywhere else in this script.

    # 1. Bare `python`/`python3` on PATH, resolved to a concrete file via
    #    Get-Command, invoked directly (not through any launcher).
    foreach ($candidate in @("python", "python3")) {
        $cmd = Get-Command $candidate -ErrorAction SilentlyContinue
        if (-not $cmd) { continue }
        # Skip the Microsoft Store's python.exe alias stub: it resolves on
        # PATH even when no real Python is installed, and either silently
        # opens the Store or prints nothing usable instead of a version
        # string -- a very common source of false "Python not found" style
        # confusion on a fresh Windows install.
        if ($cmd.Source -match "WindowsApps") { continue }
        try {
            $out = & $cmd.Source --version 2>&1
        } catch {
            continue
        }
        if ($LASTEXITCODE -eq 0 -and $out -match "Python 3\.(1[1-9]|[2-9]\d)") {
            return $cmd.Source
        }
    }

    # 2. Ask the Python Launcher to list every installed interpreter with
    #    its concrete path (`py -0p`), and use the newest 3.11+ one's path
    #    directly -- this finds versions installed alongside an older
    #    "default" python that step 1 alone would miss.
    if (Get-Command "py" -ErrorAction SilentlyContinue) {
        try {
            $listing = & py -0p 2>&1
        } catch {
            $listing = @()
        }
        $candidates = @()
        foreach ($line in $listing) {
            if ($line -match "-V:3\.(1[1-9]|[2-9]\d).*?(\S:\\.+python\.exe)") {
                $minor = [int]$Matches[1]
                $path = $Matches[2]
                if (Test-Path $path) {
                    $candidates += [PSCustomObject]@{ Minor = $minor; Path = $path }
                }
            }
        }
        if ($candidates.Count -gt 0) {
            return ($candidates | Sort-Object Minor -Descending | Select-Object -First 1).Path
        }
    }

    return $null
}

function Install-PythonViaWinget {
    if (-not (Get-Command winget -ErrorAction SilentlyContinue)) {
        return $false
    }
    $answer = Read-Host "Install Python 3.11 now via winget? [y/N]"
    if ($answer -notmatch "^[Yy]") {
        return $false
    }
    Write-Step "Installing Python 3.11 via winget"
    winget install --id Python.Python.3.11 --source winget --accept-package-agreements --accept-source-agreements
    if ($LASTEXITCODE -ne 0) {
        Write-Host "winget install failed. See the output above." -ForegroundColor Red
        return $false
    }
    Write-Host ""
    Write-Host "Python 3.11 was just installed. PATH changes don't apply to this already-open" -ForegroundColor Yellow
    Write-Host "window -- close it and re-run install.ps1 from a NEW PowerShell window." -ForegroundColor Yellow
    return $true
}

Write-Step "Checking for Python 3.11+"
$pythonPath = Find-Python
if (-not $pythonPath) {
    Write-Host "Python 3.11 or newer was not found (checked python/python3 on PATH and every interpreter 'py -0p' knows about)." -ForegroundColor Red
    Write-Host ""
    if (Install-PythonViaWinget) {
        exit 0
    }
    Write-Host "Install Python 3.11+ manually, then re-run this script:"
    Write-Host "  winget install --id Python.Python.3.11"
    Write-Host "  (or download from https://www.python.org/downloads/ -- check 'Add python.exe to PATH' during setup)"
    exit 1
}
Write-Host "Using: $pythonPath ($(& $pythonPath --version))"

$repoRoot = $PSScriptRoot
Set-Location $repoRoot

$venvPath = Join-Path $repoRoot ".venv"
$venvPython = Join-Path $venvPath "Scripts\python.exe"

if (-not (Test-Path $venvPython)) {
    Write-Step "Creating virtual environment at .venv"
    & $pythonPath -m venv $venvPath
    if (-not (Test-Path $venvPython)) {
        Write-Host "Virtual environment creation failed -- $venvPython was not created." -ForegroundColor Red
        exit 1
    }
} else {
    Write-Host "Virtual environment already exists at .venv -- reusing it."
}

Write-Step "Upgrading pip"
& $venvPython -m pip install --upgrade pip
if ($LASTEXITCODE -ne 0) {
    Write-Host "Failed to upgrade pip. See the output above." -ForegroundColor Red
    exit 1
}

Write-Step "Installing Job_bot and its Python dependencies"
& $venvPython -m pip install -e ".[dev]"
if ($LASTEXITCODE -ne 0) {
    Write-Host "Dependency installation failed. See the pip output above." -ForegroundColor Red
    exit 1
}

if (-not $SkipPlaywright) {
    Write-Step "Installing the Playwright Chromium browser (used by scraper.py to fetch job postings)"
    & $venvPython -m playwright install chromium
    if ($LASTEXITCODE -ne 0) {
        Write-Host "Playwright browser install failed. You can retry later with:" -ForegroundColor Yellow
        Write-Host "  .venv\Scripts\python.exe -m playwright install chromium"
    }
} else {
    Write-Host "Skipping Playwright browser install (-SkipPlaywright)."
}

$envExample = Join-Path $repoRoot ".env.example"
$envFile = Join-Path $repoRoot ".env"
if ((Test-Path $envExample) -and (-not (Test-Path $envFile))) {
    Write-Step "Creating .env from .env.example"
    Copy-Item $envExample $envFile
    Write-Host "Created .env -- edit it and set JOBPORTAL_ANTHROPIC_API_KEY before running the app."
} elseif (Test-Path $envFile) {
    Write-Host ".env already exists -- leaving it untouched."
} else {
    Write-Host ".env.example not found -- skipping .env bootstrap." -ForegroundColor Yellow
}

Write-Step "Installation complete"
Write-Host ""
Write-Host "Next steps:" -ForegroundColor Green
Write-Host "  1. Edit .env and set JOBPORTAL_ANTHROPIC_API_KEY (or ANTHROPIC_API_KEY)."
Write-Host "  2. Run the app:"
Write-Host "       .\run.ps1"
Write-Host "     or manually:"
Write-Host "       .venv\Scripts\Activate.ps1"
Write-Host "       streamlit run app.py"
Write-Host ""
