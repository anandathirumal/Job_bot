"""Filesystem storage layer for generated ``.docx`` resume documents.

This module is deliberately unaware of ``database.py``. It knows nothing
about applications, resume versions, or SQLite -- it only knows how to turn
a ``file_uuid`` string into a safe path under the configured storage
directory and read/write/delete bytes there. ``pipeline.py`` is the layer
that coordinates the two: it calls ``database.purge_application_record()``
to get back the ``file_uuid`` values of a deleted application's resume
versions, then calls :func:`delete_resume_documents` here to remove the
corresponding files. Keeping transactional database integrity and
filesystem side effects in separate modules means a bug in one can never
corrupt the invariants of the other.

Every path this module produces is derived from :func:`resolve_resume_document_path`,
which strictly validates ``file_uuid`` as a real UUID (via ``uuid.UUID``)
before it ever touches a path. This is the path-traversal defense: a
crafted identifier like ``"../../../etc/passwd"`` or one containing a null
byte simply fails UUID parsing and is rejected with
:class:`exceptions.InvalidFileIdentifierError` before any filesystem call
is made, rather than being "sanitized" and used anyway.

RESIDUAL RISKS:

1. **No cross-subsystem transaction.** A purge is, by design, "delete the
   database row first (durable, atomic), then best-effort delete the
   file(s) after." If the process crashes or a file is locked by another
   program between those two steps, the ``.docx`` can be left orphaned on
   disk with no database row pointing to it. This module surfaces that
   condition via :class:`PurgeFileResult.failed` rather than hiding it;
   ``pipeline.py`` must log/report it so an operator can reconcile disk
   contents later. There is intentionally no distributed-transaction
   machinery here for a single-user desktop tool.
2. **File locks are not retried.** On Windows in particular, a ``.docx``
   the user currently has open in Word will raise ``PermissionError`` on
   delete. That failure is captured per-file in ``PurgeFileResult.failed``
   instead of aborting the whole batch, but this module does not wait or
   retry -- the caller decides whether/when to try again.
3. **The storage directory itself is trusted configuration, not user
   input.** UUID validation stops a hostile ``file_uuid`` from escaping the
   directory, but this module assumes ``settings.resume_storage_dir`` (or
   an explicit ``base_dir`` override) is a location the operator controls,
   not something derived from untrusted input.
"""

from __future__ import annotations

import os
import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, Optional

from config import settings
from exceptions import DocumentGenerationError, InvalidFileIdentifierError, StorageError


@dataclass(frozen=True)
class PurgeFileResult:
    """Outcome of a bulk :func:`delete_resume_documents` call."""

    deleted: tuple[str, ...]
    missing: tuple[str, ...]
    failed: tuple[tuple[str, str], ...]  # (file_uuid, error message)

    @property
    def all_succeeded(self) -> bool:
        return not self.failed


def generate_file_uuid() -> str:
    """Canonical way to mint a new document identifier. Callers (e.g.
    ``pipeline.py``, before calling ``database.create_resume_version()``)
    should always get their ``file_uuid`` from here rather than formatting
    ``uuid.uuid4()`` themselves, so the value is guaranteed to already be in
    the exact canonical form :func:`resolve_resume_document_path` expects.
    """
    return str(uuid.uuid4())


def init_storage(base_dir: Optional[Path | str] = None) -> Path:
    """Ensure the storage directory exists. Safe to call on every
    application boot.
    """
    directory = _resolve_base_dir(base_dir)
    directory.mkdir(parents=True, exist_ok=True)
    return directory


def _resolve_base_dir(base_dir: Optional[Path | str]) -> Path:
    return Path(base_dir) if base_dir is not None else settings.resume_storage_dir


def _validate_file_uuid(file_uuid: str) -> str:
    if not isinstance(file_uuid, str):
        raise InvalidFileIdentifierError(f"file_uuid must be a string, got {type(file_uuid).__name__}")
    try:
        parsed = uuid.UUID(file_uuid)
    except (ValueError, AttributeError, TypeError) as exc:
        raise InvalidFileIdentifierError(f"file_uuid is not a valid UUID: {file_uuid!r}") from exc
    return str(parsed)


def resolve_resume_document_path(file_uuid: str, *, base_dir: Optional[Path | str] = None) -> Path:
    """Turn a ``file_uuid`` into the absolute path of its ``.docx`` on disk.

    This is the single choke point every other function in this module
    routes through. ``file_uuid`` is validated as a real UUID first (see
    module docstring), then the resulting canonical, hyphenated,
    lowercase form -- containing nothing but hex digits and hyphens -- is
    used as the filename. The containment check below is deliberately
    redundant with that validation: it should be unreachable, but stays
    in place as a defense-in-depth guard against a future refactor that
    might loosen ``_validate_file_uuid``.
    """
    normalized = _validate_file_uuid(file_uuid)
    directory = _resolve_base_dir(base_dir)
    resolved_directory = directory.resolve()
    resolved_candidate = (resolved_directory / f"{normalized}.docx").resolve()

    if not resolved_candidate.is_relative_to(resolved_directory):
        raise InvalidFileIdentifierError(
            f"Resolved document path {resolved_candidate} escapes the storage "
            f"directory {resolved_directory}"
        )
    return resolved_candidate


def save_resume_document(
    file_uuid: str, content: bytes, *, base_dir: Optional[Path | str] = None
) -> Path:
    """Write ``content`` to the ``.docx`` path for ``file_uuid``, atomically.

    Writes to a sibling temp file first and ``os.replace``s it into place,
    so a crash or failure mid-write can never leave a truncated/corrupt
    ``.docx`` at the final path -- readers only ever see either the
    previous complete file (on failure) or the new complete file (on
    success), never a partial one.
    """
    if not content:
        raise DocumentGenerationError("Refusing to save an empty .docx payload")

    path = resolve_resume_document_path(file_uuid, base_dir=base_dir)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp_path = path.with_name(f".{path.name}.{uuid.uuid4().hex}.tmp")

    try:
        tmp_path.write_bytes(content)
        os.replace(tmp_path, path)
    except OSError as exc:
        raise StorageError(f"Failed to save document for file_uuid={file_uuid!r}: {exc}") from exc
    finally:
        if tmp_path.exists():
            tmp_path.unlink(missing_ok=True)

    return path


def resume_document_exists(file_uuid: str, *, base_dir: Optional[Path | str] = None) -> bool:
    return resolve_resume_document_path(file_uuid, base_dir=base_dir).is_file()


def read_resume_document(file_uuid: str, *, base_dir: Optional[Path | str] = None) -> bytes:
    path = resolve_resume_document_path(file_uuid, base_dir=base_dir)
    try:
        return path.read_bytes()
    except FileNotFoundError as exc:
        raise StorageError(f"No stored document for file_uuid={file_uuid!r}") from exc


def delete_resume_document(file_uuid: str, *, base_dir: Optional[Path | str] = None) -> bool:
    """Delete a single document. Returns ``True`` if a file was removed,
    ``False`` if it was already absent (idempotent -- a purge retried after
    a partial failure should not raise just because some files are
    already gone).
    """
    path = resolve_resume_document_path(file_uuid, base_dir=base_dir)
    try:
        os.remove(path)
        return True
    except FileNotFoundError:
        return False


def delete_resume_documents(
    file_uuids: Iterable[str], *, base_dir: Optional[Path | str] = None
) -> PurgeFileResult:
    """Bulk-delete documents, e.g. the ``file_uuid`` tuple returned by
    ``database.purge_application_record()``.

    A single file's ``OSError`` (locked, permission denied, ...) is
    recorded in ``PurgeFileResult.failed`` rather than aborting the rest of
    the batch -- the database row is already gone by the time this runs, so
    the caller wants "clean up as much as possible and tell me what's
    left," not an all-or-nothing failure. An :class:`InvalidFileIdentifierError`
    is different: it indicates a malformed identifier reached this function
    at all, which points at a bug upstream, so it is never swallowed.
    """
    deleted: list[str] = []
    missing: list[str] = []
    failed: list[tuple[str, str]] = []

    for file_uuid in file_uuids:
        try:
            if delete_resume_document(file_uuid, base_dir=base_dir):
                deleted.append(file_uuid)
            else:
                missing.append(file_uuid)
        except InvalidFileIdentifierError:
            raise
        except OSError as exc:
            failed.append((file_uuid, str(exc)))

    return PurgeFileResult(deleted=tuple(deleted), missing=tuple(missing), failed=tuple(failed))
