"""Linear, ATS-parsing-compliant ``.docx`` generation.

Renders a :class:`models.ResumeProfile` (source of truth for facts: contact
info, full work history, education, certifications) merged with a
sanitized :class:`models.TailoredResumeSchema` (the AI-optimized summary,
emphasized skills, and per-role bullet rewrites that already passed
``llm_service.verify_and_sanitize_tailored_resume``) into a single ``.docx``
document, returned as bytes -- this module performs no filesystem I/O
itself; ``storage.py`` owns writing the result to disk.

**ATS-parsing-compliance choices**, all in service of a single linear
top-to-bottom reading order a parser can follow without guessing:

- No tables, text boxes, columns, or embedded images anywhere in the
  document -- these are the most common source of scrambled or dropped
  text in real-world ATS parsers.
- Section headings use Word's built-in Heading styles (``add_heading``),
  not bold-and-bigger body text, so heading-detection heuristics that key
  off paragraph style actually find them.
- Bullets use the native "List Bullet" paragraph style (real Word list
  XML), not hand-typed bullet characters.
- Contact information is a normal paragraph at the top of the document
  body -- never placed in a header or footer, which many ATS parsers skip
  entirely.
- One font family and size for body text, set once on the Normal style,
  rather than per-paragraph formatting that can render inconsistently
  across parsers.

**Hard content invariants, enforced here independent of what the LLM or
sanitization pass produced**:

- Every role in ``profile.experience`` is rendered, in its original order,
  even if the tailoring pass produced no update for that role at all --
  the document must always represent the candidate's complete real work
  history. Bullets come from the sanitized tailored update when one exists
  for that (role, company); otherwise the original bullet text is used
  unchanged.
- ``TailoredResumeSchema.skills_missing_not_safe_to_claim`` is never
  written into the document, anywhere -- per the spec, missing
  qualifications may only surface to the candidate as guidance (via
  ``pipeline.py`` / the UI), never as claimed resume content.
- ``TailoredResumeSchema.critical_warnings`` is likewise never written
  into the document -- it's operator/candidate-facing metadata about the
  tailoring run, not resume content.

RESIDUAL RISK -- this module verifies structural traceability (every
rendered bullet either came from the original resume verbatim or from a
sanitized update whose ``source_bullet_id`` was independently confirmed by
``llm_service.py``) and skill-name evidence, but it does **not**
fact-check the *prose* of ``professional_summary`` or the reworded text of
``optimized_bullet`` sentence-by-sentence against the source resume. That
level of free-text verification is beyond this module's (and
``llm_service.py``'s) scope; phrasing quality is trusted to the model's
system-prompt instructions, not mechanically re-verified.
"""

from __future__ import annotations

import io

from docx import Document
from docx.shared import Pt

from models import ResumeExperienceSection, ResumeProfile, TailoredResumeSchema

_BODY_FONT = "Calibri"
_BODY_FONT_SIZE_PT = 11

_SECTION_TITLES = {
    "professional_summary": "Professional Summary",
    "experience": "Experience",
    "skills": "Skills",
    "education": "Education",
    "certifications": "Certifications",
    "additional_sections": None,  # each additional section supplies its own title
}


def _merge_experience(
    profile: ResumeProfile, tailored: TailoredResumeSchema
) -> list[tuple[ResumeExperienceSection, list[str]]]:
    """Full work history, in the profile's original order. Bullet text for
    each role comes from the sanitized tailored update if one exists for
    that (role, company) pair, else falls back to the original bullets --
    a role the tailoring pass didn't touch must still appear, unmodified.
    """
    updates_by_role = {
        (update.role_title.strip().lower(), update.company.strip().lower()): update
        for update in tailored.experience_updates
    }
    merged: list[tuple[ResumeExperienceSection, list[str]]] = []
    for section in profile.experience:
        key = (section.role_title.strip().lower(), section.company.strip().lower())
        update = updates_by_role.get(key)
        if update is not None and update.bullet_updates:
            bullet_texts = [bullet.optimized_bullet for bullet in update.bullet_updates]
        else:
            bullet_texts = [bullet.text for bullet in section.bullets]
        merged.append((section, bullet_texts))
    return merged


def _merge_skills(profile: ResumeProfile, tailored: TailoredResumeSchema) -> list[str]:
    """Emphasized (evidenced, job-relevant) skills first, then any other
    real skill from the profile not already covered -- every skill the
    candidate actually has stays in the document; emphasis just orders
    them. ``skills_missing_not_safe_to_claim`` never enters this list.
    """
    seen_lower: set[str] = set()
    merged: list[str] = []
    for skill in [*tailored.skills_to_emphasize, *profile.skills]:
        key = skill.strip().lower()
        if key and key not in seen_lower:
            seen_lower.add(key)
            merged.append(skill)
    return merged


def _configure_base_style(document: Document) -> None:
    normal = document.styles["Normal"]
    normal.font.name = _BODY_FONT
    normal.font.size = Pt(_BODY_FONT_SIZE_PT)


def _render_contact_info(document: Document, profile: ResumeProfile) -> None:
    document.add_paragraph(profile.contact_info)


def _render_professional_summary(document: Document, profile: ResumeProfile, tailored: TailoredResumeSchema) -> None:
    text = tailored.professional_summary.strip() or profile.professional_summary.strip()
    if not text:
        return
    document.add_heading(_SECTION_TITLES["professional_summary"], level=1)
    document.add_paragraph(text)


def _render_experience(document: Document, profile: ResumeProfile, tailored: TailoredResumeSchema) -> None:
    merged = _merge_experience(profile, tailored)
    if not merged:
        return
    document.add_heading(_SECTION_TITLES["experience"], level=1)
    for section, bullet_texts in merged:
        document.add_heading(f"{section.role_title} — {section.company}", level=2)
        document.add_paragraph(section.timeframe)
        for bullet_text in bullet_texts:
            document.add_paragraph(bullet_text, style="List Bullet")


def _render_skills(document: Document, profile: ResumeProfile, tailored: TailoredResumeSchema) -> None:
    skills = _merge_skills(profile, tailored)
    if not skills:
        return
    document.add_heading(_SECTION_TITLES["skills"], level=1)
    document.add_paragraph(", ".join(skills))


def _render_education(document: Document, profile: ResumeProfile, _tailored: TailoredResumeSchema) -> None:
    if not profile.education:
        return
    document.add_heading(_SECTION_TITLES["education"], level=1)
    for entry in profile.education:
        document.add_heading(f"{entry.credential} — {entry.institution}", level=2)
        document.add_paragraph(entry.timeframe)
        for detail in entry.details:
            document.add_paragraph(detail, style="List Bullet")


def _render_certifications(document: Document, profile: ResumeProfile, _tailored: TailoredResumeSchema) -> None:
    if not profile.certifications:
        return
    document.add_heading(_SECTION_TITLES["certifications"], level=1)
    for cert in profile.certifications:
        line = f"{cert.name} — {cert.issuer}"
        if cert.date_earned:
            line += f" ({cert.date_earned})"
        document.add_paragraph(line, style="List Bullet")


def _render_additional_sections(document: Document, profile: ResumeProfile, _tailored: TailoredResumeSchema) -> None:
    for additional in profile.additional_sections:
        if not additional.items:
            continue
        document.add_heading(additional.title, level=1)
        for item in additional.items:
            document.add_paragraph(item, style="List Bullet")


_SECTION_RENDERERS = {
    "professional_summary": _render_professional_summary,
    "experience": _render_experience,
    "skills": _render_skills,
    "education": _render_education,
    "certifications": _render_certifications,
    "additional_sections": _render_additional_sections,
}


def build_resume_docx(profile: ResumeProfile, tailored: TailoredResumeSchema) -> bytes:
    """Render ``profile`` + the already-sanitized ``tailored`` schema into a
    ``.docx`` file, returned as bytes. Callers are responsible for passing
    a schema that already went through
    ``llm_service.verify_and_sanitize_tailored_resume`` -- this function
    trusts ``tailored.experience_updates`` / ``skills_to_emphasize`` as
    already evidence-checked and does not re-verify them.
    """
    document = Document()
    _configure_base_style(document)
    document.core_properties.author = ""
    document.core_properties.title = f"{tailored.job_title} Resume"

    _render_contact_info(document, profile)

    for section_name in profile.section_order:
        renderer = _SECTION_RENDERERS.get(section_name)
        if renderer is not None:
            renderer(document, profile, tailored)

    buffer = io.BytesIO()
    document.save(buffer)
    return buffer.getvalue()
