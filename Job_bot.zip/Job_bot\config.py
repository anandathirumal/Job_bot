"""Centralized, environment-driven configuration.

All hard operational boundaries from the security spec live here as typed,
validated defaults so no other module hardcodes a magic number. Values may
be overridden via environment variables or a local ``.env`` file (see
``.env.example``), but the retry-limit and redirect-cap validators below
prevent an environment misconfiguration from silently loosening the
security posture past the policy ceiling.
"""

from __future__ import annotations

from pathlib import Path

from pydantic import Field, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        env_prefix="JOBPORTAL_",
        extra="ignore",
    )

    # --- Anthropic ------------------------------------------------------
    anthropic_api_key: str = Field(
        default="",
        description="Set via JOBPORTAL_ANTHROPIC_API_KEY (or ANTHROPIC_API_KEY, see below).",
    )
    anthropic_model: str = Field(
        default="claude-sonnet-5",
        description="Must support Anthropic native Structured Outputs; verified by the boot-time capability handshake in llm_service.py.",
    )
    llm_max_output_tokens: int = 8000

    # --- Resource abuse boundaries (spec section 2) ----------------------
    max_url_length: int = 2048
    max_html_bytes: int = 5 * 1024 * 1024
    max_job_description_chars: int = 50_000
    max_resume_profile_chars: int = 100_000

    # --- Network / browser timeouts --------------------------------------
    browser_navigation_timeout_s: float = 30.0
    selector_ready_timeout_s: float = 8.0
    http_validation_timeout_s: float = 10.0
    max_redirects: int = 3

    # --- Retry policy (spec section 2: "at most one retry") --------------
    scrape_retry_limit: int = 1
    structured_output_retry_limit: int = 1

    # --- Storage ----------------------------------------------------------
    database_path: Path = Path("data/pipeline.db")
    resume_storage_dir: Path = Path("data/generated_resumes")
    db_busy_timeout_ms: int = 5000

    # --- HTTP client identity for the URL-validation engine ----------------
    http_user_agent: str = "JobPortalLinkValidator/1.0 (+security-hardened; contact: operator)"

    @field_validator("max_redirects")
    @classmethod
    def _cap_redirects(cls, v: int) -> int:
        if v > 3:
            raise ValueError(
                "max_redirects cannot exceed the hardened policy cap of 3"
            )
        if v < 0:
            raise ValueError("max_redirects cannot be negative")
        return v

    @field_validator("scrape_retry_limit", "structured_output_retry_limit")
    @classmethod
    def _cap_retries(cls, v: int) -> int:
        if v > 1:
            raise ValueError("retry limits are hard-capped at 1 by policy")
        if v < 0:
            raise ValueError("retry limits cannot be negative")
        return v

    @field_validator(
        "max_url_length",
        "max_html_bytes",
        "max_job_description_chars",
        "max_resume_profile_chars",
        "db_busy_timeout_ms",
        "llm_max_output_tokens",
    )
    @classmethod
    def _positive(cls, v: int) -> int:
        if v <= 0:
            raise ValueError("resource boundaries must be positive")
        return v


settings = Settings()
